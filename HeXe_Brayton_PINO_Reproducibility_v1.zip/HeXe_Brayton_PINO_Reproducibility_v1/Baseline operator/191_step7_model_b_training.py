#!/usr/bin/env python3
"""
191_step7_model_b_training.py

STEP 7 - MODEL B ACTUAL TRAINING

Model:
    Dual-Resolution Coordinate DeepONet

Frozen operator:
    external reactivity history -> 10 coupled dynamic states

Global:
    601 points over 600 s

Event-local:
    1021 points over 0-5 s

Important:
    - Production-V1 dataset is NOT modified.
    - Normalization is TRAIN-only.
    - VALIDATION is used only for early stopping/checkpoint selection.
    - ID/OOD/STRESS are evaluated only after training.
    - No physics loss yet.
"""

from __future__ import annotations

import json
import math
import platform
import random
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn


# =====================================================================
# FROZEN DATASET CONTRACT
# =====================================================================

TOTAL_CASES = 2177
GLOBAL_POINTS = 601
EVENT_CASES = 1088
EVENT_POINTS = 1021
N_STATES = 10

PARTITIONS = {
    "TRAIN": (0, 1025),
    "VALIDATION": (1025, 1281),
    "ID_TEST": (1281, 1537),
    "OOD_NEG_TEST": (1537, 1793),
    "OOD_POS_TEST": (1793, 2049),
    "STRESS_TEST": (2049, 2177),
}

EVENT_PARTITION_COUNTS = {
    "TRAIN": 512,
    "VALIDATION": 128,
    "ID_TEST": 128,
    "OOD_NEG_TEST": 128,
    "OOD_POS_TEST": 128,
    "STRESS_TEST": 64,
}


# =====================================================================
# TRAINING CONFIGURATION
# =====================================================================

SEED = 20261002

MAX_EPOCHS = 100
BATCH_SIZE = 8

GLOBAL_QUERY_POINTS = 32

EVENT_FAST_QUERY_POINTS = 48
EVENT_SLOW_QUERY_POINTS = 16

LEARNING_RATE = 1.0e-3
WEIGHT_DECAY = 0.0

GRADIENT_CLIP = 1.0

EARLY_STOPPING_PATIENCE = 15
MIN_VALIDATION_IMPROVEMENT = 1.0e-5

HIDDEN_WIDTH = 128
LATENT_WIDTH = 128
MLP_DEPTH = 3

GLOBAL_LOSS_WEIGHT = 0.5
EVENT_LOSS_WEIGHT = 0.5


# =====================================================================
# GENERAL UTILITIES
# =====================================================================

def find_project_root() -> Path:

    current = Path.cwd().resolve()

    for path in [current, *current.parents]:

        if (path / "step6_dataset" / "production_v1").is_dir():
            return path

    raise FileNotFoundError(
        "\nCould not locate the He-Xe PINO project root.\n"
        "Run this file from:\n"
        "D:/PHD/HeXe_Space_Reactor_PINO\n"
    )


def set_seed(seed: int) -> None:

    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def load_npy(folder: Path, filename: str):

    path = folder / filename

    if not path.exists():
        raise FileNotFoundError(
            f"\nRequired file not found:\n{path}"
        )

    return np.load(path, mmap_mode="r")


def parameter_count(model):

    return sum(
        p.numel()
        for p in model.parameters()
        if p.requires_grad
    )


# =====================================================================
# TRAIN-ONLY NORMALIZATION
# =====================================================================

def calculate_train_normalization(
    global_rho,
    global_state,
):

    train_stop = PARTITIONS["TRAIN"][1]

    rho_train = np.asarray(
        global_rho[:train_stop],
        dtype=np.float64
    )

    state_train = np.asarray(
        global_state[:train_stop],
        dtype=np.float64
    )

    rho_mean = float(rho_train.mean())
    rho_std = float(rho_train.std())

    state_mean = state_train.mean(
        axis=(0, 1)
    )

    state_std = state_train.std(
        axis=(0, 1)
    )

    rho_std = max(rho_std, 1.0e-12)

    state_std = np.maximum(
        state_std,
        1.0e-12
    )

    return (
        rho_mean,
        rho_std,
        state_mean,
        state_std,
    )


# =====================================================================
# MLP
# =====================================================================

class MLP(nn.Module):

    def __init__(
        self,
        input_dim,
        hidden_dim,
        output_dim,
        depth,
    ):

        super().__init__()

        layers = []

        current_dim = input_dim

        for _ in range(depth):

            layers.append(
                nn.Linear(
                    current_dim,
                    hidden_dim
                )
            )

            layers.append(
                nn.Tanh()
            )

            current_dim = hidden_dim

        layers.append(
            nn.Linear(
                current_dim,
                output_dim
            )
        )

        self.network = nn.Sequential(
            *layers
        )

    def forward(self, x):

        return self.network(x)


# =====================================================================
# MODEL B
# =====================================================================

class ModelB(nn.Module):
    """
    Dual-Resolution Coordinate DeepONet.

    Global branch:
        601-point reactivity history

    Event branch:
        1021-point event-local reactivity history

    Trunks:
        normalized time coordinate

    Outputs:
        10 dynamic states
    """

    def __init__(self):

        super().__init__()

        # Global branch
        self.global_branch = MLP(
            GLOBAL_POINTS,
            HIDDEN_WIDTH,
            LATENT_WIDTH,
            MLP_DEPTH,
        )

        # Event branch
        self.event_branch = MLP(
            EVENT_POINTS,
            HIDDEN_WIDTH,
            LATENT_WIDTH,
            MLP_DEPTH,
        )

        # Global coordinate trunk
        self.global_trunk = MLP(
            1,
            HIDDEN_WIDTH,
            LATENT_WIDTH,
            MLP_DEPTH,
        )

        # Event coordinate trunk
        self.event_trunk = MLP(
            1,
            HIDDEN_WIDTH,
            LATENT_WIDTH,
            MLP_DEPTH,
        )

        # Output heads
        self.global_head = nn.Linear(
            LATENT_WIDTH,
            N_STATES
        )

        self.event_head = nn.Linear(
            LATENT_WIDTH,
            N_STATES
        )

        self.global_bias = nn.Parameter(
            torch.zeros(N_STATES)
        )

        self.event_bias = nn.Parameter(
            torch.zeros(N_STATES)
        )

    def decode(
        self,
        branch_latent,
        query,
        trunk,
        head,
        bias,
    ):

        # branch_latent:
        # [batch, latent]

        # query:
        # [batch, query_points, 1]

        trunk_output = trunk(query)

        branch_output = branch_latent.unsqueeze(1)

        latent_product = (
            branch_output *
            trunk_output
        )

        output = head(
            latent_product
        )

        return output + bias

    def forward_global(
        self,
        branch,
        query,
    ):

        latent = self.global_branch(
            branch
        )

        return self.decode(
            latent,
            query,
            self.global_trunk,
            self.global_head,
            self.global_bias,
        )

    def forward_event(
        self,
        branch,
        query,
    ):

        latent = self.event_branch(
            branch
        )

        return self.decode(
            latent,
            query,
            self.event_trunk,
            self.event_head,
            self.event_bias,
        )


# =====================================================================
# TIME NORMALIZATION
# =====================================================================

def normalize_time(time_array):

    time_array = np.asarray(
        time_array,
        dtype=np.float32
    )

    return (
        (time_array - time_array[0])
        /
        (time_array[-1] - time_array[0])
    )


# =====================================================================
# QUERY SAMPLING
# =====================================================================

def sample_global_queries(
    time_norm,
    number,
    generator,
):

    number = min(
        number,
        len(time_norm)
    )

    indices = torch.randperm(
        len(time_norm),
        generator=generator
    )[:number]

    indices = indices.sort().values

    return indices


def sample_event_queries(
    event_time_raw,
    number_fast,
    number_slow,
    generator,
):

    raw = np.asarray(
        event_time_raw,
        dtype=np.float64
    )

    fast_indices = np.flatnonzero(
        raw <= 0.010
    )

    slow_indices = np.flatnonzero(
        raw > 0.010
    )

    if (
        len(fast_indices) == 0
        or
        len(slow_indices) == 0
    ):

        all_indices = torch.randperm(
            len(raw),
            generator=generator
        )[
            :number_fast + number_slow
        ]

        return all_indices.sort().values

    number_fast = min(
        number_fast,
        len(fast_indices)
    )

    number_slow = min(
        number_slow,
        len(slow_indices)
    )

    fast_perm = torch.randperm(
        len(fast_indices),
        generator=generator
    )[:number_fast]

    slow_perm = torch.randperm(
        len(slow_indices),
        generator=generator
    )[:number_slow]

    fast_tensor = torch.as_tensor(
        fast_indices,
        dtype=torch.long
    )[fast_perm]

    slow_tensor = torch.as_tensor(
        slow_indices,
        dtype=torch.long
    )[slow_perm]

    indices = torch.cat(
        [
            fast_tensor,
            slow_tensor,
        ]
    )

    return indices.sort().values


# =====================================================================
# EVENT PARTITION MAPPING
# =====================================================================

def build_event_partition_mapping(
    step_case_indices
):

    mapping = {}

    for name, (
        start,
        stop
    ) in PARTITIONS.items():

        positions = np.flatnonzero(
            (
                step_case_indices >= start
            )
            &
            (
                step_case_indices < stop
            )
        )

        expected = EVENT_PARTITION_COUNTS[
            name
        ]

        if len(positions) != expected:

            raise RuntimeError(
                f"Event mapping error for {name}: "
                f"expected {expected}, "
                f"found {len(positions)}"
            )

        mapping[name] = positions

    return mapping


# =====================================================================
# VALIDATION / EVALUATION
# =====================================================================

@torch.no_grad()
def evaluate_partition(
    model,
    global_rho,
    global_state,
    event_rho,
    event_state,
    event_positions,
    global_time_norm,
    event_time_norm,
    case_start,
    case_stop,
    rho_mean,
    rho_std,
    state_mean,
    state_std,
    device,
):

    model.eval()

    # ---------------------------------------------------------------
    # GLOBAL
    # ---------------------------------------------------------------

    global_losses = []

    for start in range(
        case_start,
        case_stop,
        32,
    ):

        stop = min(
            start + 32,
            case_stop
        )

        indices = np.arange(
            start,
            stop,
            dtype=np.int64
        )

        rho = (
            np.asarray(
                global_rho[indices],
                dtype=np.float32
            )
            - rho_mean
        ) / rho_std

        target = (
            np.asarray(
                global_state[indices],
                dtype=np.float32
            )
            - state_mean
        ) / state_std

        rho_tensor = torch.from_numpy(
            rho
        ).to(device)

        target_tensor = torch.from_numpy(
            target
        ).to(device)

        query = (
            global_time_norm
            .view(1, -1, 1)
            .expand(
                len(indices),
                -1,
                -1
            )
        )

        prediction = model.forward_global(
            rho_tensor,
            query
        )

        loss = torch.mean(
            (
                prediction
                - target_tensor
            ) ** 2
        )

        global_losses.append(
            float(loss.item())
        )

    global_mse = float(
        np.mean(global_losses)
    )

    # ---------------------------------------------------------------
    # EVENT
    # ---------------------------------------------------------------

    event_mse = float("nan")

    if len(event_positions) > 0:

        event_losses = []

        for start in range(
            0,
            len(event_positions),
            32,
        ):

            positions = event_positions[
                start:start + 32
            ]

            rho = (
                np.asarray(
                    event_rho[positions],
                    dtype=np.float32
                )
                - rho_mean
            ) / rho_std

            target = (
                np.asarray(
                    event_state[positions],
                    dtype=np.float32
                )
                - state_mean
            ) / state_std

            rho_tensor = torch.from_numpy(
                rho
            ).to(device)

            target_tensor = torch.from_numpy(
                target
            ).to(device)

            query = (
                event_time_norm
                .view(1, -1, 1)
                .expand(
                    len(positions),
                    -1,
                    -1
                )
            )

            prediction = model.forward_event(
                rho_tensor,
                query
            )

            loss = torch.mean(
                (
                    prediction
                    - target_tensor
                ) ** 2
            )

            event_losses.append(
                float(loss.item())
            )

        event_mse = float(
            np.mean(event_losses)
        )

    if math.isfinite(event_mse):

        combined = (
            GLOBAL_LOSS_WEIGHT
            * global_mse
            +
            EVENT_LOSS_WEIGHT
            * event_mse
        )

    else:

        combined = global_mse

    return {
        "global_mse": global_mse,
        "event_mse": event_mse,
        "combined_mse": combined,
        "normalized_rmse": math.sqrt(
            combined
        ),
    }


# =====================================================================
# MAIN
# =====================================================================

def main():

    set_seed(SEED)

    root = find_project_root()

    production = (
        root
        / "step6_dataset"
        / "production_v1"
    )

    output_dir = (
        root
        / "step7_pino"
        / "model_b_training"
    )

    output_dir.mkdir(
        parents=True,
        exist_ok=True
    )

    print("=" * 78)
    print(
        "STEP 7 MODEL-B "
        "DUAL-RESOLUTION DEEPONET TRAINING"
    )
    print("=" * 78)

    print(
        f"Project root : {root}"
    )

    print(
        f"Dataset      : {production}"
    )

    # ---------------------------------------------------------------
    # DEVICE
    # ---------------------------------------------------------------

    device = torch.device(
        "cuda"
        if torch.cuda.is_available()
        else "cpu"
    )

    print(
        f"Device       : {device}"
    )

    if device.type == "cuda":

        print(
            "GPU          : "
            + torch.cuda.get_device_name(0)
        )

        free_memory, total_memory = (
            torch.cuda.mem_get_info()
        )

        print(
            f"GPU memory   : "
            f"{free_memory / 1024**3:.2f} GiB free / "
            f"{total_memory / 1024**3:.2f} GiB total"
        )

    print()

    # ---------------------------------------------------------------
    # LOAD DATA
    # ---------------------------------------------------------------

    print(
        "LOADING FROZEN PRODUCTION-V1 DATASET"
    )

    print("-" * 78)

    global_time = load_npy(
        production,
        "global_time_s.npy"
    )

    global_rho = load_npy(
        production,
        "global_reactivity_delta_k_over_k.npy"
    )

    global_state = load_npy(
        production,
        "global_state.npy"
    )

    event_time = load_npy(
        production,
        "step_event_relative_time_s.npy"
    )

    event_rho = load_npy(
        production,
        "step_event_reactivity_delta_k_over_k.npy"
    )

    event_state = load_npy(
        production,
        "step_event_state.npy"
    )

    step_case_indices = np.asarray(
        load_npy(
            production,
            "step_case_indices.npy"
        ),
        dtype=np.int64
    )

    state_names = [
        str(x)
        for x in np.asarray(
            load_npy(
                production,
                "state_names.npy"
            )
        ).tolist()
    ]

    print(
        f"Global rho       : "
        f"{global_rho.shape}"
    )

    print(
        f"Global state     : "
        f"{global_state.shape}"
    )

    print(
        f"Event rho        : "
        f"{event_rho.shape}"
    )

    print(
        f"Event state      : "
        f"{event_state.shape}"
    )

    # ---------------------------------------------------------------
    # HARD SHAPE CHECKS
    # ---------------------------------------------------------------

    assert global_rho.shape == (
        TOTAL_CASES,
        GLOBAL_POINTS
    )

    assert global_state.shape == (
        TOTAL_CASES,
        GLOBAL_POINTS,
        N_STATES
    )

    assert event_rho.shape == (
        EVENT_CASES,
        EVENT_POINTS
    )

    assert event_state.shape == (
        EVENT_CASES,
        EVENT_POINTS,
        N_STATES
    )

    assert len(step_case_indices) == (
        EVENT_CASES
    )

    print(
        "Dataset shape checks : PASS"
    )

    # ---------------------------------------------------------------
    # EVENT PARTITIONS
    # ---------------------------------------------------------------

    event_mapping = (
        build_event_partition_mapping(
            step_case_indices
        )
    )

    print()
    print(
        "PARTITION MAPPING"
    )

    print("-" * 78)

    for name, (
        start,
        stop
    ) in PARTITIONS.items():

        print(
            f"{name:<14} "
            f"global={stop-start:<4} "
            f"event={len(event_mapping[name])}"
        )

    # ---------------------------------------------------------------
    # TRAIN NORMALIZATION
    # ---------------------------------------------------------------

    (
        rho_mean,
        rho_std,
        state_mean,
        state_std,
    ) = calculate_train_normalization(
        global_rho,
        global_state,
    )

    print()
    print(
        "TRAIN-ONLY NORMALIZATION"
    )

    print("-" * 78)

    print(
        f"Reactivity mean : "
        f"{rho_mean:.16e}"
    )

    print(
        f"Reactivity std  : "
        f"{rho_std:.16e}"
    )

    print(
        "State means     :"
    )

    print(state_mean)

    print(
        "State stds      :"
    )

    print(state_std)

    # ---------------------------------------------------------------
    # TIME COORDINATES
    # ---------------------------------------------------------------

    global_time_np = np.asarray(
        global_time,
        dtype=np.float32
    )

    event_time_np = np.asarray(
        event_time,
        dtype=np.float32
    )

    global_time_norm_np = normalize_time(
        global_time_np
    )

    event_time_norm_np = normalize_time(
        event_time_np
    )

    global_time_norm = torch.from_numpy(
        global_time_norm_np
    ).to(device)

    event_time_norm = torch.from_numpy(
        event_time_norm_np
    ).to(device)

    print()
    print(
        "TIME COORDINATES"
    )

    print("-" * 78)

    print(
        f"Global time : "
        f"{global_time_np[0]} "
        f"to {global_time_np[-1]} s"
    )

    print(
        f"Event time  : "
        f"{event_time_np[0]} "
        f"to {event_time_np[-1]} s"
    )

    # ---------------------------------------------------------------
    # MODEL
    # ---------------------------------------------------------------

    model = ModelB().to(device)

    number_parameters = parameter_count(
        model
    )

    print()
    print(
        "MODEL-B ARCHITECTURE"
    )

    print("-" * 78)

    print(
        "Architecture : "
        "Dual-Resolution Coordinate DeepONet"
    )

    print(
        f"Hidden width : {HIDDEN_WIDTH}"
    )

    print(
        f"Latent width : {LATENT_WIDTH}"
    )

    print(
        f"MLP depth    : {MLP_DEPTH}"
    )

    print(
        f"Parameters   : "
        f"{number_parameters:,}"
    )

    # ---------------------------------------------------------------
    # OPTIMIZER
    # ---------------------------------------------------------------

    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=LEARNING_RATE,
        weight_decay=WEIGHT_DECAY
    )

    loss_function = nn.MSELoss()

    query_generator = torch.Generator(
        device="cpu"
    )

    query_generator.manual_seed(
        SEED + 1
    )

    numpy_rng = np.random.default_rng(
        SEED + 2
    )

    # ---------------------------------------------------------------
    # TRAINING DATA
    # ---------------------------------------------------------------

    train_global_indices = np.arange(
        PARTITIONS["TRAIN"][0],
        PARTITIONS["TRAIN"][1],
        dtype=np.int64
    )

    train_event_positions = (
        event_mapping["TRAIN"]
    )

    # ---------------------------------------------------------------
    # TRAINING LOOP
    # ---------------------------------------------------------------

    print()
    print(
        "TRAINING MODEL-B"
    )

    print("-" * 78)

    print(
        f"Maximum epochs     : {MAX_EPOCHS}"
    )

    print(
        f"Batch size         : {BATCH_SIZE}"
    )

    print(
        f"Global queries     : "
        f"{GLOBAL_QUERY_POINTS}"
    )

    print(
        f"Event queries      : "
        f"{EVENT_FAST_QUERY_POINTS + EVENT_SLOW_QUERY_POINTS}"
    )

    print(
        f"Learning rate      : "
        f"{LEARNING_RATE}"
    )

    print(
        f"Early-stop patience: "
        f"{EARLY_STOPPING_PATIENCE}"
    )

    print()

    best_validation = float(
        "inf"
    )

    best_epoch = 0

    patience_counter = 0

    history = []

    training_start = time.perf_counter()

    # ---------------------------------------------------------------
    # EPOCHS
    # ---------------------------------------------------------------

    for epoch in range(
        1,
        MAX_EPOCHS + 1
    ):

        epoch_start = time.perf_counter()

        model.train()

        # ===========================================================
        # GLOBAL TRAINING
        # ===========================================================

        shuffled_global = (
            numpy_rng.permutation(
                train_global_indices
            )
        )

        global_losses = []

        for start in range(
            0,
            len(shuffled_global),
            BATCH_SIZE
        ):

            indices = shuffled_global[
                start:start + BATCH_SIZE
            ]

            query_indices = (
                sample_global_queries(
                    global_time_norm,
                    GLOBAL_QUERY_POINTS,
                    query_generator
                )
            )

            branch = (
                np.asarray(
                    global_rho[indices],
                    dtype=np.float32
                )
                - rho_mean
            ) / rho_std

            target_full = (
                np.asarray(
                    global_state[indices],
                    dtype=np.float32
                )
                - state_mean
            ) / state_std

            target = target_full[
                :,
                query_indices.numpy(),
                :
            ]

            branch_tensor = (
                torch.from_numpy(
                    branch
                ).to(device)
            )

            target_tensor = (
                torch.from_numpy(
                    target
                ).to(device)
            )

            query_tensor = (
                global_time_norm[
                    query_indices
                ]
                .view(1, -1, 1)
                .expand(
                    len(indices),
                    -1,
                    -1
                )
            )

            prediction = (
                model.forward_global(
                    branch_tensor,
                    query_tensor
                )
            )

            loss = loss_function(
                prediction,
                target_tensor
            )

            optimizer.zero_grad(
                set_to_none=True
            )

            loss.backward()

            torch.nn.utils.clip_grad_norm_(
                model.parameters(),
                GRADIENT_CLIP
            )

            optimizer.step()

            global_losses.append(
                float(loss.item())
            )

        # ===========================================================
        # EVENT TRAINING
        # ===========================================================

        shuffled_event = (
            numpy_rng.permutation(
                train_event_positions
            )
        )

        event_losses = []

        for start in range(
            0,
            len(shuffled_event),
            BATCH_SIZE
        ):

            positions = shuffled_event[
                start:start + BATCH_SIZE
            ]

            query_indices = (
                sample_event_queries(
                    event_time_np,
                    EVENT_FAST_QUERY_POINTS,
                    EVENT_SLOW_QUERY_POINTS,
                    query_generator
                )
            )

            branch = (
                np.asarray(
                    event_rho[positions],
                    dtype=np.float32
                )
                - rho_mean
            ) / rho_std

            target_full = (
                np.asarray(
                    event_state[positions],
                    dtype=np.float32
                )
                - state_mean
            ) / state_std

            target = target_full[
                :,
                query_indices.numpy(),
                :
            ]

            branch_tensor = (
                torch.from_numpy(
                    branch
                ).to(device)
            )

            target_tensor = (
                torch.from_numpy(
                    target
                ).to(device)
            )

            query_tensor = (
                event_time_norm[
                    query_indices
                ]
                .view(1, -1, 1)
                .expand(
                    len(positions),
                    -1,
                    -1
                )
            )

            prediction = (
                model.forward_event(
                    branch_tensor,
                    query_tensor
                )
            )

            loss = loss_function(
                prediction,
                target_tensor
            )

            optimizer.zero_grad(
                set_to_none=True
            )

            loss.backward()

            torch.nn.utils.clip_grad_norm_(
                model.parameters(),
                GRADIENT_CLIP
            )

            optimizer.step()

            event_losses.append(
                float(loss.item())
            )

        # ===========================================================
        # VALIDATION
        # ===========================================================

        validation = evaluate_partition(
            model,
            global_rho,
            global_state,
            event_rho,
            event_state,
            event_mapping["VALIDATION"],
            global_time_norm,
            event_time_norm,
            PARTITIONS["VALIDATION"][0],
            PARTITIONS["VALIDATION"][1],
            rho_mean,
            rho_std,
            state_mean,
            state_std,
            device,
        )

        train_global_mse = float(
            np.mean(global_losses)
        )

        train_event_mse = float(
            np.mean(event_losses)
        )

        train_combined = (
            GLOBAL_LOSS_WEIGHT
            * train_global_mse
            +
            EVENT_LOSS_WEIGHT
            * train_event_mse
        )

        epoch_seconds = (
            time.perf_counter()
            - epoch_start
        )

        record = {
            "epoch": epoch,
            "train_global_mse": train_global_mse,
            "train_event_mse": train_event_mse,
            "train_combined_mse": train_combined,
            "validation_global_mse":
                validation["global_mse"],
            "validation_event_mse":
                validation["event_mse"],
            "validation_combined_mse":
                validation["combined_mse"],
            "validation_normalized_rmse":
                validation["normalized_rmse"],
            "epoch_seconds":
                epoch_seconds,
        }

        history.append(record)

        # ===========================================================
        # CHECKPOINT
        # ===========================================================

        improved = (
            validation["combined_mse"]
            <
            best_validation
            - MIN_VALIDATION_IMPROVEMENT
        )

        if improved:

            best_validation = (
                validation["combined_mse"]
            )

            best_epoch = epoch

            patience_counter = 0

            checkpoint = {

                "model_state_dict":
                    model.state_dict(),

                "optimizer_state_dict":
                    optimizer.state_dict(),

                "epoch":
                    epoch,

                "best_validation_mse":
                    best_validation,

                "normalization": {

                    "rho_mean":
                        rho_mean,

                    "rho_std":
                        rho_std,

                    "state_mean":
                        state_mean,

                    "state_std":
                        state_std,
                },

                "architecture": {

                    "name":
                        "Model-B Dual-Resolution Coordinate DeepONet",

                    "hidden_width":
                        HIDDEN_WIDTH,

                    "latent_width":
                        LATENT_WIDTH,

                    "depth":
                        MLP_DEPTH,

                    "parameters":
                        number_parameters,
                },

                "seed":
                    SEED,
            }

            torch.save(
                checkpoint,
                output_dir
                / "model_b_best.pt"
            )

        else:

            patience_counter += 1

        print(
            f"Epoch {epoch:03d} | "
            f"Train={train_combined:.6e} | "
            f"Val={validation['combined_mse']:.6e} | "
            f"ValRMSE={validation['normalized_rmse']:.6e} | "
            f"Patience={patience_counter:02d} | "
            f"Time={epoch_seconds:.1f}s"
        )

        if (
            patience_counter
            >= EARLY_STOPPING_PATIENCE
        ):

            print()

            print(
                f"EARLY STOPPING at epoch "
                f"{epoch}"
            )

            break

    total_training_seconds = (
        time.perf_counter()
        - training_start
    )

    # =================================================================
    # LOAD BEST CHECKPOINT
    # =================================================================

    checkpoint_path = (
        output_dir
        / "model_b_best.pt"
    )

    if not checkpoint_path.exists():

        raise RuntimeError(
            "No best Model-B checkpoint "
            "was created."
        )

    checkpoint = torch.load(
        checkpoint_path,
        map_location=device,
        weights_only=False,
    )

    model.load_state_dict(
        checkpoint[
            "model_state_dict"
        ]
    )

    # =================================================================
    # POST-TRAINING EVALUATION
    # =================================================================

    print()
    print(
        "POST-TRAINING EVALUATION"
    )

    print("-" * 78)

    evaluations = {}

    for name in [
        "TRAIN",
        "VALIDATION",
        "ID_TEST",
        "OOD_NEG_TEST",
        "OOD_POS_TEST",
        "STRESS_TEST",
    ]:

        start, stop = PARTITIONS[
            name
        ]

        result = evaluate_partition(
            model,
            global_rho,
            global_state,
            event_rho,
            event_state,
            event_mapping[name],
            global_time_norm,
            event_time_norm,
            start,
            stop,
            rho_mean,
            rho_std,
            state_mean,
            state_std,
            device,
        )

        evaluations[name] = result

        print(
            f"{name:<14} "
            f"Global={result['global_mse']:.6e} "
            f"Event={result['event_mse']:.6e} "
            f"Combined={result['combined_mse']:.6e} "
            f"RMSE={result['normalized_rmse']:.6e}"
        )

    # =================================================================
    # SAVE TRAINING HISTORY
    # =================================================================

    history_path = (
        output_dir
        / "training_history.json"
    )

    history_path.write_text(
        json.dumps(
            history,
            indent=2
        ),
        encoding="utf-8"
    )

    # =================================================================
    # SAVE RESULTS
    # =================================================================

    results = {

        "script":
            "191_step7_model_b_training.py",

        "status":
            "TRAINING_COMPLETE",

        "seed":
            SEED,

        "device":
            str(device),

        "gpu":
            (
                torch.cuda.get_device_name(0)
                if device.type == "cuda"
                else None
            ),

        "dataset": {

            "production_cases":
                TOTAL_CASES,

            "global_shape":
                list(global_state.shape),

            "event_shape":
                list(event_state.shape),

            "global_time_s":
                [
                    float(global_time_np[0]),
                    float(global_time_np[-1]),
                ],

            "event_time_s":
                [
                    float(event_time_np[0]),
                    float(event_time_np[-1]),
                ],
        },

        "partitions": {
            name:
                stop - start
            for name, (
                start,
                stop
            ) in PARTITIONS.items()
        },

        "event_partition_counts":
            EVENT_PARTITION_COUNTS,

        "normalization": {

            "source":
                "TRAIN only",

            "rho_mean":
                rho_mean,

            "rho_std":
                rho_std,

            "state_mean":
                state_mean.tolist(),

            "state_std":
                state_std.tolist(),

            "state_names":
                state_names,
        },

        "model": {

            "name":
                "Model-B Dual-Resolution Coordinate DeepONet",

            "hidden_width":
                HIDDEN_WIDTH,

            "latent_width":
                LATENT_WIDTH,

            "depth":
                MLP_DEPTH,

            "trainable_parameters":
                number_parameters,
        },

        "training": {

            "max_epochs":
                MAX_EPOCHS,

            "completed_epochs":
                len(history),

            "best_epoch":
                best_epoch,

            "best_validation_combined_mse":
                best_validation,

            "batch_size":
                BATCH_SIZE,

            "global_query_points":
                GLOBAL_QUERY_POINTS,

            "event_fast_query_points":
                EVENT_FAST_QUERY_POINTS,

            "event_slow_query_points":
                EVENT_SLOW_QUERY_POINTS,

            "learning_rate":
                LEARNING_RATE,

            "weight_decay":
                WEIGHT_DECAY,

            "gradient_clip":
                GRADIENT_CLIP,

            "early_stopping_patience":
                EARLY_STOPPING_PATIENCE,

            "global_loss_weight":
                GLOBAL_LOSS_WEIGHT,

            "event_loss_weight":
                EVENT_LOSS_WEIGHT,

            "physics_loss":
                False,

            "training_seconds":
                total_training_seconds,
        },

        "evaluations":
            evaluations,

        "scientific_usage": {

            "validation_used_for_early_stopping":
                True,

            "id_test_used_for_tuning":
                False,

            "ood_negative_used_for_tuning":
                False,

            "ood_positive_used_for_tuning":
                False,

            "stress_used_for_tuning":
                False,

            "dataset_modified":
                False,

            "physics_loss":
                False,
        },

        "environment": {

            "python":
                platform.python_version(),

            "torch":
                torch.__version__,

            "platform":
                platform.platform(),
        },
    }

    results_path = (
        output_dir
        / "training_results.json"
    )

    results_path.write_text(
        json.dumps(
            results,
            indent=2
        ),
        encoding="utf-8"
    )

    # =================================================================
    # TEXT REPORT
    # =================================================================

    report = []

    report.append(
        "=" * 78
    )

    report.append(
        "STEP 7 MODEL-B TRAINING REPORT"
    )

    report.append(
        "=" * 78
    )

    report.append("")

    report.append(
        f"Device              : {device}"
    )

    report.append(
        "Model               : "
        "Model-B Dual-Resolution Coordinate DeepONet"
    )

    report.append(
        f"Parameters           : "
        f"{number_parameters:,}"
    )

    report.append(
        f"Completed epochs     : "
        f"{len(history)}"
    )

    report.append(
        f"Best epoch           : "
        f"{best_epoch}"
    )

    report.append(
        f"Best validation MSE  : "
        f"{best_validation:.10e}"
    )

    report.append(
        f"Training time        : "
        f"{total_training_seconds:.2f} s"
    )

    report.append("")

    report.append(
        "POST-TRAINING METRICS"
    )

    report.append(
        "-" * 78
    )

    for name, result in evaluations.items():

        report.append(
            f"{name:<14} "
            f"global={result['global_mse']:.10e} "
            f"event={result['event_mse']:.10e} "
            f"combined={result['combined_mse']:.10e} "
            f"rmse={result['normalized_rmse']:.10e}"
        )

    report.append("")

    report.append(
        "NORMALIZATION : TRAIN ONLY"
    )

    report.append(
        "PHYSICS LOSS  : NONE"
    )

    report.append(
        "TEST/OOD TUNING : NO"
    )

    report.append(
        "DATASET MODIFIED : NO"
    )

    report.append("")

    report.append(
        f"Checkpoint : {checkpoint_path}"
    )

    report.append(
        f"Results    : {results_path}"
    )

    report.append(
        f"History    : {history_path}"
    )

    report.append("")

    report.append(
        "STATUS: MODEL-B TRAINING COMPLETE"
    )

    report_path = (
        output_dir
        / "training_report.txt"
    )

    report_path.write_text(
        "\n".join(report) + "\n",
        encoding="utf-8"
    )

    # =================================================================
    # FINAL
    # =================================================================

    print()

    print("=" * 78)

    print(
        "MODEL-B TRAINING COMPLETE"
    )

    print("=" * 78)

    print(
        f"Best epoch      : {best_epoch}"
    )

    print(
        f"Best validation : "
        f"{best_validation:.10e}"
    )

    print(
        f"Checkpoint      : "
        f"{checkpoint_path}"
    )

    print(
        f"Results         : "
        f"{results_path}"
    )

    print(
        f"Report          : "
        f"{report_path}"
    )

    print()

    print(
        "STATUS: MODEL-B TRAINING COMPLETE"
    )


# =====================================================================
# ENTRY POINT
# =====================================================================

if __name__ == "__main__":
    main()