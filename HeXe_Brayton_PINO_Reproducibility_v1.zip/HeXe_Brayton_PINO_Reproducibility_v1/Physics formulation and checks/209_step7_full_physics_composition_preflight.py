#!/usr/bin/env python3
"""
209_step7_full_physics_composition_preflight.py

NO TRAINING. NO TUNING. NO ID/OOD/STRESS ACCESS. NO DATASET MODIFICATION.

Freezes only the full-physics composition contract:
    L_K = mean(7 normalized kinetics equation MSEs)
    L_T = mean(3 normalized thermal equation MSEs)
    L_physics = 0.5*L_K + 0.5*L_T

A naive mean across all ten equations is audited but rejected because it gives
70% structural weight to kinetics and 30% to thermal solely from equation count.
The final full-PINO lambda is not frozen here.
"""
from __future__ import annotations

import importlib.util
import json
import math
import sys
from pathlib import Path

import numpy as np
import torch

SEED = 20262090
PROBE_BATCH_SIZE = 4
TRAIN_PROBE_BATCHES = 12
VALIDATION_PROBE_BATCHES = 8
KINETICS_FAMILY_WEIGHT = 0.5
THERMAL_FAMILY_WEIGHT = 0.5
EPS = 1.0e-30

EXPECTED_KINETICS_NAMES = [
    "power_kinetics", "precursor_1", "precursor_2", "precursor_3",
    "precursor_4", "precursor_5", "precursor_6",
]
EXPECTED_THERMAL_NAMES = [
    "fuel_temperature", "block_temperature", "bulk_coolant_temperature",
]


def find_root() -> Path:
    current = Path.cwd().resolve()
    for path in [current, *current.parents]:
        if (path / "step6_dataset" / "production_v1").is_dir():
            return path
    raise FileNotFoundError("Could not locate He-Xe PINO project root.")


def require_file(path: Path) -> Path:
    if not path.exists():
        raise FileNotFoundError(path)
    return path


def load_module(name: str, path: Path):
    path = require_file(path)
    spec = importlib.util.spec_from_file_location(name, str(path))
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not import:\n{path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def serializable(value):
    if isinstance(value, dict):
        return {k: serializable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [serializable(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.floating):
        return float(value)
    if isinstance(value, np.integer):
        return int(value)
    return value


def normalization_match(reference, candidate) -> bool:
    if candidate is None:
        return True

    keys = ["rho_mean", "rho_std", "state_mean", "state_std"]

    if not all(k in candidate for k in keys):
        return False

    return bool(
        math.isclose(
            float(reference["rho_mean"]),
            float(candidate["rho_mean"]),
            rel_tol=1.0e-12,
            abs_tol=1.0e-15,
        )
        and math.isclose(
            float(reference["rho_std"]),
            float(candidate["rho_std"]),
            rel_tol=1.0e-12,
            abs_tol=1.0e-15,
        )
        and np.allclose(
            np.asarray(reference["state_mean"], dtype=np.float64),
            np.asarray(candidate["state_mean"], dtype=np.float64),
            rtol=1.0e-12,
            atol=1.0e-12,
        )
        and np.allclose(
            np.asarray(reference["state_std"], dtype=np.float64),
            np.asarray(candidate["state_std"], dtype=np.float64),
            rtol=1.0e-12,
            atol=1.0e-12,
        )
    )


def data_mse_batch(
    model,
    forward_method,
    branch_array,
    state_array,
    selected_cases,
    query_indices,
    normalized_time,
    rho_mean,
    rho_std,
    state_mean,
    state_std,
    device,
):
    cases = np.asarray(selected_cases, dtype=np.int64)
    qidx = np.asarray(query_indices, dtype=np.int64)

    raw_branch = np.asarray(
        branch_array[cases],
        dtype=np.float32,
    )

    branch = (
        raw_branch
        - np.float32(rho_mean)
    ) / np.float32(rho_std)

    target = np.asarray(
        state_array[cases][:, qidx, :],
        dtype=np.float32,
    )

    target = (
        target
        - np.asarray(state_mean, dtype=np.float32)
    ) / np.asarray(state_std, dtype=np.float32)

    branch_t = torch.as_tensor(
        branch,
        dtype=torch.float32,
        device=device,
    )

    target_t = torch.as_tensor(
        target,
        dtype=torch.float32,
        device=device,
    )

    q = torch.as_tensor(
        np.asarray(
            normalized_time[qidx],
            dtype=np.float32,
        ),
        dtype=torch.float32,
        device=device,
    )

    q = (
        q.view(1, -1, 1)
        .expand(len(cases), -1, -1)
    )

    with torch.no_grad():
        pred = forward_method(
            branch_t,
            q,
        )

        loss = torch.mean(
            (pred - target_t) ** 2
        )

    return float(
        loss.detach().cpu()
    )


def probe_representation_batch(
    *,
    model,
    forward_method,
    branch_array,
    state_array,
    selected_cases,
    query_indices,
    normalized_time,
    horizon_seconds,
    rho_mean,
    rho_std,
    state_mean,
    state_std,
    state_mean_t,
    state_std_t,
    kinetics_scales_t,
    thermal_scales_t,
    beta_t,
    lambdas_t,
    generation_time,
    fuel_coeff_t,
    block_coeff_t,
    fuel_reference,
    block_reference,
    file196,
    file204,
    file208,
    file74,
    file206,
    thermal_model,
    device,
):
    data_loss = data_mse_batch(
        model,
        forward_method,
        branch_array,
        state_array,
        selected_cases,
        query_indices,
        normalized_time,
        rho_mean,
        rho_std,
        state_mean,
        state_std,
        device,
    )

    kinetics = file204.coupled_residual_batch(
        model=model,
        forward_method=forward_method,
        branch_array=branch_array,
        selected_cases=selected_cases,
        query_indices=query_indices,
        normalized_time=normalized_time,
        horizon_seconds=horizon_seconds,
        rho_mean=rho_mean,
        rho_std=rho_std,
        state_mean_t=state_mean_t,
        state_std_t=state_std_t,
        physics_scales_t=kinetics_scales_t,
        beta_t=beta_t,
        lambdas_t=lambdas_t,
        generation_time=generation_time,
        fuel_coeff_t=fuel_coeff_t,
        block_coeff_t=block_coeff_t,
        fuel_reference=fuel_reference,
        block_reference=block_reference,
        file196=file196,
        device=device,
    )

    thermal = file208.thermal_residual_batch(
        model=model,
        forward_method=forward_method,
        branch_array=branch_array,
        selected_cases=selected_cases,
        query_indices=query_indices,
        normalized_time=normalized_time,
        horizon_seconds=horizon_seconds,
        rho_mean=rho_mean,
        rho_std=rho_std,
        state_mean_t=state_mean_t,
        state_std_t=state_std_t,
        thermal_scale_t=thermal_scales_t,
        file74=file74,
        file206=file206,
        thermal_model=thermal_model,
        device=device,
    )

    k_eq = np.asarray(
        kinetics["equation_mse"],
        dtype=np.float64,
    )

    t_eq = np.asarray(
        thermal["equation_mse"],
        dtype=np.float64,
    )

    if k_eq.shape != (7,):
        raise RuntimeError(
            f"Unexpected kinetics residual shape: {k_eq.shape}"
        )

    if t_eq.shape != (3,):
        raise RuntimeError(
            f"Unexpected thermal residual shape: {t_eq.shape}"
        )

    return {
        "data_loss":
            data_loss,

        "kinetics_loss":
            float(
                kinetics["coupled_mse"]
            ),

        "thermal_loss":
            float(
                thermal["thermal_mse"]
            ),

        "kinetics_equation_mse":
            k_eq,

        "thermal_equation_mse":
            t_eq,
    }


def summarize_rows(rows):
    return {
        "data_loss":
            float(
                np.mean(
                    [
                        row["data_loss"]
                        for row in rows
                    ]
                )
            ),

        "kinetics_loss":
            float(
                np.mean(
                    [
                        row["kinetics_loss"]
                        for row in rows
                    ]
                )
            ),

        "thermal_loss":
            float(
                np.mean(
                    [
                        row["thermal_loss"]
                        for row in rows
                    ]
                )
            ),

        "kinetics_equation_mse":
            np.mean(
                np.stack(
                    [
                        row["kinetics_equation_mse"]
                        for row in rows
                    ]
                ),
                axis=0,
            ),

        "thermal_equation_mse":
            np.mean(
                np.stack(
                    [
                        row["thermal_equation_mse"]
                        for row in rows
                    ]
                ),
                axis=0,
            ),
    }


def probe_partition(
    *,
    model,
    partition,
    seed,
    number_batches,
    file191,
    file196,
    file204,
    file208,
    file74,
    file206,
    thermal_model,
    global_rho,
    global_state,
    event_rho,
    event_state,
    event_mapping,
    global_time,
    event_time,
    global_time_norm,
    event_time_norm,
    rho_mean,
    rho_std,
    state_mean,
    state_std,
    state_mean_t,
    state_std_t,
    kinetics_scales_t,
    thermal_scales_t,
    beta_t,
    lambdas_t,
    generation_time,
    fuel_coeff_t,
    block_coeff_t,
    fuel_reference,
    block_reference,
    device,
):
    rng = np.random.default_rng(
        seed
    )

    start, stop = (
        file191.PARTITIONS[
            partition
        ]
    )

    global_available = np.arange(
        start,
        stop,
        dtype=np.int64,
    )

    event_available = np.asarray(
        event_mapping[
            partition
        ],
        dtype=np.int64,
    )

    global_rows = []
    event_rows = []

    for _ in range(
        number_batches
    ):
        g_cases = rng.choice(
            global_available,
            size=PROBE_BATCH_SIZE,
            replace=False,
        )

        g_q = file196.sample_global(
            total_points=file191.GLOBAL_POINTS,
            number_points=file191.GLOBAL_QUERY_POINTS,
            rng=rng,
        )

        global_rows.append(
            probe_representation_batch(
                model=model,
                forward_method=model.forward_global,
                branch_array=global_rho,
                state_array=global_state,
                selected_cases=g_cases,
                query_indices=g_q,
                normalized_time=global_time_norm,
                horizon_seconds=float(
                    global_time[-1]
                    - global_time[0]
                ),
                rho_mean=rho_mean,
                rho_std=rho_std,
                state_mean=state_mean,
                state_std=state_std,
                state_mean_t=state_mean_t,
                state_std_t=state_std_t,
                kinetics_scales_t=kinetics_scales_t,
                thermal_scales_t=thermal_scales_t,
                beta_t=beta_t,
                lambdas_t=lambdas_t,
                generation_time=generation_time,
                fuel_coeff_t=fuel_coeff_t,
                block_coeff_t=block_coeff_t,
                fuel_reference=fuel_reference,
                block_reference=block_reference,
                file196=file196,
                file204=file204,
                file208=file208,
                file74=file74,
                file206=file206,
                thermal_model=thermal_model,
                device=device,
            )
        )

        e_cases = rng.choice(
            event_available,
            size=PROBE_BATCH_SIZE,
            replace=False,
        )

        e_q = file196.sample_event(
            event_time=event_time,
            fast_number=file191.EVENT_FAST_QUERY_POINTS,
            slow_number=file191.EVENT_SLOW_QUERY_POINTS,
            rng=rng,
        )

        event_rows.append(
            probe_representation_batch(
                model=model,
                forward_method=model.forward_event,
                branch_array=event_rho,
                state_array=event_state,
                selected_cases=e_cases,
                query_indices=e_q,
                normalized_time=event_time_norm,
                horizon_seconds=float(
                    event_time[-1]
                    - event_time[0]
                ),
                rho_mean=rho_mean,
                rho_std=rho_std,
                state_mean=state_mean,
                state_std=state_std,
                state_mean_t=state_mean_t,
                state_std_t=state_std_t,
                kinetics_scales_t=kinetics_scales_t,
                thermal_scales_t=thermal_scales_t,
                beta_t=beta_t,
                lambdas_t=lambdas_t,
                generation_time=generation_time,
                fuel_coeff_t=fuel_coeff_t,
                block_coeff_t=block_coeff_t,
                fuel_reference=fuel_reference,
                block_reference=block_reference,
                file196=file196,
                file204=file204,
                file208=file208,
                file74=file74,
                file206=file206,
                thermal_model=thermal_model,
                device=device,
            )
        )

    global_result = summarize_rows(
        global_rows
    )

    event_result = summarize_rows(
        event_rows
    )

    wg = float(
        file191.GLOBAL_LOSS_WEIGHT
    )

    we = float(
        file191.EVENT_LOSS_WEIGHT
    )

    data = (
        wg
        * global_result["data_loss"]
        +
        we
        * event_result["data_loss"]
    )

    kinetics = (
        wg
        * global_result["kinetics_loss"]
        +
        we
        * event_result["kinetics_loss"]
    )

    thermal = (
        wg
        * global_result["thermal_loss"]
        +
        we
        * event_result["thermal_loss"]
    )

    kinetics_eq = (
        wg
        * global_result["kinetics_equation_mse"]
        +
        we
        * event_result["kinetics_equation_mse"]
    )

    thermal_eq = (
        wg
        * global_result["thermal_equation_mse"]
        +
        we
        * event_result["thermal_equation_mse"]
    )

    naive10 = float(
        np.mean(
            np.concatenate(
                [
                    kinetics_eq,
                    thermal_eq,
                ]
            )
        )
    )

    naive_formula = float(
        0.7
        * kinetics
        +
        0.3
        * thermal
    )

    balanced = float(
        KINETICS_FAMILY_WEIGHT
        * kinetics
        +
        THERMAL_FAMILY_WEIGHT
        * thermal
    )

    return {
        "partition":
            partition,

        "probe_batches":
            number_batches,

        "probe_batch_size":
            PROBE_BATCH_SIZE,

        "global":
            global_result,

        "event":
            event_result,

        "combined": {
            "data_loss":
                data,

            "kinetics_family_loss":
                kinetics,

            "thermal_family_loss":
                thermal,

            "kinetics_equation_mse":
                kinetics_eq,

            "thermal_equation_mse":
                thermal_eq,

            "naive_ten_equation_mean":
                naive10,

            "naive_formula_0p7K_plus_0p3T":
                naive_formula,

            "family_balanced_physics_loss":
                balanced,

            "naive_kinetics_contribution_share":
                0.7
                * kinetics
                / max(
                    naive_formula,
                    EPS,
                ),

            "naive_thermal_contribution_share":
                0.3
                * thermal
                / max(
                    naive_formula,
                    EPS,
                ),

            "balanced_kinetics_contribution_share":
                0.5
                * kinetics
                / max(
                    balanced,
                    EPS,
                ),

            "balanced_thermal_contribution_share":
                0.5
                * thermal
                / max(
                    balanced,
                    EPS,
                ),
        },

        "identity_audit": {
            "kinetics_mean_error":
                abs(
                    float(
                        np.mean(
                            kinetics_eq
                        )
                    )
                    - kinetics
                ),

            "thermal_mean_error":
                abs(
                    float(
                        np.mean(
                            thermal_eq
                        )
                    )
                    - thermal
                ),

            "naive_formula_error":
                abs(
                    naive10
                    - naive_formula
                ),
        },
    }


def main():
    root = find_root()

    production = (
        root
        / "step6_dataset"
        / "production_v1"
    )

    file191 = load_module(
        "file191_209",
        root
        / "191_step7_model_b_training.py",
    )

    file196 = load_module(
        "file196_209",
        root
        / "196_step7_kinetics_physics_preflight_gate.py",
    )

    file204 = load_module(
        "file204_209",
        root
        / "204_step7_coupled_kinetics_weight_gate.py",
    )

    file206 = load_module(
        "file206_209",
        root
        / "206_step7_exact_thermal_autograd_closure_audit.py",
    )

    file208 = load_module(
        "file208_209",
        root
        / "208_step7_thermal_only_weight_gate.py",
    )

    file70 = load_module(
        "file70_209",
        root
        / "70_reference_reactor_kinetics.py",
    )

    file74 = load_module(
        "file74_209",
        root
        / "74_master_coupled_reference_model.py",
    )

    file198_path = (
        root
        / "step7_pino"
        / "physics_informed"
        / "preflight"
        / "198_dimensionless_kinetics_residual_gate.json"
    )

    file206_json_path = (
        root
        / "step7_pino"
        / "physics_informed"
        / "thermal_preflight"
        / "206_exact_thermal_autograd_closure_audit.json"
    )

    file207_path = (
        root
        / "step7_pino"
        / "physics_informed"
        / "thermal_preflight"
        / "207_thermal_residual_normalization_gate.json"
    )

    base_checkpoint_path = (
        root
        / "step7_pino"
        / "model_b_training"
        / "model_b_best.pt"
    )

    control_checkpoint_path = (
        root
        / "step7_pino"
        / "physics_informed"
        / "power_lr_gate"
        / "lr_0p5_data_control_best.pt"
    )

    output_dir = (
        root
        / "step7_pino"
        / "physics_informed"
        / "full_physics_preflight"
    )

    output_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    output_json = (
        output_dir
        / "209_full_physics_composition_preflight.json"
    )

    output_txt = (
        output_dir
        / "209_full_physics_composition_preflight.txt"
    )

    print("=" * 78)
    print(
        "STEP 7 FULL-PHYSICS COMPOSITION PREFLIGHT GATE"
    )
    print("=" * 78)
    print(
        f"Project root : {root}"
    )
    print()

    file198 = json.loads(
        require_file(
            file198_path
        ).read_text(
            encoding="utf-8"
        )
    )

    file206_json = json.loads(
        require_file(
            file206_json_path
        ).read_text(
            encoding="utf-8"
        )
    )

    file207 = json.loads(
        require_file(
            file207_path
        ).read_text(
            encoding="utf-8"
        )
    )

    file198_pass = (
        file198.get(
            "status"
        )
        == "PASS"
    )

    file206_pass = (
        file206_json.get(
            "status"
        )
        ==
        "EXACT_NUMERICAL_AUTOGRAD_THERMAL_CLOSURE_VERIFIED"
    )

    file207_pass = (
        file207.get(
            "status"
        )
        ==
        "THERMAL_RESIDUAL_NORMALIZATION_READY"
    )

    if not file198_pass:
        raise RuntimeError(
            "File 198 has not passed."
        )

    if not file206_pass:
        raise RuntimeError(
            "File 206 exact thermal closure is not verified."
        )

    if not file207_pass:
        raise RuntimeError(
            "File 207 thermal normalization is not ready."
        )

    kinetics_names = list(
        file198[
            "residual_names"
        ]
    )

    thermal_names = list(
        file207[
            "normalization_contract"
        ][
            "equations"
        ]
    )

    equation_name_pass = (
        kinetics_names
        == EXPECTED_KINETICS_NAMES
        and
        thermal_names
        == EXPECTED_THERMAL_NAMES
    )

    kinetics_scales = np.asarray(
        file198[
            "physics_scales"
        ],
        dtype=np.float64,
    )

    thermal_scales = np.asarray(
        file207[
            "normalization_contract"
        ][
            "thermal_scales"
        ],
        dtype=np.float64,
    )

    scale_shape_pass = (
        kinetics_scales.shape
        == (7,)
        and
        thermal_scales.shape
        == (3,)
    )

    scale_finite_positive_pass = bool(
        np.all(
            np.isfinite(
                kinetics_scales
            )
        )
        and
        np.all(
            kinetics_scales > 0.0
        )
        and
        np.all(
            np.isfinite(
                thermal_scales
            )
        )
        and
        np.all(
            thermal_scales > 0.0
        )
    )

    if not equation_name_pass:
        raise RuntimeError(
            "Physics equation-name contract mismatch."
        )

    if not (
        scale_shape_pass
        and
        scale_finite_positive_pass
    ):
        raise RuntimeError(
            "Physics residual scales are invalid."
        )

    print(
        "PRIOR PHYSICS CONTRACTS"
    )
    print("-" * 78)

    print(
        "File 198 kinetics scaling : PASS"
    )

    print(
        "File 206 exact closure    : PASS"
    )

    print(
        "File 207 thermal scaling  : PASS"
    )

    print(
        "Equation-name audit       : PASS"
    )

    print(
        "Finite positive scales    : PASS"
    )

    print()

    n_k = len(
        kinetics_names
    )

    n_t = len(
        thermal_names
    )

    n_total = (
        n_k
        + n_t
    )

    naive_k_weight = (
        n_k
        / n_total
    )

    naive_t_weight = (
        n_t
        / n_total
    )

    family_balance_pass = (
        KINETICS_FAMILY_WEIGHT
        == 0.5
        and
        THERMAL_FAMILY_WEIGHT
        == 0.5
        and
        math.isclose(
            KINETICS_FAMILY_WEIGHT
            + THERMAL_FAMILY_WEIGHT,
            1.0,
            abs_tol=1.0e-15,
        )
    )

    print(
        "FAMILY-LEVEL COMPOSITION AUDIT"
    )

    print("-" * 78)

    print(
        f"Kinetics equations         : {n_k}"
    )

    print(
        f"Thermal equations          : {n_t}"
    )

    print(
        "Naive equation-mean weights: "
        f"K={naive_k_weight:.3f}, "
        f"T={naive_t_weight:.3f}"
    )

    print(
        "Frozen family weights       : "
        "K=0.500, T=0.500"
    )

    print(
        "Decision                    : "
        "FAMILY-BALANCED 0.5 / 0.5"
    )

    print()

    device = torch.device(
        "cuda"
        if torch.cuda.is_available()
        else "cpu"
    )

    print(
        f"Device : {device}"
    )

    if device.type == "cuda":
        print(
            "GPU    : "
            + torch.cuda.get_device_name(
                0
            )
        )

    print()

    global_time = np.asarray(
        file191.load_npy(
            production,
            "global_time_s.npy",
        ),
        dtype=np.float32,
    )

    global_rho = file191.load_npy(
        production,
        "global_reactivity_delta_k_over_k.npy",
    )

    global_state = file191.load_npy(
        production,
        "global_state.npy",
    )

    event_time = np.asarray(
        file191.load_npy(
            production,
            "step_event_relative_time_s.npy",
        ),
        dtype=np.float32,
    )

    event_rho = file191.load_npy(
        production,
        "step_event_reactivity_delta_k_over_k.npy",
    )

    event_state = file191.load_npy(
        production,
        "step_event_state.npy",
    )

    step_case_indices = np.asarray(
        file191.load_npy(
            production,
            "step_case_indices.npy",
        ),
        dtype=np.int64,
    )

    event_mapping = (
        file191
        .build_event_partition_mapping(
            step_case_indices
        )
    )

    global_time_norm = (
        file191
        .normalize_time(
            global_time
        )
    )

    event_time_norm = (
        file191
        .normalize_time(
            event_time
        )
    )

    base_checkpoint = torch.load(
        require_file(
            base_checkpoint_path
        ),
        map_location="cpu",
        weights_only=False,
    )

    control_checkpoint = torch.load(
        require_file(
            control_checkpoint_path
        ),
        map_location="cpu",
        weights_only=False,
    )

    normalization = (
        base_checkpoint[
            "normalization"
        ]
    )

    control_normalization = (
        control_checkpoint.get(
            "normalization"
        )
    )

    control_normalization_match = (
        normalization_match(
            normalization,
            control_normalization,
        )
    )

    if (
        control_normalization
        is not None
        and
        not control_normalization_match
    ):
        raise RuntimeError(
            "Matched-control normalization differs "
            "from Model-B normalization."
        )

    rho_mean = float(
        normalization[
            "rho_mean"
        ]
    )

    rho_std = float(
        normalization[
            "rho_std"
        ]
    )

    state_mean = np.asarray(
        normalization[
            "state_mean"
        ],
        dtype=np.float64,
    )

    state_std = np.asarray(
        normalization[
            "state_std"
        ],
        dtype=np.float64,
    )

    state_mean_t = torch.as_tensor(
        state_mean,
        dtype=torch.float32,
        device=device,
    ).view(
        1,
        1,
        -1,
    )

    state_std_t = torch.as_tensor(
        state_std,
        dtype=torch.float32,
        device=device,
    ).view(
        1,
        1,
        -1,
    )

    base_model = (
        file191
        .ModelB()
        .to(
            device
        )
    )

    base_model.load_state_dict(
        base_checkpoint[
            "model_state_dict"
        ]
    )

    base_model.eval()

    control_model = (
        file191
        .ModelB()
        .to(
            device
        )
    )

    control_model.load_state_dict(
        control_checkpoint[
            "model_state_dict"
        ]
    )

    control_model.eval()

    for model in (
        base_model,
        control_model,
    ):
        for parameter in (
            model.parameters()
        ):
            parameter.requires_grad_(
                False
            )

    print(
        "CHECKPOINTS"
    )

    print("-" * 78)

    print(
        f"Model-B epoch        : "
        f"{base_checkpoint.get('epoch')}"
    )

    print(
        f"Matched-control epoch: "
        f"{control_checkpoint.get('epoch')}"
    )

    print(
        "Control normalization : "
        + (
            "MATCH"
            if control_normalization
            is not None
            else
            "NOT STORED, BASE NORMALIZATION USED"
        )
    )

    print()

    beta = np.asarray(
        file70.BETA,
        dtype=np.float64,
    )

    lambdas = np.asarray(
        file70.LAMBDA,
        dtype=np.float64,
    )

    generation_time = float(
        file70.GENERATION_TIME
    )

    fuel_coeff = np.asarray(
        file70.FUEL_COEFF,
        dtype=np.float64,
    )

    block_coeff = np.asarray(
        file70.BLOCK_COEFF,
        dtype=np.float64,
    )

    fuel_reference = float(
        file74.T_FUEL_REF
    )

    block_reference = float(
        file74.T_BLOCK_REF
    )

    beta_t = torch.as_tensor(
        beta,
        dtype=torch.float32,
        device=device,
    )

    lambdas_t = torch.as_tensor(
        lambdas,
        dtype=torch.float32,
        device=device,
    )

    fuel_coeff_t = torch.as_tensor(
        fuel_coeff,
        dtype=torch.float32,
        device=device,
    )

    block_coeff_t = torch.as_tensor(
        block_coeff,
        dtype=torch.float32,
        device=device,
    )

    kinetics_scales_t = torch.as_tensor(
        kinetics_scales,
        dtype=torch.float32,
        device=device,
    ).view(
        1,
        1,
        7,
    )

    thermal_scales_t = torch.as_tensor(
        thermal_scales,
        dtype=torch.float32,
        device=device,
    ).view(
        1,
        1,
        3,
    )

    thermal_model = (
        file74
        .MasterCoupledReferenceModel()
    )

    print(
        "PAIRED FULL-PHYSICS PROBES"
    )

    print("-" * 78)

    results = {}

    for partition, batches, seed in [
        (
            "TRAIN",
            TRAIN_PROBE_BATCHES,
            SEED + 10,
        ),
        (
            "VALIDATION",
            VALIDATION_PROBE_BATCHES,
            SEED + 20,
        ),
    ]:
        results[
            partition
        ] = {}

        for label, model in [
            (
                "MODEL_B",
                base_model,
            ),
            (
                "MATCHED_CONTROL",
                control_model,
            ),
        ]:
            probe = probe_partition(
                model=model,
                partition=partition,
                seed=seed,
                number_batches=batches,
                file191=file191,
                file196=file196,
                file204=file204,
                file208=file208,
                file74=file74,
                file206=file206,
                thermal_model=thermal_model,
                global_rho=global_rho,
                global_state=global_state,
                event_rho=event_rho,
                event_state=event_state,
                event_mapping=event_mapping,
                global_time=global_time,
                event_time=event_time,
                global_time_norm=global_time_norm,
                event_time_norm=event_time_norm,
                rho_mean=rho_mean,
                rho_std=rho_std,
                state_mean=state_mean,
                state_std=state_std,
                state_mean_t=state_mean_t,
                state_std_t=state_std_t,
                kinetics_scales_t=kinetics_scales_t,
                thermal_scales_t=thermal_scales_t,
                beta_t=beta_t,
                lambdas_t=lambdas_t,
                generation_time=generation_time,
                fuel_coeff_t=fuel_coeff_t,
                block_coeff_t=block_coeff_t,
                fuel_reference=fuel_reference,
                block_reference=block_reference,
                device=device,
            )

            results[
                partition
            ][
                label
            ] = probe

            combined = (
                probe[
                    "combined"
                ]
            )

            print(
                f"{partition:<10} "
                f"{label:<16} "
                f"Data={combined['data_loss']:.8e} "
                f"K={combined['kinetics_family_loss']:.8e} "
                f"T={combined['thermal_family_loss']:.8e} "
                f"Naive10={combined['naive_ten_equation_mean']:.8e} "
                f"Balanced={combined['family_balanced_physics_loss']:.8e}"
            )

    print()

    identity_errors = []
    finite_values = []

    for partition in [
        "TRAIN",
        "VALIDATION",
    ]:
        for label in [
            "MODEL_B",
            "MATCHED_CONTROL",
        ]:
            probe = (
                results[
                    partition
                ][
                    label
                ]
            )

            identity_errors += list(
                probe[
                    "identity_audit"
                ].values()
            )

            combined = (
                probe[
                    "combined"
                ]
            )

            finite_values += [
                combined[
                    "data_loss"
                ],
                combined[
                    "kinetics_family_loss"
                ],
                combined[
                    "thermal_family_loss"
                ],
                combined[
                    "naive_ten_equation_mean"
                ],
                combined[
                    "family_balanced_physics_loss"
                ],
                *np.asarray(
                    combined[
                        "kinetics_equation_mse"
                    ],
                    dtype=np.float64,
                ).tolist(),
                *np.asarray(
                    combined[
                        "thermal_equation_mse"
                    ],
                    dtype=np.float64,
                ).tolist(),
            ]

    identity_pass = (
        max(
            identity_errors
        )
        <= 1.0e-8
    )

    finite_pass = all(
        math.isfinite(
            float(
                value
            )
        )
        for value
        in finite_values
    )

    positive_loss_pass = all(
        float(
            value
        )
        >= 0.0
        for value
        in finite_values
    )

    model_b_train = (
        results[
            "TRAIN"
        ][
            "MODEL_B"
        ][
            "combined"
        ]
    )

    equal_contribution_lambda = (
        model_b_train[
            "data_loss"
        ]
        /
        max(
            model_b_train[
                "family_balanced_physics_loss"
            ],
            EPS,
        )
    )

    gate_pass = all(
        [
            file198_pass,
            file206_pass,
            file207_pass,
            equation_name_pass,
            scale_shape_pass,
            scale_finite_positive_pass,
            family_balance_pass,
            identity_pass,
            finite_pass,
            positive_loss_pass,
            control_normalization_match,
        ]
    )

    print(
        "COMPOSITION CONTRACT CHECK"
    )

    print("-" * 78)

    print(
        "7 kinetics + 3 thermal residuals : "
        + (
            "PASS"
            if (
                equation_name_pass
                and
                scale_shape_pass
            )
            else
            "FAIL"
        )
    )

    print(
        "Within-family mean identities    : "
        + (
            "PASS"
            if identity_pass
            else
            "FAIL"
        )
    )

    print(
        "Finite nonnegative losses        : "
        + (
            "PASS"
            if (
                finite_pass
                and
                positive_loss_pass
            )
            else
            "FAIL"
        )
    )

    print(
        "Naive 10-equation structure      : "
        "0.7 kinetics + 0.3 thermal"
    )

    print(
        "Frozen full-physics structure    : "
        "0.5 kinetics + 0.5 thermal"
    )

    print(
        f"TRAIN equal-scale lambda         : "
        f"{equal_contribution_lambda:.10e}"
    )

    print(
        "Lambda status                    : "
        "DIAGNOSTIC ONLY, NOT FROZEN"
    )

    print()

    payload = {
        "script":
            "209_step7_full_physics_composition_preflight.py",

        "status":
            (
                "FULL_PHYSICS_COMPOSITION_READY"
                if gate_pass
                else
                "FULL_PHYSICS_COMPOSITION_CHECK_REQUIRED"
            ),

        "training_performed":
            False,

        "hyperparameter_tuning":
            False,

        "dataset_modified":
            False,

        "id_ood_stress_accessed":
            False,

        "source_contracts": {
            "file198_status":
                file198.get(
                    "status"
                ),

            "file206_status":
                file206_json.get(
                    "status"
                ),

            "file207_status":
                file207.get(
                    "status"
                ),

            "kinetics_residual_source":
                "204_step7_coupled_kinetics_weight_gate.py",

            "thermal_residual_source":
                "208_step7_thermal_only_weight_gate.py",

            "thermal_forward_closure":
                "206 exact File-74 numerical-autograd closure",
        },

        "equations": {
            "kinetics":
                kinetics_names,

            "thermal":
                thermal_names,

            "kinetics_count":
                n_k,

            "thermal_count":
                n_t,

            "total_count":
                n_total,
        },

        "normalization": {
            "kinetics": {
                "source":
                    "File 198",

                "scales":
                    kinetics_scales,

                "rule":
                    (
                        "beta_eff/Lambda for power; "
                        "beta_i/Lambda for precursors"
                    ),
            },

            "thermal": {
                "source":
                    "File 207",

                "scales":
                    thermal_scales,

                "rule":
                    (
                        "TRAIN pooled "
                        "equation-balance RMS"
                    ),
            },
        },

        "equation_count_bias_audit": {
            "naive_ten_equation_mean": {
                "kinetics_structural_weight":
                    naive_k_weight,

                "thermal_structural_weight":
                    naive_t_weight,

                "accepted":
                    False,
            },

            "family_balanced": {
                "kinetics_family_weight":
                    KINETICS_FAMILY_WEIGHT,

                "thermal_family_weight":
                    THERMAL_FAMILY_WEIGHT,

                "accepted":
                    True,

                "reason":
                    (
                        "prevents automatic 70/30 weighting "
                        "from the 7-versus-3 equation count"
                    ),
            },
        },

        "frozen_full_physics_loss_contract": {
            "kinetics_family_loss":
                (
                    "mean of seven normalized "
                    "kinetics equation MSEs"
                ),

            "thermal_family_loss":
                (
                    "mean of three normalized "
                    "thermal equation MSEs"
                ),

            "physics_loss":
                (
                    "0.5 * kinetics_family_loss "
                    "+ 0.5 * thermal_family_loss"
                ),

            "global_event_weighting": {
                "global":
                    float(
                        file191.GLOBAL_LOSS_WEIGHT
                    ),

                "event":
                    float(
                        file191.EVENT_LOSS_WEIGHT
                    ),
            },

            "reactivity_closure_loss_added":
                False,

            "independent_brayton_loss_added":
                False,

            "global_initial_condition_loss_added":
                False,

            "event_rated_initial_condition_loss_added":
                False,
        },

        "checkpoint_probe": {
            "model_b_checkpoint":
                str(
                    base_checkpoint_path
                ),

            "matched_control_checkpoint":
                str(
                    control_checkpoint_path
                ),

            "control_normalization_metadata_present":
                (
                    control_normalization
                    is not None
                ),

            "control_normalization_match":
                control_normalization_match,

            "results":
                results,
        },

        "diagnostic_weight_scale": {
            "source":
                (
                    "MODEL_B TRAIN paired "
                    "composition probe"
                ),

            "equal_contribution_lambda":
                equal_contribution_lambda,

            "status":
                "DIAGNOSTIC_ONLY_NOT_FROZEN",

            "next_use":
                (
                    "File 210 controlled "
                    "full-PINO weight gate"
                ),
        },

        "gate_audit": {
            "family_balance_pass":
                family_balance_pass,

            "identity_pass":
                identity_pass,

            "maximum_identity_error":
                max(
                    identity_errors
                ),

            "finite_pass":
                finite_pass,

            "positive_loss_pass":
                positive_loss_pass,
        },
    }

    output_json.write_text(
        json.dumps(
            serializable(
                payload
            ),
            indent=2,
            allow_nan=False,
        ),
        encoding="utf-8",
    )

    report = [
        "=" * 78,

        "STEP 7 FULL-PHYSICS COMPOSITION PREFLIGHT REPORT",

        "=" * 78,

        "",

        "Physics families:",

        "  Kinetics = 1 power + 6 precursor equations",

        "  Thermal  = fuel + block + bulk coolant equations",

        "",

        "Residual normalization:",

        "  Kinetics = File 198 dimensionless scales",

        "  Thermal  = File 207 TRAIN equation-balance RMS scales",

        "",

        "Equation-count audit:",

        "  Naive 10-equation mean = 0.7 K + 0.3 T",

        "  Adopted family balance = 0.5 K + 0.5 T",

        "",

        "Frozen composition:",

        "  L_data    = 0.5 L_global + 0.5 L_event",

        "  L_kin     = mean(7 normalized kinetics equation MSEs)",

        "  L_thermal = mean(3 normalized thermal equation MSEs)",

        "  L_physics = 0.5 L_kin + 0.5 L_thermal",

        "  L_total   = L_data + lambda_full * L_physics",

        "",

        f"TRAIN equal-scale lambda : "
        f"{equal_contribution_lambda:.10e}",

        "Lambda status            : "
        "DIAGNOSTIC ONLY, NOT FROZEN",

        "",

        "Training performed       : NO",

        "Hyperparameter tuning    : NO",

        "ID/OOD/STRESS accessed   : NO",

        "Production-V1 modified   : NO",

        "",

        "STATUS: "
        + (
            "FULL_PHYSICS_COMPOSITION_READY"
            if gate_pass
            else
            "FULL_PHYSICS_COMPOSITION_CHECK_REQUIRED"
        ),
    ]

    output_txt.write_text(
        "\n".join(
            report
        )
        + "\n",
        encoding="utf-8",
    )

    print("=" * 78)

    print(
        "FULL-PHYSICS COMPOSITION DECISION"
    )

    print("=" * 78)

    print(
        "STATUS: "
        + (
            "FULL_PHYSICS_COMPOSITION_READY"
            if gate_pass
            else
            "FULL_PHYSICS_COMPOSITION_CHECK_REQUIRED"
        )
    )

    print()

    print(
        f"JSON report : {output_json}"
    )

    print(
        f"Text report : {output_txt}"
    )

    print()

    print(
        "Training performed : NO"
    )

    print(
        "Dataset modified   : NO"
    )

    print(
        "ID/OOD/STRESS used : NO"
    )


if __name__ == "__main__":
    main()