#!/usr/bin/env python3
"""
208_step7_thermal_only_weight_gate.py

STEP 7 - THERMAL-ONLY PHYSICS WEIGHT GATE

Physics family:
    fuel thermal equation
    block thermal equation
    bulk coolant thermal equation

Rules
-----
- Every thermal candidate starts from the original File-191 Model-B.
- Fine-tuning LR is frozen at 5e-4.
- Exact File-74 thermal physics is used through File-206 autograd closure.
- File-207 thermal normalization is frozen.
- Matched data-only continuation from File-201 is reused.
- Same batch/query schedule is used for every thermal candidate.
- TRAIN performs updates.
- VALIDATION performs checkpoint and weight selection.
- ID/OOD/STRESS are NOT accessed.
- No kinetics residuals.
- No Brayton residual is independently invented.
- Production-V1 is not modified.
"""

from __future__ import annotations

import copy
import gc
import importlib.util
import json
import math
import random
import sys
import time
from pathlib import Path

import numpy as np
import torch


# =====================================================================
# FROZEN EXPERIMENT CONTRACT
# =====================================================================

FROZEN_LEARNING_RATE = 5.0e-4

CONTINUATION_EPOCHS = 20

EFFECTIVE_BATCH_SIZE = 8

MICRO_BATCH_SIZE = 2

SCHEDULE_SEED = 20261999

CANDIDATE_FRACTIONS = [
    0.003,
    0.010,
    0.030,
]

AUDIT_REPLICATES = 12

AUDIT_BATCHES_PER_REPLICATE = 8

AUDIT_BATCH_SIZE = 4

AUDIT_SEED_BASE = 20262080

STABLE_POSITIVE_FRACTION = 0.80


# =====================================================================
# GENERAL
# =====================================================================

def find_root():

    current = Path.cwd().resolve()

    for path in [current, *current.parents]:

        if (
            path
            / "step6_dataset"
            / "production_v1"
        ).is_dir():

            return path

    raise FileNotFoundError(
        "Could not locate He-Xe PINO project root."
    )


def load_module(
    name,
    path,
):

    if not path.exists():

        raise FileNotFoundError(
            f"Required file not found:\n{path}"
        )

    spec = importlib.util.spec_from_file_location(
        name,
        str(path),
    )

    if (
        spec is None
        or spec.loader is None
    ):

        raise ImportError(
            f"Could not import:\n{path}"
        )

    module = importlib.util.module_from_spec(
        spec
    )

    sys.modules[name] = module

    spec.loader.exec_module(
        module
    )

    return module


def require_file(
    path,
):

    if not path.exists():

        raise FileNotFoundError(
            path
        )

    return path


def set_seed(
    seed,
):

    random.seed(
        seed
    )

    np.random.seed(
        seed
    )

    torch.manual_seed(
        seed
    )

    if torch.cuda.is_available():

        torch.cuda.manual_seed_all(
            seed
        )

    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def cpu_state_dict(
    model,
):

    return {

        key:
            value
            .detach()
            .cpu()
            .clone()

        for key, value
        in model.state_dict().items()
    }


def percent_improvement(
    reference,
    candidate,
):

    if reference == 0.0:

        return float(
            "nan"
        )

    return (
        100.0
        * (
            reference
            - candidate
        )
        / reference
    )


# =====================================================================
# THERMAL TIME DERIVATIVES
# =====================================================================

def thermal_time_derivatives_training(
    prediction,
    query,
    state_std_t,
    horizon_seconds,
):

    derivatives = []

    thermal_indices = [
        7,
        8,
        9,
    ]

    for state_index in thermal_indices:

        scalar = prediction[
            ...,
            state_index
        ].sum()

        gradient_tau = torch.autograd.grad(
            outputs=scalar,
            inputs=query,
            create_graph=True,
            retain_graph=True,
        )[0]

        derivative_time = (
            gradient_tau.squeeze(
                -1
            )
            * state_std_t[
                0,
                0,
                state_index
            ]
            / horizon_seconds
        )

        derivatives.append(
            derivative_time
        )

    return torch.stack(
        derivatives,
        dim=-1,
    )


def thermal_time_derivatives_audit(
    prediction,
    query,
    state_std_t,
    horizon_seconds,
):

    derivatives = []

    thermal_indices = [
        7,
        8,
        9,
    ]

    for local_index, state_index in enumerate(
        thermal_indices
    ):

        scalar = prediction[
            ...,
            state_index
        ].sum()

        gradient_tau = torch.autograd.grad(
            outputs=scalar,
            inputs=query,
            create_graph=False,
            retain_graph=(
                local_index < 2
            ),
        )[0]

        derivative_time = (
            gradient_tau.squeeze(
                -1
            )
            * state_std_t[
                0,
                0,
                state_index
            ]
            / horizon_seconds
        )

        derivatives.append(
            derivative_time
        )

    return torch.stack(
        derivatives,
        dim=-1,
    )


# =====================================================================
# THERMAL RHS INPUT
# =====================================================================

def make_thermal_rhs_input(
    physical_state,
):

    return torch.stack(
        [
            physical_state[
                ...,
                0
            ],

            physical_state[
                ...,
                7
            ],

            physical_state[
                ...,
                8
            ],

            physical_state[
                ...,
                9
            ],
        ],
        dim=-1,
    )


# =====================================================================
# THERMAL TRAINING LOSS
# =====================================================================

def thermal_physics_loss_training(
    prediction,
    query,
    state_mean_t,
    state_std_t,
    thermal_scale_t,
    horizon_seconds,
    file74,
    file206,
    thermal_model,
):

    physical_state = (
        prediction
        * state_std_t
        + state_mean_t
    )

    predicted_derivative = (
        thermal_time_derivatives_training(
            prediction=prediction,
            query=query,
            state_std_t=state_std_t,
            horizon_seconds=horizon_seconds,
        )
    )

    rhs_input = make_thermal_rhs_input(
        physical_state
    )

    rhs = file206.exact_thermal_rhs_torch(
        rhs_input,
        file74,
        thermal_model,
    )

    residual = (
        predicted_derivative
        - rhs
    ) / thermal_scale_t

    equation_mse = torch.mean(
        residual**2,
        dim=(0, 1),
    )

    physics_loss = torch.mean(
        equation_mse
    )

    return (
        physics_loss,
        equation_mse,
    )


# =====================================================================
# TRAIN ONE REPRESENTATION
# =====================================================================

def train_representation(
    model,
    optimizer,
    branch_array,
    state_array,
    ordered_cases,
    time_norm_tensor,
    query_sampler,
    query_generator,
    forward_method,
    rho_mean,
    rho_std,
    state_mean,
    state_std,
    state_mean_t,
    state_std_t,
    thermal_scale_t,
    physics_weight,
    horizon_seconds,
    file74,
    file206,
    thermal_model,
    device,
):

    data_sum = 0.0

    physics_sum = 0.0

    equation_sum = np.zeros(
        3,
        dtype=np.float64,
    )

    case_count = 0

    ordered_cases = np.asarray(
        ordered_cases,
        dtype=np.int64,
    )

    for batch_start in range(
        0,
        len(
            ordered_cases
        ),
        EFFECTIVE_BATCH_SIZE,
    ):

        effective_cases = ordered_cases[
            batch_start:
            batch_start
            + EFFECTIVE_BATCH_SIZE
        ]

        if len(
            effective_cases
        ) == 0:

            continue

        query_indices_tensor = query_sampler(
            query_generator
        )

        query_indices = (
            query_indices_tensor
            .cpu()
            .numpy()
            .astype(
                np.int64,
                copy=False,
            )
        )

        optimizer.zero_grad(
            set_to_none=True
        )

        effective_n = len(
            effective_cases
        )

        for micro_start in range(
            0,
            effective_n,
            MICRO_BATCH_SIZE,
        ):

            cases = effective_cases[
                micro_start:
                micro_start
                + MICRO_BATCH_SIZE
            ]

            micro_n = len(
                cases
            )

            raw_branch = np.asarray(
                branch_array[
                    cases
                ],
                dtype=np.float32,
            )

            branch_normalized = (
                raw_branch
                - np.float32(
                    rho_mean
                )
            ) / np.float32(
                rho_std
            )

            target_full = (
                np.asarray(
                    state_array[
                        cases
                    ],
                    dtype=np.float32,
                )
                - np.asarray(
                    state_mean,
                    dtype=np.float32,
                )
            ) / np.asarray(
                state_std,
                dtype=np.float32,
            )

            target = target_full[
                :,
                query_indices,
                :
            ]

            branch_tensor = torch.from_numpy(
                branch_normalized
            ).to(
                device
            )

            target_tensor = torch.from_numpy(
                target
            ).to(
                device
            )

            query = (
                time_norm_tensor[
                    query_indices_tensor
                ]
                .view(
                    1,
                    -1,
                    1,
                )
                .expand(
                    micro_n,
                    -1,
                    -1,
                )
                .clone()
                .detach()
                .requires_grad_(
                    True
                )
            )

            prediction = forward_method(
                branch_tensor,
                query,
            )

            data_loss = torch.mean(
                (
                    prediction
                    - target_tensor
                )**2
            )

            (
                physics_loss,
                equation_mse,
            ) = thermal_physics_loss_training(
                prediction=prediction,
                query=query,
                state_mean_t=state_mean_t,
                state_std_t=state_std_t,
                thermal_scale_t=thermal_scale_t,
                horizon_seconds=horizon_seconds,
                file74=file74,
                file206=file206,
                thermal_model=thermal_model,
            )

            total_loss = (
                data_loss
                + physics_weight
                * physics_loss
            )

            gradient_weight = (
                float(
                    micro_n
                )
                / float(
                    effective_n
                )
            )

            (
                total_loss
                * gradient_weight
            ).backward()

            data_sum += (
                float(
                    data_loss
                    .detach()
                    .cpu()
                )
                * micro_n
            )

            physics_sum += (
                float(
                    physics_loss
                    .detach()
                    .cpu()
                )
                * micro_n
            )

            equation_sum += (
                equation_mse
                .detach()
                .cpu()
                .numpy()
                .astype(
                    np.float64
                )
                * micro_n
            )

            case_count += (
                micro_n
            )

        torch.nn.utils.clip_grad_norm_(
            model.parameters(),
            file191_gradient_clip_placeholder
        )

        optimizer.step()

    return {

        "data_loss":
            data_sum
            / case_count,

        "physics_loss":
            physics_sum
            / case_count,

        "equation_mse":
            (
                equation_sum
                / case_count
            ).tolist(),
    }


# =====================================================================
# TRAIN REPRESENTATION WRAPPER
# =====================================================================

def train_representation_with_clip(
    *,
    file191,
    **kwargs,
):

    global file191_gradient_clip_placeholder

    file191_gradient_clip_placeholder = (
        file191.GRADIENT_CLIP
    )

    return train_representation(
        **kwargs
    )


# =====================================================================
# CHECKPOINT
# =====================================================================

def save_checkpoint(
    path,
    model,
    optimizer,
    epoch,
    validation_mse,
    fraction,
    physics_weight,
    base_checkpoint,
    normalization,
    thermal_scale,
):

    payload = {

        "model_state_dict":
            cpu_state_dict(
                model
            ),

        "optimizer_state_dict":
            optimizer.state_dict(),

        "epoch":
            epoch,

        "best_validation_mse":
            validation_mse,

        "initialization":
            "File-191 model_b_best.pt",

        "initialization_epoch":
            base_checkpoint.get(
                "epoch"
            ),

        "physics_family":
            "thermal_only",

        "thermal_equations":
            [
                "fuel_temperature",
                "block_temperature",
                "bulk_coolant_temperature",
            ],

        "kinetics_residuals":
            False,

        "thermal_residuals":
            True,

        "physics_fraction":
            fraction,

        "physics_weight":
            physics_weight,

        "thermal_scale":
            thermal_scale.tolist(),

        "learning_rate":
            FROZEN_LEARNING_RATE,

        "normalization":
            normalization,

        "test_partitions_used":
            False,
    }

    torch.save(
        payload,
        path,
    )


# =====================================================================
# RUN ONE THERMAL CANDIDATE
# =====================================================================

def run_candidate(
    fraction,
    physics_weight,
    file191,
    file74,
    file206,
    thermal_model,
    base_checkpoint,
    normalization,
    global_rho,
    global_state,
    event_rho,
    event_state,
    event_mapping,
    global_time,
    event_time,
    global_time_norm_t,
    event_time_norm_t,
    rho_mean,
    rho_std,
    state_mean,
    state_std,
    state_mean_t,
    state_std_t,
    thermal_scale,
    thermal_scale_t,
    device,
    output_dir,
):

    model = (
        file191
        .ModelB()
        .to(
            device
        )
    )

    model.load_state_dict(
        base_checkpoint[
            "model_state_dict"
        ]
    )

    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=FROZEN_LEARNING_RATE,
        weight_decay=file191.WEIGHT_DECAY,
    )

    if (
        "optimizer_state_dict"
        in base_checkpoint
    ):

        optimizer.load_state_dict(
            copy.deepcopy(
                base_checkpoint[
                    "optimizer_state_dict"
                ]
            )
        )

    for group in optimizer.param_groups:

        group[
            "lr"
        ] = FROZEN_LEARNING_RATE

        group[
            "weight_decay"
        ] = file191.WEIGHT_DECAY

    numpy_rng = np.random.default_rng(
        SCHEDULE_SEED
    )

    query_generator = torch.Generator(
        device="cpu"
    )

    query_generator.manual_seed(
        SCHEDULE_SEED + 1
    )

    train_global = np.arange(
        file191.PARTITIONS[
            "TRAIN"
        ][0],
        file191.PARTITIONS[
            "TRAIN"
        ][1],
        dtype=np.int64,
    )

    train_event = np.asarray(
        event_mapping[
            "TRAIN"
        ],
        dtype=np.int64,
    )

    global_horizon = float(
        global_time[-1]
        - global_time[0]
    )

    event_horizon = float(
        event_time[-1]
        - event_time[0]
    )

    def global_sampler(
        generator,
    ):

        return (
            file191
            .sample_global_queries(
                global_time_norm_t,
                file191.GLOBAL_QUERY_POINTS,
                generator,
            )
        )

    def event_sampler(
        generator,
    ):

        return (
            file191
            .sample_event_queries(
                event_time,
                file191.EVENT_FAST_QUERY_POINTS,
                file191.EVENT_SLOW_QUERY_POINTS,
                generator,
            )
        )

    validation_initial = (
        file191
        .evaluate_partition(
            model,
            global_rho,
            global_state,
            event_rho,
            event_state,
            event_mapping[
                "VALIDATION"
            ],
            global_time_norm_t,
            event_time_norm_t,
            file191.PARTITIONS[
                "VALIDATION"
            ][0],
            file191.PARTITIONS[
                "VALIDATION"
            ][1],
            rho_mean,
            rho_std,
            state_mean,
            state_std,
            device,
        )
    )

    best_validation = float(
        validation_initial[
            "combined_mse"
        ]
    )

    best_epoch = 0

    tag = (
        f"{fraction:.3f}"
        .replace(
            ".",
            "p"
        )
    )

    checkpoint_path = (
        output_dir
        / f"thermal_{tag}_best.pt"
    )

    history_path = (
        output_dir
        / f"thermal_{tag}_history.json"
    )

    save_checkpoint(
        path=checkpoint_path,
        model=model,
        optimizer=optimizer,
        epoch=0,
        validation_mse=best_validation,
        fraction=fraction,
        physics_weight=physics_weight,
        base_checkpoint=base_checkpoint,
        normalization=normalization,
        thermal_scale=thermal_scale,
    )

    history = []

    print()

    print("=" * 78)

    print(
        f"THERMAL FRACTION {fraction:.3f}"
    )

    print("=" * 78)

    print(
        f"Physics lambda : "
        f"{physics_weight:.10e}"
    )

    print(
        f"Starting MSE   : "
        f"{best_validation:.10e}"
    )

    for epoch in range(
        1,
        CONTINUATION_EPOCHS + 1,
    ):

        epoch_start = (
            time.perf_counter()
        )

        model.train()

        shuffled_global = (
            numpy_rng.permutation(
                train_global
            )
        )

        global_result = (
            train_representation_with_clip(
                file191=file191,
                model=model,
                optimizer=optimizer,
                branch_array=global_rho,
                state_array=global_state,
                ordered_cases=shuffled_global,
                time_norm_tensor=global_time_norm_t,
                query_sampler=global_sampler,
                query_generator=query_generator,
                forward_method=model.forward_global,
                rho_mean=rho_mean,
                rho_std=rho_std,
                state_mean=state_mean,
                state_std=state_std,
                state_mean_t=state_mean_t,
                state_std_t=state_std_t,
                thermal_scale_t=thermal_scale_t,
                physics_weight=physics_weight,
                horizon_seconds=global_horizon,
                file74=file74,
                file206=file206,
                thermal_model=thermal_model,
                device=device,
            )
        )

        shuffled_event = (
            numpy_rng.permutation(
                train_event
            )
        )

        event_result = (
            train_representation_with_clip(
                file191=file191,
                model=model,
                optimizer=optimizer,
                branch_array=event_rho,
                state_array=event_state,
                ordered_cases=shuffled_event,
                time_norm_tensor=event_time_norm_t,
                query_sampler=event_sampler,
                query_generator=query_generator,
                forward_method=model.forward_event,
                rho_mean=rho_mean,
                rho_std=rho_std,
                state_mean=state_mean,
                state_std=state_std,
                state_mean_t=state_mean_t,
                state_std_t=state_std_t,
                thermal_scale_t=thermal_scale_t,
                physics_weight=physics_weight,
                horizon_seconds=event_horizon,
                file74=file74,
                file206=file206,
                thermal_model=thermal_model,
                device=device,
            )
        )

        validation = (
            file191
            .evaluate_partition(
                model,
                global_rho,
                global_state,
                event_rho,
                event_state,
                event_mapping[
                    "VALIDATION"
                ],
                global_time_norm_t,
                event_time_norm_t,
                file191.PARTITIONS[
                    "VALIDATION"
                ][0],
                file191.PARTITIONS[
                    "VALIDATION"
                ][1],
                rho_mean,
                rho_std,
                state_mean,
                state_std,
                device,
            )
        )

        train_data = (
            file191.GLOBAL_LOSS_WEIGHT
            * global_result[
                "data_loss"
            ]
            +
            file191.EVENT_LOSS_WEIGHT
            * event_result[
                "data_loss"
            ]
        )

        train_physics = (
            file191.GLOBAL_LOSS_WEIGHT
            * global_result[
                "physics_loss"
            ]
            +
            file191.EVENT_LOSS_WEIGHT
            * event_result[
                "physics_loss"
            ]
        )

        total_loss = (
            train_data
            + physics_weight
            * train_physics
        )

        improved = (
            validation[
                "combined_mse"
            ]
            <
            best_validation
            - file191.MIN_VALIDATION_IMPROVEMENT
        )

        if improved:

            best_validation = float(
                validation[
                    "combined_mse"
                ]
            )

            best_epoch = epoch

            save_checkpoint(
                path=checkpoint_path,
                model=model,
                optimizer=optimizer,
                epoch=epoch,
                validation_mse=best_validation,
                fraction=fraction,
                physics_weight=physics_weight,
                base_checkpoint=base_checkpoint,
                normalization=normalization,
                thermal_scale=thermal_scale,
            )

        elapsed = (
            time.perf_counter()
            - epoch_start
        )

        history.append({

            "epoch":
                epoch,

            "global_data_loss":
                global_result[
                    "data_loss"
                ],

            "event_data_loss":
                event_result[
                    "data_loss"
                ],

            "global_thermal_loss":
                global_result[
                    "physics_loss"
                ],

            "event_thermal_loss":
                event_result[
                    "physics_loss"
                ],

            "combined_data_loss":
                train_data,

            "combined_thermal_loss":
                train_physics,

            "total_loss":
                total_loss,

            "validation_mse":
                validation[
                    "combined_mse"
                ],

            "validation_rmse":
                validation[
                    "normalized_rmse"
                ],

            "best_validation_mse":
                best_validation,

            "best_epoch":
                best_epoch,

            "seconds":
                elapsed,
        })

        print(
            f"Epoch {epoch:02d} | "
            f"Data={train_data:.6e} | "
            f"Thermal={train_physics:.6e} | "
            f"Total={total_loss:.6e} | "
            f"Val={validation['combined_mse']:.6e} | "
            f"Best={best_validation:.6e} | "
            f"BestEpoch={best_epoch:02d} | "
            f"Time={elapsed:.1f}s"
        )

    history_path.write_text(
        json.dumps(
            history,
            indent=2,
        ),
        encoding="utf-8",
    )

    checkpoint = torch.load(
        checkpoint_path,
        map_location=device,
        weights_only=False,
    )

    model.load_state_dict(
        checkpoint[
            "model_state_dict"
        ]
    )

    model.eval()

    return {

        "model":
            model,

        "checkpoint":
            checkpoint,

        "checkpoint_path":
            checkpoint_path,

        "history_path":
            history_path,

        "best_epoch":
            int(
                checkpoint[
                    "epoch"
                ]
            ),

        "best_validation_mse":
            float(
                checkpoint[
                    "best_validation_mse"
                ]
            ),
    }


# =====================================================================
# THERMAL RESIDUAL AUDIT BATCH
# =====================================================================

def thermal_residual_batch(
    model,
    forward_method,
    branch_array,
    selected_cases,
    query_indices,
    normalized_time,
    horizon_seconds,
    rho_mean,
    rho_std,
    state_mean_t,
    state_std_t,
    thermal_scale_t,
    file74,
    file206,
    thermal_model,
    device,
):

    selected_cases = np.asarray(
        selected_cases,
        dtype=np.int64,
    )

    query_indices = np.asarray(
        query_indices,
        dtype=np.int64,
    )

    raw_branch = np.asarray(
        branch_array[
            selected_cases
        ],
        dtype=np.float32,
    )

    normalized_branch = (
        raw_branch
        - np.float32(
            rho_mean
        )
    ) / np.float32(
        rho_std
    )

    branch_tensor = torch.as_tensor(
        normalized_branch,
        dtype=torch.float32,
        device=device,
    )

    query_values = np.asarray(
        normalized_time[
            query_indices
        ],
        dtype=np.float32,
    )

    query = (
        torch.as_tensor(
            query_values,
            dtype=torch.float32,
            device=device,
        )
        .view(
            1,
            -1,
            1,
        )
        .expand(
            len(
                selected_cases
            ),
            -1,
            -1,
        )
        .clone()
        .detach()
        .requires_grad_(
            True
        )
    )

    prediction = forward_method(
        branch_tensor,
        query,
    )

    physical_state = (
        prediction
        * state_std_t
        + state_mean_t
    )

    predicted_derivative = (
        thermal_time_derivatives_audit(
            prediction=prediction,
            query=query,
            state_std_t=state_std_t,
            horizon_seconds=horizon_seconds,
        )
    )

    rhs_input = make_thermal_rhs_input(
        physical_state
    )

    rhs = file206.exact_thermal_rhs_torch(
        rhs_input,
        file74,
        thermal_model,
    )

    residual = (
        predicted_derivative
        - rhs
    ) / thermal_scale_t

    equation_mse = torch.mean(
        residual**2,
        dim=(0, 1),
    )

    thermal_mse = torch.mean(
        equation_mse
    )

    return {

        "thermal_mse":
            float(
                thermal_mse
                .detach()
                .cpu()
            ),

        "equation_mse":
            equation_mse
            .detach()
            .cpu()
            .numpy()
            .astype(
                np.float64
            ),
    }


# =====================================================================
# PAIRED VALIDATION AUDIT
# =====================================================================

def paired_validation_replicate(
    control_model,
    candidate_model,
    seed,
    file191,
    file196,
    file74,
    file206,
    thermal_model,
    global_rho,
    event_rho,
    event_mapping,
    global_time,
    event_time,
    global_time_norm,
    event_time_norm,
    rho_mean,
    rho_std,
    state_mean_t,
    state_std_t,
    thermal_scale_t,
    device,
):

    rng = np.random.default_rng(
        seed
    )

    start, stop = (
        file191.PARTITIONS[
            "VALIDATION"
        ]
    )

    global_available = np.arange(
        start,
        stop,
        dtype=np.int64,
    )

    event_available = np.asarray(
        event_mapping[
            "VALIDATION"
        ],
        dtype=np.int64,
    )

    control_global = []

    candidate_global = []

    control_event = []

    candidate_event = []

    for _ in range(
        AUDIT_BATCHES_PER_REPLICATE
    ):

        global_cases = rng.choice(
            global_available,
            size=AUDIT_BATCH_SIZE,
            replace=False,
        )

        global_queries = (
            file196
            .sample_global(
                total_points=(
                    file191.GLOBAL_POINTS
                ),
                number_points=(
                    file191.GLOBAL_QUERY_POINTS
                ),
                rng=rng,
            )
        )

        control_g = thermal_residual_batch(
            model=control_model,
            forward_method=(
                control_model
                .forward_global
            ),
            branch_array=global_rho,
            selected_cases=global_cases,
            query_indices=global_queries,
            normalized_time=global_time_norm,
            horizon_seconds=float(
                global_time[-1]
                - global_time[0]
            ),
            rho_mean=rho_mean,
            rho_std=rho_std,
            state_mean_t=state_mean_t,
            state_std_t=state_std_t,
            thermal_scale_t=thermal_scale_t,
            file74=file74,
            file206=file206,
            thermal_model=thermal_model,
            device=device,
        )

        candidate_g = thermal_residual_batch(
            model=candidate_model,
            forward_method=(
                candidate_model
                .forward_global
            ),
            branch_array=global_rho,
            selected_cases=global_cases,
            query_indices=global_queries,
            normalized_time=global_time_norm,
            horizon_seconds=float(
                global_time[-1]
                - global_time[0]
            ),
            rho_mean=rho_mean,
            rho_std=rho_std,
            state_mean_t=state_mean_t,
            state_std_t=state_std_t,
            thermal_scale_t=thermal_scale_t,
            file74=file74,
            file206=file206,
            thermal_model=thermal_model,
            device=device,
        )

        control_global.append(
            control_g[
                "thermal_mse"
            ]
        )

        candidate_global.append(
            candidate_g[
                "thermal_mse"
            ]
        )

        event_cases = rng.choice(
            event_available,
            size=AUDIT_BATCH_SIZE,
            replace=False,
        )

        event_queries = (
            file196
            .sample_event(
                event_time=event_time,
                fast_number=(
                    file191.EVENT_FAST_QUERY_POINTS
                ),
                slow_number=(
                    file191.EVENT_SLOW_QUERY_POINTS
                ),
                rng=rng,
            )
        )

        control_e = thermal_residual_batch(
            model=control_model,
            forward_method=(
                control_model
                .forward_event
            ),
            branch_array=event_rho,
            selected_cases=event_cases,
            query_indices=event_queries,
            normalized_time=event_time_norm,
            horizon_seconds=float(
                event_time[-1]
                - event_time[0]
            ),
            rho_mean=rho_mean,
            rho_std=rho_std,
            state_mean_t=state_mean_t,
            state_std_t=state_std_t,
            thermal_scale_t=thermal_scale_t,
            file74=file74,
            file206=file206,
            thermal_model=thermal_model,
            device=device,
        )

        candidate_e = thermal_residual_batch(
            model=candidate_model,
            forward_method=(
                candidate_model
                .forward_event
            ),
            branch_array=event_rho,
            selected_cases=event_cases,
            query_indices=event_queries,
            normalized_time=event_time_norm,
            horizon_seconds=float(
                event_time[-1]
                - event_time[0]
            ),
            rho_mean=rho_mean,
            rho_std=rho_std,
            state_mean_t=state_mean_t,
            state_std_t=state_std_t,
            thermal_scale_t=thermal_scale_t,
            file74=file74,
            file206=file206,
            thermal_model=thermal_model,
            device=device,
        )

        control_event.append(
            control_e[
                "thermal_mse"
            ]
        )

        candidate_event.append(
            candidate_e[
                "thermal_mse"
            ]
        )

    control_global_mean = float(
        np.mean(
            control_global
        )
    )

    candidate_global_mean = float(
        np.mean(
            candidate_global
        )
    )

    control_event_mean = float(
        np.mean(
            control_event
        )
    )

    candidate_event_mean = float(
        np.mean(
            candidate_event
        )
    )

    control_combined = (
        file191.GLOBAL_LOSS_WEIGHT
        * control_global_mean
        +
        file191.EVENT_LOSS_WEIGHT
        * control_event_mean
    )

    candidate_combined = (
        file191.GLOBAL_LOSS_WEIGHT
        * candidate_global_mean
        +
        file191.EVENT_LOSS_WEIGHT
        * candidate_event_mean
    )

    return {

        "seed":
            seed,

        "control_global":
            control_global_mean,

        "candidate_global":
            candidate_global_mean,

        "control_event":
            control_event_mean,

        "candidate_event":
            candidate_event_mean,

        "control_combined":
            control_combined,

        "candidate_combined":
            candidate_combined,

        "combined_improvement_percent":
            percent_improvement(
                control_combined,
                candidate_combined,
            ),
    }


# =====================================================================
# STABILITY SUMMARY
# =====================================================================

def summarize_stability(
    records,
):

    improvements = np.asarray(
        [
            row[
                "combined_improvement_percent"
            ]
            for row in records
        ],
        dtype=np.float64,
    )

    positive = int(
        np.sum(
            improvements > 0.0
        )
    )

    required_positive = math.ceil(
        STABLE_POSITIVE_FRACTION
        * len(
            records
        )
    )

    mean_improvement = float(
        np.mean(
            improvements
        )
    )

    stable_improvement = bool(
        positive
        >= required_positive
        and
        mean_improvement > 0.0
    )

    return {

        "replicates":
            len(
                records
            ),

        "positive_replicates":
            positive,

        "required_positive":
            required_positive,

        "mean_improvement_percent":
            mean_improvement,

        "median_improvement_percent":
            float(
                np.median(
                    improvements
                )
            ),

        "minimum_improvement_percent":
            float(
                np.min(
                    improvements
                )
            ),

        "maximum_improvement_percent":
            float(
                np.max(
                    improvements
                )
            ),

        "q10_percent":
            float(
                np.quantile(
                    improvements,
                    0.10,
                )
            ),

        "q90_percent":
            float(
                np.quantile(
                    improvements,
                    0.90,
                )
            ),

        "stable_improvement":
            stable_improvement,
    }


# =====================================================================
# MAIN
# =====================================================================

def main():

    set_seed(
        20261002
    )

    root = find_root()

    production = (
        root
        / "step6_dataset"
        / "production_v1"
    )

    file191 = load_module(
        "file191_208",
        require_file(
            root
            / "191_step7_model_b_training.py"
        ),
    )

    file196 = load_module(
        "file196_208",
        require_file(
            root
            / "196_step7_kinetics_physics_preflight_gate.py"
        ),
    )

    file206 = load_module(
        "file206_208",
        require_file(
            root
            / "206_step7_exact_thermal_autograd_closure_audit.py"
        ),
    )

    file74 = load_module(
        "file74_208",
        require_file(
            root
            / "74_master_coupled_reference_model.py"
        ),
    )

    file207_path = (
        root
        / "step7_pino"
        / "physics_informed"
        / "thermal_preflight"
        / "207_thermal_residual_normalization_gate.json"
    )

    base_checkpoint_path = (
        root
        / "step7_pino"
        / "model_b_training"
        / "model_b_best.pt"
    )

    control_checkpoint_path = (
        root
        / "step7_pino"
        / "physics_informed"
        / "power_lr_gate"
        / "lr_0p5_data_control_best.pt"
    )

    output_dir = (
        root
        / "step7_pino"
        / "physics_informed"
        / "thermal_only"
    )

    output_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    output_json = (
        output_dir
        / "208_thermal_only_weight_gate.json"
    )

    output_txt = (
        output_dir
        / "208_thermal_only_weight_gate.txt"
    )

    print("=" * 78)

    print(
        "STEP 7 THERMAL-ONLY PHYSICS WEIGHT GATE"
    )

    print("=" * 78)

    print(
        f"Project root : {root}"
    )

    # ---------------------------------------------------------------
    # FILE 207
    # ---------------------------------------------------------------

    file207 = json.loads(
        require_file(
            file207_path
        ).read_text(
            encoding="utf-8"
        )
    )

    if (
        file207.get(
            "status"
        )
        !=
        "THERMAL_RESIDUAL_NORMALIZATION_READY"
    ):

        raise RuntimeError(
            "File-207 normalization gate has not passed."
        )

    # ---------------------------------------------------------------
    # DEVICE
    # ---------------------------------------------------------------

    device = torch.device(
        "cuda"
        if torch.cuda.is_available()
        else "cpu"
    )

    print()

    print(
        f"Device : {device}"
    )

    if device.type == "cuda":

        print(
            "GPU    : "
            + torch.cuda.get_device_name(
                0
            )
        )

    # ---------------------------------------------------------------
    # DATA
    # ---------------------------------------------------------------

    global_time = np.asarray(
        file191.load_npy(
            production,
            "global_time_s.npy",
        ),
        dtype=np.float32,
    )

    global_rho = file191.load_npy(
        production,
        "global_reactivity_delta_k_over_k.npy",
    )

    global_state = file191.load_npy(
        production,
        "global_state.npy",
    )

    event_time = np.asarray(
        file191.load_npy(
            production,
            "step_event_relative_time_s.npy",
        ),
        dtype=np.float32,
    )

    event_rho = file191.load_npy(
        production,
        "step_event_reactivity_delta_k_over_k.npy",
    )

    event_state = file191.load_npy(
        production,
        "step_event_state.npy",
    )

    step_case_indices = np.asarray(
        file191.load_npy(
            production,
            "step_case_indices.npy",
        ),
        dtype=np.int64,
    )

    event_mapping = (
        file191
        .build_event_partition_mapping(
            step_case_indices
        )
    )

    global_time_norm_np = (
        file191.normalize_time(
            global_time
        )
    )

    event_time_norm_np = (
        file191.normalize_time(
            event_time
        )
    )

    global_time_norm_t = torch.from_numpy(
        global_time_norm_np
    ).to(
        device
    )

    event_time_norm_t = torch.from_numpy(
        event_time_norm_np
    ).to(
        device
    )

    # ---------------------------------------------------------------
    # BASE
    # ---------------------------------------------------------------

    base_checkpoint = torch.load(
        require_file(
            base_checkpoint_path
        ),
        map_location="cpu",
        weights_only=False,
    )

    normalization = (
        base_checkpoint[
            "normalization"
        ]
    )

    rho_mean = float(
        normalization[
            "rho_mean"
        ]
    )

    rho_std = float(
        normalization[
            "rho_std"
        ]
    )

    state_mean = np.asarray(
        normalization[
            "state_mean"
        ],
        dtype=np.float64,
    )

    state_std = np.asarray(
        normalization[
            "state_std"
        ],
        dtype=np.float64,
    )

    state_mean_t = torch.as_tensor(
        state_mean,
        dtype=torch.float32,
        device=device,
    ).view(
        1,
        1,
        -1,
    )

    state_std_t = torch.as_tensor(
        state_std,
        dtype=torch.float32,
        device=device,
    ).view(
        1,
        1,
        -1,
    )

    # ---------------------------------------------------------------
    # THERMAL SCALE
    # ---------------------------------------------------------------

    thermal_scale = np.asarray(
        file207[
            "normalization_contract"
        ][
            "thermal_scales"
        ],
        dtype=np.float64,
    )

    thermal_scale_t = torch.as_tensor(
        thermal_scale,
        dtype=torch.float32,
        device=device,
    ).view(
        1,
        1,
        3,
    )

    equal_lambda = float(
        file207[
            "weight_scale"
        ][
            "equal_contribution"
        ]
    )

    candidates = [

        {

            "fraction":
                fraction,

            "lambda":
                fraction
                * equal_lambda,
        }

        for fraction in CANDIDATE_FRACTIONS
    ]

    # ---------------------------------------------------------------
    # CONTROL
    # ---------------------------------------------------------------

    control_checkpoint = torch.load(
        require_file(
            control_checkpoint_path
        ),
        map_location="cpu",
        weights_only=False,
    )

    control_validation_mse = float(
        control_checkpoint[
            "best_validation_mse"
        ]
    )

    control_model = (
        file191
        .ModelB()
        .to(
            device
        )
    )

    control_model.load_state_dict(
        control_checkpoint[
            "model_state_dict"
        ]
    )

    control_model.eval()

    for parameter in control_model.parameters():

        parameter.requires_grad_(
            False
        )

    print()

    print(
        "THERMAL-ONLY CONTRACT"
    )

    print("-" * 78)

    print(
        f"Control Val MSE : "
        f"{control_validation_mse:.10e}"
    )

    print(
        f"Fine-tuning LR  : "
        f"{FROZEN_LEARNING_RATE:.10e}"
    )

    print(
        f"Equal-scale λ   : "
        f"{equal_lambda:.10e}"
    )

    print(
        "Thermal scales:"
    )

    print(
        f"  Fuel  : "
        f"{thermal_scale[0]:.10e}"
    )

    print(
        f"  Block : "
        f"{thermal_scale[1]:.10e}"
    )

    print(
        f"  Bulk  : "
        f"{thermal_scale[2]:.10e}"
    )

    print()

    print(
        "Candidates:"
    )

    for row in candidates:

        print(
            f"  fraction="
            f"{row['fraction']:.3f} "
            f"lambda="
            f"{row['lambda']:.10e}"
        )

    print()

    print(
        "ID/OOD/STRESS : NOT ACCESSED"
    )

    # ---------------------------------------------------------------
    # AUTHORITATIVE THERMAL MODEL
    # ---------------------------------------------------------------

    thermal_model = (
        file74
        .MasterCoupledReferenceModel()
    )

    # ---------------------------------------------------------------
    # CANDIDATES
    # ---------------------------------------------------------------

    candidate_results = []

    for candidate_index, candidate in enumerate(
        candidates,
        start=1,
    ):

        fraction = float(
            candidate[
                "fraction"
            ]
        )

        physics_weight = float(
            candidate[
                "lambda"
            ]
        )

        print()

        print("#" * 78)

        print(
            f"CANDIDATE "
            f"{candidate_index}/"
            f"{len(candidates)}"
        )

        print("#" * 78)

        run = run_candidate(
            fraction=fraction,
            physics_weight=physics_weight,
            file191=file191,
            file74=file74,
            file206=file206,
            thermal_model=thermal_model,
            base_checkpoint=base_checkpoint,
            normalization=normalization,
            global_rho=global_rho,
            global_state=global_state,
            event_rho=event_rho,
            event_state=event_state,
            event_mapping=event_mapping,
            global_time=global_time,
            event_time=event_time,
            global_time_norm_t=global_time_norm_t,
            event_time_norm_t=event_time_norm_t,
            rho_mean=rho_mean,
            rho_std=rho_std,
            state_mean=state_mean,
            state_std=state_std,
            state_mean_t=state_mean_t,
            state_std_t=state_std_t,
            thermal_scale=thermal_scale,
            thermal_scale_t=thermal_scale_t,
            device=device,
            output_dir=output_dir,
        )

        model = run[
            "model"
        ]

        for parameter in model.parameters():

            parameter.requires_grad_(
                False
            )

        # -----------------------------------------------------------
        # REPEATED VALIDATION RESIDUAL AUDIT
        # -----------------------------------------------------------

        records = []

        print()

        print(
            "PAIRED VALIDATION THERMAL RESIDUAL AUDIT"
        )

        print("-" * 78)

        for replicate in range(
            AUDIT_REPLICATES
        ):

            record = paired_validation_replicate(
                control_model=control_model,
                candidate_model=model,
                seed=(
                    AUDIT_SEED_BASE
                    + replicate
                ),
                file191=file191,
                file196=file196,
                file74=file74,
                file206=file206,
                thermal_model=thermal_model,
                global_rho=global_rho,
                event_rho=event_rho,
                event_mapping=event_mapping,
                global_time=global_time,
                event_time=event_time,
                global_time_norm=global_time_norm_np,
                event_time_norm=event_time_norm_np,
                rho_mean=rho_mean,
                rho_std=rho_std,
                state_mean_t=state_mean_t,
                state_std_t=state_std_t,
                thermal_scale_t=thermal_scale_t,
                device=device,
            )

            records.append(
                record
            )

            print(
                f"Rep {replicate + 1:02d} | "
                f"Control="
                f"{record['control_combined']:.8e} | "
                f"Candidate="
                f"{record['candidate_combined']:.8e} | "
                f"Improvement="
                f"{record['combined_improvement_percent']:+.3f}%"
            )

        stability = summarize_stability(
            records
        )

        validation_mse = float(
            run[
                "best_validation_mse"
            ]
        )

        accuracy_improvement = percent_improvement(
            control_validation_mse,
            validation_mse,
        )

        accuracy_pass = bool(
            validation_mse
            <
            control_validation_mse
            - file191.MIN_VALIDATION_IMPROVEMENT
        )

        residual_pass = bool(
            stability[
                "stable_improvement"
            ]
        )

        joint_pass = bool(
            accuracy_pass
            and
            residual_pass
        )

        result = {

            "fraction":
                fraction,

            "lambda":
                physics_weight,

            "best_epoch":
                run[
                    "best_epoch"
                ],

            "validation_mse":
                validation_mse,

            "validation_rmse":
                math.sqrt(
                    validation_mse
                ),

            "accuracy_improvement_vs_control_percent":
                accuracy_improvement,

            "accuracy_pass":
                accuracy_pass,

            "residual_stability":
                stability,

            "residual_pass":
                residual_pass,

            "joint_pass":
                joint_pass,

            "checkpoint":
                str(
                    run[
                        "checkpoint_path"
                    ]
                ),

            "history":
                str(
                    run[
                        "history_path"
                    ]
                ),
        }

        candidate_results.append(
            result
        )

        print()

        print(
            "CANDIDATE SUMMARY"
        )

        print("-" * 78)

        print(
            f"Best epoch           : "
            f"{result['best_epoch']}"
        )

        print(
            f"Validation MSE       : "
            f"{validation_mse:.10e}"
        )

        print(
            f"Accuracy vs control  : "
            f"{accuracy_improvement:+.4f}%"
        )

        print(
            "Residual mean change : "
            f"{stability['mean_improvement_percent']:+.4f}%"
        )

        print(
            "Positive residual reps: "
            f"{stability['positive_replicates']}"
            f"/{stability['replicates']}"
        )

        print(
            f"Accuracy pass        : "
            f"{accuracy_pass}"
        )

        print(
            f"Residual pass        : "
            f"{residual_pass}"
        )

        print(
            f"JOINT PASS           : "
            f"{joint_pass}"
        )

        del model
        del run

        gc.collect()

        if device.type == "cuda":

            torch.cuda.empty_cache()

    # ---------------------------------------------------------------
    # VALIDATION-ONLY SELECTION
    # ---------------------------------------------------------------

    joint_candidates = [

        row

        for row in candidate_results

        if row[
            "joint_pass"
        ]
    ]

    if joint_candidates:

        joint_candidates = sorted(
            joint_candidates,
            key=lambda row: (
                row[
                    "validation_mse"
                ],
                -row[
                    "residual_stability"
                ][
                    "mean_improvement_percent"
                ],
            ),
        )

        selected = (
            joint_candidates[0]
        )

        selection_status = (
            "THERMAL_ONLY_CANDIDATE_FROZEN"
        )

    else:

        selected = None

        selection_status = (
            "NO_THERMAL_ONLY_JOINT_DOMINANCE"
        )

    print()

    print("=" * 78)

    print(
        "VALIDATION-ONLY DECISION"
    )

    print("=" * 78)

    print(
        "Required:"
    )

    print(
        "1. lower validation MSE "
        "than matched data-only control"
    )

    print(
        "2. stable validation thermal-residual improvement"
    )

    print()

    print(
        f"Decision : "
        f"{selection_status}"
    )

    if selected is not None:

        print()

        print(
            f"Selected fraction : "
            f"{selected['fraction']:.3f}"
        )

        print(
            f"Selected lambda   : "
            f"{selected['lambda']:.10e}"
        )

        print(
            f"Best epoch        : "
            f"{selected['best_epoch']}"
        )

        print(
            f"Validation MSE    : "
            f"{selected['validation_mse']:.10e}"
        )

        print(
            "Residual improvement : "
            f"{selected['residual_stability']['mean_improvement_percent']:+.4f}%"
        )

    # ---------------------------------------------------------------
    # SAVE
    # ---------------------------------------------------------------

    payload = {

        "script":
            "208_step7_thermal_only_weight_gate.py",

        "status":
            "COMPLETE",

        "experiment":
            "Model-B plus thermal residuals only",

        "training_partition":
            "TRAIN",

        "selection_partition":
            "VALIDATION",

        "id_ood_stress_accessed":
            False,

        "production_v1_modified":
            False,

        "kinetics_residuals":
            False,

        "thermal_residuals":
            True,

        "learning_rate":
            FROZEN_LEARNING_RATE,

        "matched_control": {

            "checkpoint":
                str(
                    control_checkpoint_path
                ),

            "validation_mse":
                control_validation_mse,

            "learning_rate":
                FROZEN_LEARNING_RATE,
        },

        "physics_contract": {

            "equations":
                [
                    "fuel_temperature",
                    "block_temperature",
                    "bulk_coolant_temperature",
                ],

            "number_of_equations":
                3,

            "forward_physics":
                (
                    "exact File-74 thermal closure "
                    "verified by File 206"
                ),

            "autograd":
                (
                    "central-difference custom autograd "
                    "verified by File 206"
                ),

            "normalization":
                (
                    "File-207 pooled TRAIN "
                    "equation-balance RMS"
                ),

            "thermal_scales":
                thermal_scale.tolist(),

            "equal_scale_lambda":
                equal_lambda,

            "candidate_fractions":
                CANDIDATE_FRACTIONS,
        },

        "residual_stability_contract": {

            "replicates":
                AUDIT_REPLICATES,

            "batches_per_replicate":
                AUDIT_BATCHES_PER_REPLICATE,

            "probe_batch_size":
                AUDIT_BATCH_SIZE,

            "stable_positive_fraction":
                STABLE_POSITIVE_FRACTION,

            "paired_samples":
                True,

            "partition":
                "VALIDATION",
        },

        "candidates":
            candidate_results,

        "selection_status":
            selection_status,

        "selected_candidate":
            selected,
    }

    output_json.write_text(
        json.dumps(
            payload,
            indent=2,
            allow_nan=False,
        ),
        encoding="utf-8",
    )

    report = [

        "=" * 78,

        "STEP 7 THERMAL-ONLY PHYSICS WEIGHT GATE",

        "=" * 78,

        "",

        f"Learning rate : "
        f"{FROZEN_LEARNING_RATE:.10e}",

        f"Control MSE   : "
        f"{control_validation_mse:.10e}",

        "",

        "CANDIDATES",
    ]

    for row in candidate_results:

        report.append(

            f"fraction={row['fraction']:.3f} "

            f"lambda={row['lambda']:.10e} "

            f"epoch={row['best_epoch']} "

            f"valMSE={row['validation_mse']:.10e} "

            f"accuracyVsControl="
            f"{row['accuracy_improvement_vs_control_percent']:+.4f}% "

            f"residualMean="
            f"{row['residual_stability']['mean_improvement_percent']:+.4f}% "

            f"positiveReps="
            f"{row['residual_stability']['positive_replicates']}"
            f"/{AUDIT_REPLICATES} "

            f"jointPass="
            f"{row['joint_pass']}"
        )

    report.extend([

        "",

        f"Decision: "
        f"{selection_status}",

        "",

        "TRAIN updates             : YES",

        "VALIDATION selection      : YES",

        "ID/OOD/STRESS accessed   : NO",

        "Production-V1 modified   : NO",

        "Kinetics residuals       : NO",

        "",

        "STATUS: COMPLETE",
    ])

    output_txt.write_text(
        "\n".join(
            report
        )
        + "\n",
        encoding="utf-8",
    )

    print()

    print(
        "OUTPUT FILES"
    )

    print("-" * 78)

    print(
        output_json
    )

    print(
        output_txt
    )

    print()

    print(
        "ID/OOD/STRESS accessed : NO"
    )

    print(
        "Production-V1 modified : NO"
    )

    print()

    print("=" * 78)

    print(
        "STATUS: THERMAL-ONLY PHYSICS "
        "WEIGHT GATE COMPLETE"
    )

    print("=" * 78)


if __name__ == "__main__":
    main()