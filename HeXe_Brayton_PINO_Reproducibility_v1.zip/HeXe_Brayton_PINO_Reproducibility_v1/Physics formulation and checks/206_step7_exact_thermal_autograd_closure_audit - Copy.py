#!/usr/bin/env python3
"""
206_step7_exact_thermal_autograd_closure_audit.py

STEP 7 - EXACT THERMAL AUTOGRAD CLOSURE AUDIT

NO TRAINING.
NO HYPERPARAMETER TUNING.
NO ID/OOD/STRESS ACCESS.
NO DATASET MODIFICATION.

Purpose
-------
File 205 established that File-74 thermal physics is valid but cannot
be differentiated directly because core_cycle_from_bulk uses scipy
brentq.

This file does NOT replace the physics.

Instead it:

1. reproduces the exact File-74 thermal RHS using File-74's own
   constants and callable functions;
2. verifies that reproduction against
   MasterCoupledReferenceModel.derivatives();
3. wraps that exact RHS in a custom PyTorch autograd Function;
4. obtains derivatives numerically by central differences;
5. independently checks the numerical gradients;
6. benchmarks forward/backward cost.

This determines whether exact numerical differentiation of the
existing thermal closure is scientifically and computationally
suitable for PINO training.
"""

from __future__ import annotations

import importlib.util
import json
import math
import sys
import time
from pathlib import Path

import numpy as np
import torch


SEED = 20262060

CASES_PER_PARTITION = 4

POINTS_PER_CASE = 8

GRADIENT_CHECK_POINTS = 8

BENCHMARK_POINTS = 24

FORWARD_TOLERANCE = 1.0e-9

GRADIENT_RELATIVE_TOLERANCE = 5.0e-3


# Numerical differentiation steps.
#
# These are numerical-analysis settings only.
# They do NOT change any physical parameter.
RELATIVE_POWER_STEP = 1.0e-5
TEMPERATURE_STEP_K = 1.0e-3


# =====================================================================
# GENERAL
# =====================================================================

def find_root():

    current = Path.cwd().resolve()

    for path in [current, *current.parents]:

        if (
            path
            / "step6_dataset"
            / "production_v1"
        ).is_dir():

            return path

    raise FileNotFoundError(
        "Could not locate project root."
    )


def load_module(
    name,
    path,
):

    if not path.exists():

        raise FileNotFoundError(
            f"Required source not found:\n{path}"
        )

    spec = importlib.util.spec_from_file_location(
        name,
        str(path),
    )

    if (
        spec is None
        or spec.loader is None
    ):

        raise ImportError(
            f"Could not import:\n{path}"
        )

    module = importlib.util.module_from_spec(
        spec
    )

    sys.modules[name] = module

    spec.loader.exec_module(
        module
    )

    return module


def require_file(
    path,
):

    if not path.exists():

        raise FileNotFoundError(
            path
        )

    return path


def serializable(
    value,
):

    if isinstance(
        value,
        dict,
    ):

        return {
            key:
                serializable(item)
            for key, item
            in value.items()
        }

    if isinstance(
        value,
        list,
    ):

        return [
            serializable(item)
            for item
            in value
        ]

    if isinstance(
        value,
        np.ndarray,
    ):

        return value.tolist()

    if isinstance(
        value,
        np.floating,
    ):

        return float(value)

    if isinstance(
        value,
        np.integer,
    ):

        return int(value)

    return value


# =====================================================================
# EXACT FILE-74 THERMAL RHS
# =====================================================================

def exact_thermal_rhs(
    file74,
    model,
    power,
    T_fuel,
    T_block,
    T_bulk,
):
    """
    Exact transcription of the three thermal derivatives in File 74.

    No fitted parameter.
    No surrogate equation.
    No interpolation.
    """

    power = float(
        power
    )

    T_fuel = float(
        T_fuel
    )

    T_block = float(
        T_block
    )

    T_bulk = float(
        T_bulk
    )

    # ---------------------------------------------------------------
    # Reactor heat source
    # ---------------------------------------------------------------

    fission_power = (
        power
        * file74.FISSION_POWER_REF
    )

    fuel_heat_source = (
        file74.HEAT_TO_GAS_FRACTION
        * fission_power
    )

    # ---------------------------------------------------------------
    # Exact File-74 Brayton/core closure
    # ---------------------------------------------------------------

    (
        T_core_out,
        cycle,
    ) = model.core_cycle_from_bulk(
        T_bulk
    )

    T_core_in = float(
        cycle[
            "core_inlet_temperature"
        ]
    )

    T_core_out = float(
        T_core_out
    )

    # ---------------------------------------------------------------
    # Fuel -> coolant
    # ---------------------------------------------------------------

    (
        h_inner,
        _,
        _,
        _,
    ) = file74.raw_heat_transfer_coefficient(
        T_fuel,
        T_bulk,
    )

    UA_inner = (
        file74.HEAT_TRANSFER_SCALE
        * h_inner
        * file74.INNER_HEAT_AREA
    )

    Q_fuel_to_coolant = (
        UA_inner
        * (
            T_fuel
            - T_bulk
        )
    )

    # ---------------------------------------------------------------
    # Block -> coolant
    # ---------------------------------------------------------------

    (
        h_outer,
        _,
        _,
        _,
    ) = file74.raw_heat_transfer_coefficient(
        T_block,
        T_bulk,
    )

    UA_outer = (
        h_outer
        * file74.OUTER_HEAT_AREA
    )

    Q_block_to_coolant = (
        UA_outer
        * (
            T_block
            - T_bulk
        )
    )

    # ---------------------------------------------------------------
    # Thermal capacitances
    # ---------------------------------------------------------------

    C_fuel = (
        file74.FUEL_MASS
        * file74.solid_module.uo2_cp(
            T_fuel
        )
    )

    C_block = (
        file74.BLOCK_MASS
        * file74.solid_module.CP_MORE
    )

    # ---------------------------------------------------------------
    # Flow heat removal
    # ---------------------------------------------------------------

    Q_flow_out = (
        file74.M_DOT
        * file74.CP_HEXE
        * (
            T_core_out
            - T_core_in
        )
    )

    # ---------------------------------------------------------------
    # Exact File-74 derivatives
    # ---------------------------------------------------------------

    dT_fuel_dt = (
        (
            fuel_heat_source
            - Q_fuel_to_coolant
        )
        / C_fuel
    )

    dT_block_dt = (
        -Q_block_to_coolant
        / C_block
    )

    dT_bulk_dt = (
        (
            Q_fuel_to_coolant
            + Q_block_to_coolant
            - Q_flow_out
        )
        / file74.COOLANT_HEAT_CAPACITY
    )

    return np.asarray(
        [
            dT_fuel_dt,
            dT_block_dt,
            dT_bulk_dt,
        ],
        dtype=np.float64,
    )


# =====================================================================
# DIFFERENTIATION STEPS
# =====================================================================

def differentiation_steps(
    x,
):

    x = np.asarray(
        x,
        dtype=np.float64,
    )

    power_step = max(
        abs(
            x[0]
        )
        * RELATIVE_POWER_STEP,
        1.0e-7,
    )

    return np.asarray(
        [
            power_step,
            TEMPERATURE_STEP_K,
            TEMPERATURE_STEP_K,
            TEMPERATURE_STEP_K,
        ],
        dtype=np.float64,
    )


# =====================================================================
# NUMERICAL JACOBIAN
# =====================================================================

def numerical_jacobian(
    file74,
    model,
    x,
    step_multiplier=1.0,
):

    x = np.asarray(
        x,
        dtype=np.float64,
    )

    steps = (
        differentiation_steps(
            x
        )
        * step_multiplier
    )

    jacobian = np.zeros(
        (
            3,
            4,
        ),
        dtype=np.float64,
    )

    for variable_index in range(
        4
    ):

        step = float(
            steps[
                variable_index
            ]
        )

        x_plus = x.copy()

        x_minus = x.copy()

        x_plus[
            variable_index
        ] += step

        x_minus[
            variable_index
        ] -= step

        y_plus = exact_thermal_rhs(
            file74=file74,
            model=model,
            power=x_plus[0],
            T_fuel=x_plus[1],
            T_block=x_plus[2],
            T_bulk=x_plus[3],
        )

        y_minus = exact_thermal_rhs(
            file74=file74,
            model=model,
            power=x_minus[0],
            T_fuel=x_minus[1],
            T_block=x_minus[2],
            T_bulk=x_minus[3],
        )

        jacobian[
            :,
            variable_index
        ] = (
            y_plus
            - y_minus
        ) / (
            2.0
            * step
        )

    return jacobian


# =====================================================================
# CUSTOM AUTOGRAD
# =====================================================================

class ExactThermalRHSFunction(
    torch.autograd.Function
):

    @staticmethod
    def forward(
        ctx,
        x,
        file74,
        model,
    ):

        x_np = (
            x
            .detach()
            .cpu()
            .numpy()
            .astype(
                np.float64
            )
        )

        original_shape = (
            x_np.shape
        )

        flat = x_np.reshape(
            -1,
            4,
        )

        output = np.empty(
            (
                len(
                    flat
                ),
                3,
            ),
            dtype=np.float64,
        )

        for index, row in enumerate(
            flat
        ):

            output[
                index
            ] = exact_thermal_rhs(
                file74=file74,
                model=model,
                power=row[0],
                T_fuel=row[1],
                T_block=row[2],
                T_bulk=row[3],
            )

        ctx.file74 = file74

        ctx.model = model

        ctx.save_for_backward(
            x.detach()
        )

        output_shape = (
            original_shape[:-1]
            + (
                3,
            )
        )

        return torch.as_tensor(
            output.reshape(
                output_shape
            ),
            dtype=x.dtype,
            device=x.device,
        )

    @staticmethod
    def backward(
        ctx,
        grad_output,
    ):

        (
            x,
        ) = ctx.saved_tensors

        x_np = (
            x
            .detach()
            .cpu()
            .numpy()
            .astype(
                np.float64
            )
        )

        grad_output_np = (
            grad_output
            .detach()
            .cpu()
            .numpy()
            .astype(
                np.float64
            )
        )

        flat_x = x_np.reshape(
            -1,
            4,
        )

        flat_grad_output = (
            grad_output_np.reshape(
                -1,
                3,
            )
        )

        flat_grad_input = np.zeros(
            (
                len(
                    flat_x
                ),
                4,
            ),
            dtype=np.float64,
        )

        for index, row in enumerate(
            flat_x
        ):

            jacobian = numerical_jacobian(
                file74=ctx.file74,
                model=ctx.model,
                x=row,
                step_multiplier=1.0,
            )

            flat_grad_input[
                index
            ] = (
                jacobian.T
                @ flat_grad_output[
                    index
                ]
            )

        grad_input = (
            flat_grad_input.reshape(
                x_np.shape
            )
        )

        return (
            torch.as_tensor(
                grad_input,
                dtype=x.dtype,
                device=x.device,
            ),
            None,
            None,
        )


def exact_thermal_rhs_torch(
    x,
    file74,
    model,
):

    return ExactThermalRHSFunction.apply(
        x,
        file74,
        model,
    )


# =====================================================================
# SAMPLE STATES
# =====================================================================

def collect_states(
    file191,
    production,
    rng,
):

    global_state = file191.load_npy(
        production,
        "global_state.npy",
    )

    global_rho = file191.load_npy(
        production,
        "global_reactivity_delta_k_over_k.npy",
    )

    global_time = np.asarray(
        file191.load_npy(
            production,
            "global_time_s.npy",
        ),
        dtype=np.float64,
    )

    event_state = file191.load_npy(
        production,
        "step_event_state.npy",
    )

    event_rho = file191.load_npy(
        production,
        "step_event_reactivity_delta_k_over_k.npy",
    )

    event_time = np.asarray(
        file191.load_npy(
            production,
            "step_event_relative_time_s.npy",
        ),
        dtype=np.float64,
    )

    step_case_indices = np.asarray(
        file191.load_npy(
            production,
            "step_case_indices.npy",
        ),
        dtype=np.int64,
    )

    event_mapping = (
        file191
        .build_event_partition_mapping(
            step_case_indices
        )
    )

    samples = []

    for partition in [
        "TRAIN",
        "VALIDATION",
    ]:

        start, stop = (
            file191.PARTITIONS[
                partition
            ]
        )

        global_cases = np.arange(
            start,
            stop,
            dtype=np.int64,
        )

        event_cases = np.asarray(
            event_mapping[
                partition
            ],
            dtype=np.int64,
        )

        selected_global = rng.choice(
            global_cases,
            size=min(
                CASES_PER_PARTITION,
                len(
                    global_cases
                ),
            ),
            replace=False,
        )

        selected_event = rng.choice(
            event_cases,
            size=min(
                CASES_PER_PARTITION,
                len(
                    event_cases
                ),
            ),
            replace=False,
        )

        for case in selected_global:

            time_indices = rng.choice(
                len(
                    global_time
                ),
                size=min(
                    POINTS_PER_CASE,
                    len(
                        global_time
                    ),
                ),
                replace=False,
            )

            for time_index in time_indices:

                samples.append({

                    "partition":
                        partition,

                    "representation":
                        "GLOBAL",

                    "state":
                        np.asarray(
                            global_state[
                                case,
                                time_index
                            ],
                            dtype=np.float64,
                        ),

                    "rho":
                        float(
                            global_rho[
                                case,
                                time_index
                            ]
                        ),

                    "time":
                        float(
                            global_time[
                                time_index
                            ]
                        ),
                })

        for case in selected_event:

            time_indices = rng.choice(
                len(
                    event_time
                ),
                size=min(
                    POINTS_PER_CASE,
                    len(
                        event_time
                    ),
                ),
                replace=False,
            )

            for time_index in time_indices:

                samples.append({

                    "partition":
                        partition,

                    "representation":
                        "EVENT",

                    "state":
                        np.asarray(
                            event_state[
                                case,
                                time_index
                            ],
                            dtype=np.float64,
                        ),

                    "rho":
                        float(
                            event_rho[
                                case,
                                time_index
                            ]
                        ),

                    "time":
                        float(
                            event_time[
                                time_index
                            ]
                        ),
                })

    return samples


# =====================================================================
# MAIN
# =====================================================================

def main():

    root = find_root()

    production = (
        root
        / "step6_dataset"
        / "production_v1"
    )

    file191 = load_module(
        "file191_206",
        require_file(
            root
            / "191_step7_model_b_training.py"
        ),
    )

    file74 = load_module(
        "file74_206",
        require_file(
            root
            / "74_master_coupled_reference_model.py"
        ),
    )

    file205_path = (
        root
        / "step7_pino"
        / "physics_informed"
        / "thermal_preflight"
        / "205_thermal_physics_interface_preflight.json"
    )

    output_dir = (
        root
        / "step7_pino"
        / "physics_informed"
        / "thermal_preflight"
    )

    output_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    output_json = (
        output_dir
        / "206_exact_thermal_autograd_closure_audit.json"
    )

    output_txt = (
        output_dir
        / "206_exact_thermal_autograd_closure_audit.txt"
    )

    print("=" * 78)

    print(
        "STEP 7 EXACT THERMAL AUTOGRAD CLOSURE AUDIT"
    )

    print("=" * 78)

    print(
        f"Project root : {root}"
    )

    # ---------------------------------------------------------------
    # FILE 205 CONTRACT
    # ---------------------------------------------------------------

    file205 = json.loads(
        require_file(
            file205_path
        ).read_text(
            encoding="utf-8"
        )
    )

    if (
        file205.get(
            "status"
        )
        !=
        "THERMAL_SOURCE_VALID_BUT_DIFFERENTIABLE_CLOSURE_REQUIRED"
    ):

        raise RuntimeError(
            "Unexpected File-205 status."
        )

    print()

    print(
        "FILE-205 STATUS : PASS"
    )

    # ---------------------------------------------------------------
    # AUTHORITATIVE MODEL
    # ---------------------------------------------------------------

    model = (
        file74
        .MasterCoupledReferenceModel()
    )

    rng = np.random.default_rng(
        SEED
    )

    samples = collect_states(
        file191=file191,
        production=production,
        rng=rng,
    )

    print()

    print(
        f"Audit samples : {len(samples)}"
    )

    # ---------------------------------------------------------------
    # FORWARD EQUIVALENCE
    # ---------------------------------------------------------------

    differences = []

    print()

    print(
        "FORWARD EQUIVALENCE AUDIT"
    )

    print("-" * 78)

    for sample in samples:

        state = sample[
            "state"
        ]

        rho_value = sample[
            "rho"
        ]

        model.set_external_reactivity(
            lambda _t, value=rho_value:
                value
        )

        authoritative = np.asarray(
            model.derivatives(
                sample[
                    "time"
                ],
                state,
            ),
            dtype=np.float64,
        )[
            7:10
        ]

        reproduced = exact_thermal_rhs(
            file74=file74,
            model=model,
            power=state[0],
            T_fuel=state[7],
            T_block=state[8],
            T_bulk=state[9],
        )

        differences.append(
            reproduced
            - authoritative
        )

    differences = np.asarray(
        differences,
        dtype=np.float64,
    )

    forward_max_abs = float(
        np.max(
            np.abs(
                differences
            )
        )
    )

    forward_rms = float(
        np.sqrt(
            np.mean(
                differences**2
            )
        )
    )

    forward_pass = bool(
        forward_max_abs
        <= FORWARD_TOLERANCE
    )

    print(
        f"Maximum absolute difference : "
        f"{forward_max_abs:.12e}"
    )

    print(
        f"RMS difference              : "
        f"{forward_rms:.12e}"
    )

    print(
        f"Forward equivalence         : "
        f"{'PASS' if forward_pass else 'FAIL'}"
    )

    if not forward_pass:

        raise RuntimeError(
            "Exact thermal RHS transcription "
            "does not match File 74."
        )

    # ---------------------------------------------------------------
    # GRADIENT CHECK
    # ---------------------------------------------------------------

    gradient_samples = samples[
        :GRADIENT_CHECK_POINTS
    ]

    gradient_errors = []

    print()

    print(
        "NUMERICAL AUTOGRAD GRADIENT AUDIT"
    )

    print("-" * 78)

    weights = np.asarray(
        [
            0.37,
            -0.21,
            0.42,
        ],
        dtype=np.float64,
    )

    for sample_index, sample in enumerate(
        gradient_samples,
        start=1,
    ):

        state = sample[
            "state"
        ]

        x_np = np.asarray(
            [
                state[0],
                state[7],
                state[8],
                state[9],
            ],
            dtype=np.float64,
        )

        x = torch.tensor(
            x_np,
            dtype=torch.float64,
            requires_grad=True,
        )

        y = exact_thermal_rhs_torch(
            x,
            file74,
            model,
        )

        weight_tensor = torch.tensor(
            weights,
            dtype=torch.float64,
        )

        scalar = torch.sum(
            y
            * weight_tensor
        )

        scalar.backward()

        autograd_gradient = (
            x.grad
            .detach()
            .cpu()
            .numpy()
            .astype(
                np.float64
            )
        )

        independent_jacobian = (
            numerical_jacobian(
                file74=file74,
                model=model,
                x=x_np,
                step_multiplier=0.5,
            )
        )

        independent_gradient = (
            independent_jacobian.T
            @ weights
        )

        denominator = np.maximum(
            np.abs(
                independent_gradient
            ),
            1.0e-10,
        )

        relative_error = (
            np.abs(
                autograd_gradient
                - independent_gradient
            )
            / denominator
        )

        maximum_relative_error = float(
            np.max(
                relative_error
            )
        )

        gradient_errors.append(
            maximum_relative_error
        )

        print(
            f"Sample {sample_index:02d} | "
            f"max relative gradient error="
            f"{maximum_relative_error:.8e}"
        )

    gradient_max_error = float(
        np.max(
            gradient_errors
        )
    )

    gradient_mean_error = float(
        np.mean(
            gradient_errors
        )
    )

    gradient_pass = bool(
        gradient_max_error
        <= GRADIENT_RELATIVE_TOLERANCE
    )

    print()

    print(
        f"Maximum relative error : "
        f"{gradient_max_error:.10e}"
    )

    print(
        f"Mean relative error    : "
        f"{gradient_mean_error:.10e}"
    )

    print(
        f"Gradient audit         : "
        f"{'PASS' if gradient_pass else 'FAIL'}"
    )

    # ---------------------------------------------------------------
    # RUNTIME BENCHMARK
    # ---------------------------------------------------------------

    benchmark_samples = samples[
        :BENCHMARK_POINTS
    ]

    benchmark_x_np = np.asarray(
        [
            [
                sample[
                    "state"
                ][0],
                sample[
                    "state"
                ][7],
                sample[
                    "state"
                ][8],
                sample[
                    "state"
                ][9],
            ]
            for sample
            in benchmark_samples
        ],
        dtype=np.float64,
    )

    print()

    print(
        "EXACT CLOSURE RUNTIME BENCHMARK"
    )

    print("-" * 78)

    x_forward = torch.tensor(
        benchmark_x_np,
        dtype=torch.float64,
        requires_grad=False,
    )

    start = time.perf_counter()

    with torch.no_grad():

        _ = exact_thermal_rhs_torch(
            x_forward,
            file74,
            model,
        )

    forward_seconds = (
        time.perf_counter()
        - start
    )

    x_backward = torch.tensor(
        benchmark_x_np,
        dtype=torch.float64,
        requires_grad=True,
    )

    start = time.perf_counter()

    y = exact_thermal_rhs_torch(
        x_backward,
        file74,
        model,
    )

    loss = torch.mean(
        y**2
    )

    loss.backward()

    forward_backward_seconds = (
        time.perf_counter()
        - start
    )

    n_benchmark = len(
        benchmark_samples
    )

    forward_ms_per_point = (
        1000.0
        * forward_seconds
        / n_benchmark
    )

    forward_backward_ms_per_point = (
        1000.0
        * forward_backward_seconds
        / n_benchmark
    )

    print(
        f"Points benchmarked          : "
        f"{n_benchmark}"
    )

    print(
        f"Forward total               : "
        f"{forward_seconds:.6f} s"
    )

    print(
        f"Forward ms/point            : "
        f"{forward_ms_per_point:.6f}"
    )

    print(
        f"Forward+backward total      : "
        f"{forward_backward_seconds:.6f} s"
    )

    print(
        f"Forward+backward ms/point   : "
        f"{forward_backward_ms_per_point:.6f}"
    )

    # ---------------------------------------------------------------
    # FINAL DECISION
    # ---------------------------------------------------------------

    if (
        forward_pass
        and
        gradient_pass
    ):

        final_status = (
            "EXACT_NUMERICAL_AUTOGRAD_THERMAL_CLOSURE_VERIFIED"
        )

    elif forward_pass:

        final_status = (
            "THERMAL_FORWARD_VERIFIED_GRADIENT_CHECK_REQUIRED"
        )

    else:

        final_status = (
            "THERMAL_CLOSURE_CHECK_REQUIRED"
        )

    print()

    print("=" * 78)

    print(
        "THERMAL DIFFERENTIABLE-CLOSURE DECISION"
    )

    print("=" * 78)

    print(
        f"Forward equivalence : "
        f"{'PASS' if forward_pass else 'FAIL'}"
    )

    print(
        f"Gradient check      : "
        f"{'PASS' if gradient_pass else 'FAIL'}"
    )

    print()

    print(
        f"STATUS: {final_status}"
    )

    # ---------------------------------------------------------------
    # SAVE
    # ---------------------------------------------------------------

    payload = {

        "script":
            "206_step7_exact_thermal_autograd_closure_audit.py",

        "status":
            final_status,

        "training_performed":
            False,

        "hyperparameter_tuning":
            False,

        "dataset_modified":
            False,

        "id_ood_stress_accessed":
            False,

        "physics_changed":
            False,

        "closure_method":
            (
                "Exact File-74 forward physics with "
                "central-difference custom autograd"
            ),

        "forward_equivalence": {

            "maximum_absolute_difference":
                forward_max_abs,

            "rms_difference":
                forward_rms,

            "tolerance":
                FORWARD_TOLERANCE,

            "pass":
                forward_pass,
        },

        "gradient_audit": {

            "samples":
                len(
                    gradient_samples
                ),

            "maximum_relative_error":
                gradient_max_error,

            "mean_relative_error":
                gradient_mean_error,

            "tolerance":
                GRADIENT_RELATIVE_TOLERANCE,

            "pass":
                gradient_pass,

            "primary_step": {

                "relative_power_step":
                    RELATIVE_POWER_STEP,

                "temperature_step_K":
                    TEMPERATURE_STEP_K,
            },

            "independent_check_step_multiplier":
                0.5,
        },

        "runtime": {

            "benchmark_points":
                n_benchmark,

            "forward_total_seconds":
                forward_seconds,

            "forward_ms_per_point":
                forward_ms_per_point,

            "forward_backward_total_seconds":
                forward_backward_seconds,

            "forward_backward_ms_per_point":
                forward_backward_ms_per_point,
        },
    }

    output_json.write_text(
        json.dumps(
            serializable(
                payload
            ),
            indent=2,
            allow_nan=False,
        ),
        encoding="utf-8",
    )

    report = [

        "=" * 78,

        "STEP 7 EXACT THERMAL AUTOGRAD CLOSURE AUDIT",

        "=" * 78,

        "",

        f"Forward max difference : "
        f"{forward_max_abs:.12e}",

        f"Gradient max rel error : "
        f"{gradient_max_error:.12e}",

        "",

        f"Forward ms/point       : "
        f"{forward_ms_per_point:.6f}",

        f"Forward+backward ms/pt : "
        f"{forward_backward_ms_per_point:.6f}",

        "",

        f"STATUS: "
        f"{final_status}",

        "",

        "Training performed     : NO",

        "Physics changed        : NO",

        "ID/OOD/STRESS accessed : NO",

        "Production-V1 modified : NO",
    ]

    output_txt.write_text(
        "\n".join(
            report
        )
        + "\n",
        encoding="utf-8",
    )

    print()

    print(
        "OUTPUT FILES"
    )

    print("-" * 78)

    print(
        output_json
    )

    print(
        output_txt
    )

    print()

    print(
        "Training performed     : NO"
    )

    print(
        "Physics changed        : NO"
    )

    print(
        "ID/OOD/STRESS accessed : NO"
    )

    print(
        "Production-V1 modified : NO"
    )


if __name__ == "__main__":
    main()