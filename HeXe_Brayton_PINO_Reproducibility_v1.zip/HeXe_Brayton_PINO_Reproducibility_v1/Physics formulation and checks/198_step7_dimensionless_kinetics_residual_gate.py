#!/usr/bin/env python3
"""
198_step7_dimensionless_kinetics_residual_gate.py

STEP 7 - DIMENSIONLESS KINETICS RESIDUAL GATE

No training.
No dataset modification.
No ID/OOD/STRESS access.

Purpose
-------
Replace the ill-conditioned net-RHS residual normalization identified
by File 197 with a physics-derived nondimensionalization.

Residual scales:

    S_P  = beta_eff / Lambda

    S_Ci = beta_i / Lambda

These scales are derived only from the frozen point-kinetics parameters.

They are:
- independent of TRAIN/VALIDATION/test trajectory statistics,
- identical for global and event representations,
- physically interpretable,
- insensitive to near-equilibrium cancellation of large kinetics terms.

This file:
1. verifies File-197 completion,
2. constructs the dimensionless kinetics scales,
3. evaluates the reference-trajectory residual magnitudes,
4. evaluates the pretrained Model-B residual magnitudes,
5. derives a TRAIN-only loss-weight scale for later sensitivity training.

No physics weight is frozen here.
"""

from __future__ import annotations

import importlib.util
import json
import math
import sys
from pathlib import Path

import numpy as np
import torch


SEED = 20261002

TRAIN_PROBE_BATCHES = 24
VALIDATION_PROBE_BATCHES = 8


def find_root():

    current = Path.cwd().resolve()

    for path in [current, *current.parents]:

        if (
            path
            / "step6_dataset"
            / "production_v1"
        ).is_dir():

            return path

    raise FileNotFoundError(
        "Could not locate He-Xe PINO project root."
    )


def load_module(
    name,
    path,
):

    if not path.exists():

        raise FileNotFoundError(
            f"Required source not found:\n{path}"
        )

    spec = importlib.util.spec_from_file_location(
        name,
        str(path),
    )

    if (
        spec is None
        or spec.loader is None
    ):

        raise ImportError(
            f"Could not import:\n{path}"
        )

    module = importlib.util.module_from_spec(
        spec
    )

    sys.modules[name] = module

    spec.loader.exec_module(
        module
    )

    return module


def require_file(
    path,
):

    if not path.exists():

        raise FileNotFoundError(
            path
        )

    return path


def main():

    root = find_root()

    production = (
        root
        / "step6_dataset"
        / "production_v1"
    )

    file191_path = (
        root
        / "191_step7_model_b_training.py"
    )

    file196_path = (
        root
        / "196_step7_kinetics_physics_preflight_gate.py"
    )

    file70_path = (
        root
        / "70_reference_reactor_kinetics.py"
    )

    file74_path = (
        root
        / "74_master_coupled_reference_model.py"
    )

    file197_json = (
        root
        / "step7_pino"
        / "physics_informed"
        / "preflight"
        / "197_reference_kinetics_residual_audit.json"
    )

    checkpoint_path = (
        root
        / "step7_pino"
        / "model_b_training"
        / "model_b_best.pt"
    )

    output_dir = (
        root
        / "step7_pino"
        / "physics_informed"
        / "preflight"
    )

    output_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    output_json = (
        output_dir
        / "198_dimensionless_kinetics_residual_gate.json"
    )

    output_txt = (
        output_dir
        / "198_dimensionless_kinetics_residual_gate.txt"
    )

    print("=" * 78)

    print(
        "STEP 7 DIMENSIONLESS KINETICS RESIDUAL GATE"
    )

    print("=" * 78)

    print(
        f"Project root : {root}"
    )

    # ================================================================
    # LOAD AUTHORITATIVE SOURCES
    # ================================================================

    file191 = load_module(
        "file191_198",
        require_file(
            file191_path
        ),
    )

    file196 = load_module(
        "file196_198",
        require_file(
            file196_path
        ),
    )

    file70 = load_module(
        "file70_198",
        require_file(
            file70_path
        ),
    )

    file74 = load_module(
        "file74_198",
        require_file(
            file74_path
        ),
    )

    require_file(
        file197_json
    )

    reference_audit = json.loads(
        file197_json.read_text(
            encoding="utf-8"
        )
    )

    if (
        reference_audit.get(
            "status"
        )
        != "REFERENCE_RESIDUAL_AUDIT_COMPLETE"
    ):

        raise RuntimeError(
            "File-197 audit is not complete."
        )

    print()

    print(
        "FILE-197 REFERENCE AUDIT : PASS"
    )

    # ================================================================
    # FROZEN KINETICS PARAMETERS
    # ================================================================

    beta = np.asarray(
        file70.BETA,
        dtype=np.float64,
    )

    lambdas = np.asarray(
        file70.LAMBDA,
        dtype=np.float64,
    )

    generation_time = float(
        file70.GENERATION_TIME
    )

    beta_total = float(
        np.sum(
            beta
        )
    )

    fuel_coeff = np.asarray(
        file70.FUEL_COEFF,
        dtype=np.float64,
    )

    block_coeff = np.asarray(
        file70.BLOCK_COEFF,
        dtype=np.float64,
    )

    fuel_reference = float(
        file74.T_FUEL_REF
    )

    block_reference = float(
        file74.T_BLOCK_REF
    )

    # ================================================================
    # PHYSICS-DERIVED DIMENSIONLESS SCALES
    # ================================================================

    physics_scales = np.concatenate(
        [
            np.array(
                [
                    beta_total
                    / generation_time
                ],
                dtype=np.float64,
            ),
            beta
            / generation_time,
        ]
    )

    residual_names = [

        "power_kinetics",

        "precursor_1",

        "precursor_2",

        "precursor_3",

        "precursor_4",

        "precursor_5",

        "precursor_6",
    ]

    if (
        physics_scales.shape
        != (7,)
    ):

        raise RuntimeError(
            "Unexpected dimensionless scale shape."
        )

    if not np.all(
        np.isfinite(
            physics_scales
        )
    ):

        raise RuntimeError(
            "Non-finite physics scale."
        )

    if not np.all(
        physics_scales > 0.0
    ):

        raise RuntimeError(
            "Non-positive physics scale."
        )

    print()

    print(
        "PHYSICS-DERIVED RESIDUAL SCALES"
    )

    print("-" * 78)

    for index, name in enumerate(
        residual_names
    ):

        print(
            f"{name:<20} "
            f"{physics_scales[index]:.10e}"
        )

    print()

    print(
        "Scale source: frozen beta_i, beta_eff and Lambda"
    )

    print(
        "Dataset-derived scale: NO"
    )

    print(
        "Global/event scale difference: NO"
    )

    # ================================================================
    # REFERENCE-TRAJECTORY AUDIT
    # ================================================================

    print()

    print(
        "REFERENCE-TRAJECTORY DIMENSIONLESS RESIDUAL AUDIT"
    )

    print("-" * 78)

    reference_results = {}

    for partition in [
        "TRAIN",
        "VALIDATION",
    ]:

        reference_results[
            partition
        ] = {}

        for representation in [
            "global",
            "event",
        ]:

            source = (
                reference_audit[
                    "results"
                ][
                    partition
                ][
                    representation
                ]
            )

            residual_rms = np.asarray(
                source[
                    "residual_rms"
                ],
                dtype=np.float64,
            )

            dimensionless_mse = (
                residual_rms
                / physics_scales
            ) ** 2

            reference_results[
                partition
            ][
                representation
            ] = {

                "residual_rms":
                    residual_rms.tolist(),

                "dimensionless_mse":
                    dimensionless_mse.tolist(),

                "mean_dimensionless_mse":
                    float(
                        np.mean(
                            dimensionless_mse
                        )
                    ),

                "max_dimensionless_mse":
                    float(
                        np.max(
                            dimensionless_mse
                        )
                    ),
            }

            print()

            print(
                f"{partition} {representation.upper()}"
            )

            for index, name in enumerate(
                residual_names
            ):

                print(
                    f"  {name:<18} "
                    f"MSE={dimensionless_mse[index]:.8e}"
                )

            print(
                "  Mean dimensionless MSE : "
                f"{np.mean(dimensionless_mse):.8e}"
            )

    # ================================================================
    # DEVICE
    # ================================================================

    device = torch.device(
        "cuda"
        if torch.cuda.is_available()
        else "cpu"
    )

    print()

    print(
        f"Device : {device}"
    )

    if device.type == "cuda":

        print(
            "GPU    : "
            + torch.cuda.get_device_name(
                0
            )
        )

    # ================================================================
    # DATA
    # ================================================================

    global_time = np.asarray(
        file191.load_npy(
            production,
            "global_time_s.npy",
        ),
        dtype=np.float64,
    )

    global_rho = file191.load_npy(
        production,
        "global_reactivity_delta_k_over_k.npy",
    )

    global_state = file191.load_npy(
        production,
        "global_state.npy",
    )

    event_time = np.asarray(
        file191.load_npy(
            production,
            "step_event_relative_time_s.npy",
        ),
        dtype=np.float64,
    )

    event_rho = file191.load_npy(
        production,
        "step_event_reactivity_delta_k_over_k.npy",
    )

    event_state = file191.load_npy(
        production,
        "step_event_state.npy",
    )

    step_case_indices = np.asarray(
        file191.load_npy(
            production,
            "step_case_indices.npy",
        ),
        dtype=np.int64,
    )

    event_mapping = (
        file191
        .build_event_partition_mapping(
            step_case_indices
        )
    )

    global_time_norm = (
        file191.normalize_time(
            global_time
        )
    )

    event_time_norm = (
        file191.normalize_time(
            event_time
        )
    )

    # ================================================================
    # CHECKPOINT
    # ================================================================

    checkpoint = torch.load(
        require_file(
            checkpoint_path
        ),
        map_location="cpu",
        weights_only=False,
    )

    normalization = (
        checkpoint[
            "normalization"
        ]
    )

    rho_mean = float(
        normalization[
            "rho_mean"
        ]
    )

    rho_std = float(
        normalization[
            "rho_std"
        ]
    )

    state_mean = np.asarray(
        normalization[
            "state_mean"
        ],
        dtype=np.float64,
    )

    state_std = np.asarray(
        normalization[
            "state_std"
        ],
        dtype=np.float64,
    )

    model = (
        file191
        .ModelB()
        .to(device)
    )

    model.load_state_dict(
        checkpoint[
            "model_state_dict"
        ]
    )

    model.eval()

    for parameter in model.parameters():

        parameter.requires_grad_(
            False
        )

    print()

    print(
        "Model-B checkpoint : LOADED"
    )

    print(
        f"Checkpoint epoch   : "
        f"{checkpoint.get('epoch')}"
    )

    # ================================================================
    # TORCH PHYSICS CONSTANTS
    # ================================================================

    beta_t = torch.as_tensor(
        beta,
        dtype=torch.float32,
        device=device,
    )

    lambdas_t = torch.as_tensor(
        lambdas,
        dtype=torch.float32,
        device=device,
    )

    fuel_coeff_t = torch.as_tensor(
        fuel_coeff,
        dtype=torch.float32,
        device=device,
    )

    block_coeff_t = torch.as_tensor(
        block_coeff,
        dtype=torch.float32,
        device=device,
    )

    # ================================================================
    # MODEL-B RESIDUAL PROBE
    # ================================================================

    print()

    print(
        "PRETRAINED MODEL-B DIMENSIONLESS PHYSICS PROBE"
    )

    print("-" * 78)

    train_probe = file196.probe_partition(
        model=model,
        file191=file191,
        partition_name="TRAIN",
        global_rho=global_rho,
        global_state=global_state,
        event_rho=event_rho,
        event_state=event_state,
        event_mapping=event_mapping,
        global_time=global_time,
        event_time=event_time,
        global_time_norm=global_time_norm,
        event_time_norm=event_time_norm,
        rho_mean=rho_mean,
        rho_std=rho_std,
        state_mean=state_mean,
        state_std=state_std,
        global_scale=physics_scales,
        event_scale=physics_scales,
        beta_t=beta_t,
        lambdas_t=lambdas_t,
        generation_time=generation_time,
        fuel_coeff_t=fuel_coeff_t,
        block_coeff_t=block_coeff_t,
        fuel_reference=fuel_reference,
        block_reference=block_reference,
        number_batches=TRAIN_PROBE_BATCHES,
        rng=np.random.default_rng(
            SEED + 198
        ),
        device=device,
    )

    validation_probe = file196.probe_partition(
        model=model,
        file191=file191,
        partition_name="VALIDATION",
        global_rho=global_rho,
        global_state=global_state,
        event_rho=event_rho,
        event_state=event_state,
        event_mapping=event_mapping,
        global_time=global_time,
        event_time=event_time,
        global_time_norm=global_time_norm,
        event_time_norm=event_time_norm,
        rho_mean=rho_mean,
        rho_std=rho_std,
        state_mean=state_mean,
        state_std=state_std,
        global_scale=physics_scales,
        event_scale=physics_scales,
        beta_t=beta_t,
        lambdas_t=lambdas_t,
        generation_time=generation_time,
        fuel_coeff_t=fuel_coeff_t,
        block_coeff_t=block_coeff_t,
        fuel_reference=fuel_reference,
        block_reference=block_reference,
        number_batches=VALIDATION_PROBE_BATCHES,
        rng=np.random.default_rng(
            SEED + 298
        ),
        device=device,
    )

    print(
        "TRAIN"
    )

    print(
        f"  Global data loss     : "
        f"{train_probe['global_data_loss']:.8e}"
    )

    print(
        f"  Global physics loss  : "
        f"{train_probe['global_physics_loss']:.8e}"
    )

    print(
        f"  Event data loss      : "
        f"{train_probe['event_data_loss']:.8e}"
    )

    print(
        f"  Event physics loss   : "
        f"{train_probe['event_physics_loss']:.8e}"
    )

    print(
        f"  Combined data loss   : "
        f"{train_probe['combined_data_loss']:.8e}"
    )

    print(
        f"  Combined physics loss: "
        f"{train_probe['combined_physics_loss']:.8e}"
    )

    print()

    print(
        "VALIDATION"
    )

    print(
        f"  Combined data loss   : "
        f"{validation_probe['combined_data_loss']:.8e}"
    )

    print(
        f"  Combined physics loss: "
        f"{validation_probe['combined_physics_loss']:.8e}"
    )

    # ================================================================
    # STATE CONTRIBUTIONS
    # ================================================================

    train_global_states = np.asarray(
        train_probe[
            "global_state_physics_mse"
        ],
        dtype=np.float64,
    )

    train_event_states = np.asarray(
        train_probe[
            "event_state_physics_mse"
        ],
        dtype=np.float64,
    )

    global_sum = float(
        np.sum(
            train_global_states
        )
    )

    event_sum = float(
        np.sum(
            train_event_states
        )
    )

    global_share = (
        train_global_states
        / max(
            global_sum,
            1.0e-30,
        )
    )

    event_share = (
        train_event_states
        / max(
            event_sum,
            1.0e-30,
        )
    )

    print()

    print(
        "TRAIN PHYSICS-LOSS CONTRIBUTION BY EQUATION"
    )

    print("-" * 78)

    for index, name in enumerate(
        residual_names
    ):

        print(
            f"{name:<20} "
            f"globalMSE={train_global_states[index]:.8e} "
            f"globalShare={100.0 * global_share[index]:6.2f}% "
            f"eventMSE={train_event_states[index]:.8e} "
            f"eventShare={100.0 * event_share[index]:6.2f}%"
        )

    # ================================================================
    # TRAIN-DERIVED WEIGHT SCALE
    # ================================================================

    physics_loss = float(
        train_probe[
            "combined_physics_loss"
        ]
    )

    data_loss = float(
        train_probe[
            "combined_data_loss"
        ]
    )

    if (
        not math.isfinite(
            physics_loss
        )
        or physics_loss <= 0.0
    ):

        raise RuntimeError(
            "Invalid Model-B physics loss."
        )

    balancing_weight = (
        data_loss
        / physics_loss
    )

    sensitivity_weights = [

        0.1
        * balancing_weight,

        balancing_weight,

        10.0
        * balancing_weight,
    ]

    print()

    print(
        "TRAIN-DERIVED LOSS-WEIGHT SCALE"
    )

    print("-" * 78)

    print(
        f"Data loss           : "
        f"{data_loss:.8e}"
    )

    print(
        f"Physics loss        : "
        f"{physics_loss:.8e}"
    )

    print(
        f"Equal-scale lambda  : "
        f"{balancing_weight:.8e}"
    )

    print(
        "Sensitivity candidates:"
    )

    for value in (
        sensitivity_weights
    ):

        print(
            f"  {value:.8e}"
        )

    print()

    print(
        "Weight status: DIAGNOSTIC ONLY, NOT FROZEN"
    )

    # ================================================================
    # FINITE AUDIT
    # ================================================================

    values = [

        *physics_scales.tolist(),

        data_loss,

        physics_loss,

        balancing_weight,

        validation_probe[
            "combined_data_loss"
        ],

        validation_probe[
            "combined_physics_loss"
        ],

        *train_global_states.tolist(),

        *train_event_states.tolist(),
    ]

    finite_pass = all(
        math.isfinite(
            float(value)
        )
        for value
        in values
    )

    gate_pass = finite_pass

    # ================================================================
    # SAVE
    # ================================================================

    payload = {

        "script":
            "198_step7_dimensionless_kinetics_residual_gate.py",

        "status":
            (
                "PASS"
                if gate_pass
                else "CHECK_REQUIRED"
            ),

        "training_performed":
            False,

        "dataset_modified":
            False,

        "id_ood_stress_accessed":
            False,

        "normalization_contract": {

            "power_scale":
                "beta_eff / Lambda",

            "precursor_scale":
                "beta_i / Lambda",

            "dataset_derived":
                False,

            "representation_specific":
                False,

            "physical_units_before_scaling":
                True,
        },

        "residual_names":
            residual_names,

        "physics_scales":
            physics_scales.tolist(),

        "reference_trajectory_audit":
            reference_results,

        "model_b_train_probe":
            train_probe,

        "model_b_validation_probe":
            validation_probe,

        "train_global_equation_share":
            global_share.tolist(),

        "train_event_equation_share":
            event_share.tolist(),

        "weight_scale": {

            "equal_contribution":
                balancing_weight,

            "sensitivity_candidates":
                sensitivity_weights,

            "status":
                "DIAGNOSTIC_ONLY_NOT_FROZEN",
        },
    }

    output_json.write_text(
        json.dumps(
            payload,
            indent=2,
            allow_nan=False,
        ),
        encoding="utf-8",
    )

    report = [

        "=" * 78,

        "STEP 7 DIMENSIONLESS KINETICS RESIDUAL GATE",

        "=" * 78,

        "",

        "Residual normalization:",

        "Power      : beta_eff / Lambda",

        "Precursors : beta_i / Lambda",

        "",

        "Dataset-derived residual scales : NO",

        "Global/event-specific scales    : NO",

        "Training performed              : NO",

        "ID/OOD/STRESS accessed          : NO",

        "",

        f"TRAIN data loss    : "
        f"{data_loss:.10e}",

        f"TRAIN physics loss : "
        f"{physics_loss:.10e}",

        f"Balance lambda     : "
        f"{balancing_weight:.10e}",

        "",

        f"STATUS: "
        f"{'PASS' if gate_pass else 'CHECK REQUIRED'}",
    ]

    output_txt.write_text(
        "\n".join(
            report
        )
        + "\n",
        encoding="utf-8",
    )

    print()

    print(
        "OUTPUT FILES"
    )

    print("-" * 78)

    print(
        output_json
    )

    print(
        output_txt
    )

    print()

    print(
        "Training performed : NO"
    )

    print(
        "Dataset modified   : NO"
    )

    print(
        "ID/OOD/STRESS used : NO"
    )

    print()

    print("=" * 78)

    print(
        "STATUS: DIMENSIONLESS KINETICS "
        "RESIDUAL GATE "
        + (
            "PASS"
            if gate_pass
            else "CHECK REQUIRED"
        )
    )

    print("=" * 78)


if __name__ == "__main__":
    main()