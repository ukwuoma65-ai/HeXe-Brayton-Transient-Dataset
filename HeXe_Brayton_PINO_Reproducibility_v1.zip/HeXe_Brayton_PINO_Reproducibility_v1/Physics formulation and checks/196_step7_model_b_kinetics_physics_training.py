#!/usr/bin/env python3
"""
196_step7_model_b_kinetics_physics_training.py

STEP 7 - FIRST PHYSICS-INFORMED ABLATION

BASE MODEL:
    Model-B Dual-Resolution Coordinate DeepONet

ABLATION:
    Model-B
        +
    reactor point-kinetics residuals
        +
    delayed-neutron precursor residuals
        +
    frozen fuel/block temperature-feedback reactivity

IMPORTANT:
    - Production-V1 is NOT modified.
    - Model-B architecture is NOT modified.
    - Model-B checkpoint is used as initialization.
    - TRAIN normalization stored in Model-B checkpoint is reused.
    - ID/OOD/STRESS are NOT used during training.
    - VALIDATION is used only for data-based early stopping.
    - Thermal residuals are NOT included in this file.
    - Brayton/core thermal residuals are NOT included in this file.

PURPOSE:
    Isolate the contribution of reactor-kinetics physics before adding
    thermal and Brayton physics.
"""

from __future__ import annotations

import importlib.util
import json
import math
import random
import time
from pathlib import Path
import sys

import numpy as np
import torch
import torch.nn as nn


# =====================================================================
# FROZEN DATASET CONTRACT
# =====================================================================

TOTAL_CASES = 2177
GLOBAL_POINTS = 601

EVENT_CASES = 1088
EVENT_POINTS = 1021

N_STATES = 10

PARTITIONS = {
    "TRAIN": (0, 1025),
    "VALIDATION": (1025, 1281),
    "ID_TEST": (1281, 1537),
    "OOD_NEG_TEST": (1537, 1793),
    "OOD_POS_TEST": (1793, 2049),
    "STRESS_TEST": (2049, 2177),
}

EVENT_PARTITION_COUNTS = {
    "TRAIN": 512,
    "VALIDATION": 128,
    "ID_TEST": 128,
    "OOD_NEG_TEST": 128,
    "OOD_POS_TEST": 128,
    "STRESS_TEST": 64,
}


# =====================================================================
# TRAINING CONFIGURATION
# =====================================================================

SEED = 20261002

MAX_EPOCHS = 20

BATCH_SIZE = 2

GLOBAL_QUERY_POINTS = 16

EVENT_FAST_QUERY_POINTS = 16
EVENT_SLOW_QUERY_POINTS = 4

LEARNING_RATE = 2.0e-4

WEIGHT_DECAY = 0.0

GRADIENT_CLIP = 1.0

EARLY_STOPPING_PATIENCE = 5

MIN_VALIDATION_IMPROVEMENT = 1.0e-6

PHYSICS_WEIGHT = 1.0


# =====================================================================
# UTILITIES
# =====================================================================

def find_project_root() -> Path:

    current = Path.cwd().resolve()

    for path in [current, *current.parents]:

        if (
            path
            / "step6_dataset"
            / "production_v1"
        ).is_dir():

            return path

    raise FileNotFoundError(
        "Could not locate He-Xe PINO project root."
    )


def load_module_from_file(
    module_name: str,
    path: Path,
):

    if not path.exists():

        raise FileNotFoundError(
            f"Required Python source file not found:\n{path}"
        )

    spec = importlib.util.spec_from_file_location(
        module_name,
        str(path)
    )

    if spec is None or spec.loader is None:

        raise ImportError(
            f"Could not create import specification for:\n{path}"
        )

    module = importlib.util.module_from_spec(
        spec
    )

    sys.modules[module_name] = module

    spec.loader.exec_module(module)

    return module


def find_model_b_source(
    root: Path,
) -> Path:

    candidates = [

        root / "191_step7_model_b_training.py",

        root / "191_step7_model_b_training(1).py",

    ]

    for path in candidates:

        if path.exists():

            return path

    matches = sorted(
        root.glob(
            "191_step7_model_b_training*.py"
        )
    )

    if matches:

        return matches[0]

    raise FileNotFoundError(
        "Could not locate File 191 Model-B source."
    )


def set_seed(
    seed: int,
) -> None:

    random.seed(seed)

    np.random.seed(seed)

    torch.manual_seed(seed)

    if torch.cuda.is_available():

        torch.cuda.manual_seed_all(seed)

        torch.backends.cudnn.deterministic = True

        torch.backends.cudnn.benchmark = False


def load_npy(
    folder: Path,
    filename: str,
):

    path = folder / filename

    if not path.exists():

        raise FileNotFoundError(
            f"Required dataset file not found:\n{path}"
        )

    return np.load(
        path,
        mmap_mode="r"
    )


def normalize_time(
    time_array,
):

    time_array = np.asarray(
        time_array,
        dtype=np.float64
    )

    return (
        (
            time_array
            - time_array[0]
        )
        /
        (
            time_array[-1]
            - time_array[0]
        )
    ).astype(
        np.float32
    )


def make_query(
    time_norm,
    indices,
    batch_size,
    device,
):

    values = np.asarray(
        time_norm[indices],
        dtype=np.float32
    )

    query = torch.as_tensor(
        values,
        dtype=torch.float32,
        device=device,
    ).view(
        1,
        -1,
        1
    )

    query = (
        query
        .expand(
            batch_size,
            -1,
            -1
        )
        .clone()
        .detach()
        .requires_grad_(True)
    )

    return query


# =====================================================================
# FROZEN REACTOR KINETICS
# =====================================================================

def load_kinetics_source(
    root: Path,
):

    path = (
        root
        / "70_reference_reactor_kinetics.py"
    )

    return load_module_from_file(
        "reference_reactor_kinetics_196",
        path
    )


def polynomial_torch(
    temperature,
    coefficients,
):

    return (
        coefficients[0]
        + coefficients[1]
        * temperature
        + coefficients[2]
        * temperature**2
        + coefficients[3]
        * temperature**3
    )


def physics_rhs(
    physical_state,
    external_reactivity,
    beta,
    lambdas,
    generation_time,
    fuel_coeff,
    block_coeff,
    fuel_reference,
    block_reference,
):

    power = physical_state[..., 0]

    precursors = physical_state[..., 1:7]

    fuel_temperature = physical_state[..., 7]

    block_temperature = physical_state[..., 8]

    fuel_current = polynomial_torch(
        fuel_temperature,
        fuel_coeff
    )

    fuel_ref = polynomial_torch(
        torch.as_tensor(
            fuel_reference,
            dtype=physical_state.dtype,
            device=physical_state.device,
        ),
        fuel_coeff
    )

    block_current = polynomial_torch(
        block_temperature,
        block_coeff
    )

    block_ref = polynomial_torch(
        torch.as_tensor(
            block_reference,
            dtype=physical_state.dtype,
            device=physical_state.device,
        ),
        block_coeff
    )

    rho_fuel = (
        fuel_current
        - fuel_ref
    )

    rho_block = (
        block_current
        - block_ref
    )

    rho_total = (
        external_reactivity
        + rho_fuel
        + rho_block
    )

    beta_total = torch.sum(
        beta
    )

    d_power_dt = (
        (
            rho_total
            - beta_total
        )
        / generation_time
        * power
        +
        torch.sum(
            lambdas
            * precursors,
            dim=-1
        )
    )

    d_precursors_dt = (
        beta.view(
            *([1] * (physical_state.ndim - 1)),
            6
        )
        / generation_time
        * power.unsqueeze(-1)
        -
        lambdas.view(
            *([1] * (physical_state.ndim - 1)),
            6
        )
        * precursors
    )

    rhs = torch.cat(
        [
            d_power_dt.unsqueeze(-1),
            d_precursors_dt,
        ],
        dim=-1
    )

    return rhs


# =====================================================================
# PHYSICS SCALE CALCULATION
# =====================================================================

def numpy_feedback(
    temperature,
    coefficients,
    reference_temperature,
):

    current = (
        coefficients[0]
        + coefficients[1] * temperature
        + coefficients[2] * temperature**2
        + coefficients[3] * temperature**3
    )

    reference = (
        coefficients[0]
        + coefficients[1] * reference_temperature
        + coefficients[2] * reference_temperature**2
        + coefficients[3] * reference_temperature**3
    )

    return current - reference


def calculate_rhs_scales(
    global_state,
    global_rho,
    event_state,
    event_rho,
    event_positions,
    kinetics,
):

    train_start, train_stop = (
        PARTITIONS["TRAIN"]
    )

    global_states = np.asarray(
        global_state[
            train_start:train_stop
        ],
        dtype=np.float64
    )

    global_reactivities = np.asarray(
        global_rho[
            train_start:train_stop
        ],
        dtype=np.float64
    )

    beta = np.asarray(
        kinetics.BETA,
        dtype=np.float64
    )

    lambdas = np.asarray(
        kinetics.LAMBDA,
        dtype=np.float64
    )

    beta_total = np.sum(
        beta
    )

    generation_time = float(
        kinetics.GENERATION_TIME
    )

    fuel_coeff = np.asarray(
        kinetics.FUEL_COEFF,
        dtype=np.float64
    )

    block_coeff = np.asarray(
        kinetics.BLOCK_COEFF,
        dtype=np.float64
    )

    fuel_reference = float(
        kinetics.FUEL_REFERENCE_TEMPERATURE
        if hasattr(
            kinetics,
            "FUEL_REFERENCE_TEMPERATURE"
        )
        else 1056.0
    )

    block_reference = float(
        kinetics.BLOCK_REFERENCE_TEMPERATURE
        if hasattr(
            kinetics,
            "BLOCK_REFERENCE_TEMPERATURE"
        )
        else 964.7249
    )

    power = (
        global_states[..., 0]
    )

    precursors = (
        global_states[..., 1:7]
    )

    fuel_temperature = (
        global_states[..., 7]
    )

    block_temperature = (
        global_states[..., 8]
    )

    rho_fuel = numpy_feedback(
        fuel_temperature,
        fuel_coeff,
        fuel_reference
    )

    rho_block = numpy_feedback(
        block_temperature,
        block_coeff,
        block_reference
    )

    rho_total = (
        global_reactivities
        + rho_fuel
        + rho_block
    )

    d_power = (
        (
            rho_total
            - beta_total
        )
        / generation_time
        * power
        +
        np.sum(
            lambdas
            * precursors,
            axis=-1
        )
    )

    d_precursors = (
        (
            beta[None, None, :]
            / generation_time
            * power[..., None]
        )
        -
        lambdas[None, None, :]
        * precursors
    )

    rhs_global = np.concatenate(
        [
            d_power[..., None],
            d_precursors,
        ],
        axis=-1
    )

    event_positions = np.asarray(
        event_positions,
        dtype=np.int64
    )

    event_states = np.asarray(
        event_state[
            event_positions
        ],
        dtype=np.float64
    )

    event_reactivities = np.asarray(
        event_rho[
            event_positions
        ],
        dtype=np.float64
    )

    event_power = (
        event_states[..., 0]
    )

    event_precursors = (
        event_states[..., 1:7]
    )

    event_fuel_temperature = (
        event_states[..., 7]
    )

    event_block_temperature = (
        event_states[..., 8]
    )

    event_rho_fuel = numpy_feedback(
        event_fuel_temperature,
        fuel_coeff,
        fuel_reference
    )

    event_rho_block = numpy_feedback(
        event_block_temperature,
        block_coeff,
        block_reference
    )

    event_rho_total = (
        event_reactivities
        + event_rho_fuel
        + event_rho_block
    )

    event_d_power = (
        (
            event_rho_total
            - beta_total
        )
        / generation_time
        * event_power
        +
        np.sum(
            lambdas
            * event_precursors,
            axis=-1
        )
    )

    event_d_precursors = (
        beta[None, None, :]
        / generation_time
        * event_power[..., None]
        -
        lambdas[None, None, :]
        * event_precursors
    )

    rhs_event = np.concatenate(
        [
            event_d_power[..., None],
            event_d_precursors,
        ],
        axis=-1
    )

    rhs_all = np.concatenate(
        [
            rhs_global.reshape(
                -1,
                7
            ),
            rhs_event.reshape(
                -1,
                7
            ),
        ],
        axis=0
    )

    scales = np.sqrt(
        np.mean(
            rhs_all**2,
            axis=0
        )
    )

    scales = np.maximum(
        scales,
        1.0e-12
    )

    return scales


# =====================================================================
# EVENT PARTITION MAPPING
# =====================================================================

def build_event_mapping(
    step_case_indices,
):

    mapping = {}

    for name, (
        start,
        stop
    ) in PARTITIONS.items():

        positions = np.flatnonzero(
            (
                step_case_indices >= start
            )
            &
            (
                step_case_indices < stop
            )
        )

        expected = (
            EVENT_PARTITION_COUNTS[name]
        )

        if len(positions) != expected:

            raise RuntimeError(
                f"Event mapping mismatch for "
                f"{name}: expected {expected}, "
                f"found {len(positions)}"
            )

        mapping[name] = positions

    return mapping


# =====================================================================
# DERIVATIVE CALCULATION
# =====================================================================

def state_time_derivatives(
    prediction,
    query,
    state_std,
    horizon_seconds,
):

    derivatives = []

    for state_index in range(7):

        scalar_output = (
            prediction[
                ...,
                state_index
            ].sum()
        )

        derivative = torch.autograd.grad(
            outputs=scalar_output,
            inputs=query,
            create_graph=True,
            retain_graph=True,
        )[0]

        derivative = (
            derivative.squeeze(-1)
            * state_std[state_index]
            / horizon_seconds
        )

        derivatives.append(
            derivative
        )

    return torch.stack(
        derivatives,
        dim=-1
    )


# =====================================================================
# PHYSICS LOSS
# =====================================================================

def calculate_physics_loss(
    prediction,
    query,
    branch_normalized,
    rho_mean,
    rho_std,
    state_mean,
    state_std,
    horizon_seconds,
    scales,
    beta,
    lambdas,
    generation_time,
    fuel_coeff,
    block_coeff,
    fuel_reference,
    block_reference,
):

    physical_state = (
        prediction
        * state_std
        +
        state_mean
    )

    external_reactivity = (
        branch_normalized
        * rho_std
        +
        rho_mean
    )

    predicted_derivatives = (
        state_time_derivatives(
            prediction,
            query,
            state_std,
            horizon_seconds
        )
    )

    rhs = physics_rhs(
        physical_state=physical_state,
        external_reactivity=external_reactivity,
        beta=beta,
        lambdas=lambdas,
        generation_time=generation_time,
        fuel_coeff=fuel_coeff,
        block_coeff=block_coeff,
        fuel_reference=fuel_reference,
        block_reference=block_reference,
    )

    residual = (
        predicted_derivatives
        - rhs
    )

    residual = (
        residual
        / scales
    )

    return torch.mean(
        residual**2
    )


# =====================================================================
# DATA LOSS
# =====================================================================

def calculate_data_loss(
    prediction,
    target,
):

    return torch.mean(
        (
            prediction
            - target
        )**2
    )


# =====================================================================
# VALIDATION
# =====================================================================

@torch.no_grad()
def evaluate_validation(
    model,
    global_rho,
    global_state,
    event_rho,
    event_state,
    event_positions,
    global_time_norm,
    event_time_norm,
    rho_mean,
    rho_std,
    state_mean,
    state_std,
    device,
):

    global_start, global_stop = (
        PARTITIONS["VALIDATION"]
    )

    global_losses = []

    global_query = torch.as_tensor(
        global_time_norm,
        dtype=torch.float32,
        device=device
    ).view(
        1,
        -1,
        1
    )

    for start in range(
        global_start,
        global_stop,
        BATCH_SIZE
    ):

        stop = min(
            start + BATCH_SIZE,
            global_stop
        )

        indices = np.arange(
            start,
            stop
        )

        branch = (
            (
                np.asarray(
                    global_rho[
                        indices
                    ],
                    dtype=np.float32
                )
                -
                rho_mean
            )
            /
            rho_std
        )

        target = (
            (
                np.asarray(
                    global_state[
                        indices
                    ],
                    dtype=np.float32
                )
                -
                state_mean
            )
            /
            state_std
        )

        branch_tensor = torch.as_tensor(
            branch,
            dtype=torch.float32,
            device=device
        )

        target_tensor = torch.as_tensor(
            target,
            dtype=torch.float32,
            device=device
        )

        query = (
            global_query
            .expand(
                len(indices),
                -1,
                -1
            )
        )

        prediction = (
            model.forward_global(
                branch_tensor,
                query
            )
        )

        loss = calculate_data_loss(
            prediction,
            target_tensor
        )

        global_losses.append(
            float(
                loss.item()
            )
        )

    event_losses = []

    event_positions = np.asarray(
        event_positions,
        dtype=np.int64
    )

    event_query = torch.as_tensor(
        event_time_norm,
        dtype=torch.float32,
        device=device
    ).view(
        1,
        -1,
        1
    )

    for start in range(
        0,
        len(event_positions),
        BATCH_SIZE
    ):

        positions = event_positions[
            start:
            start + BATCH_SIZE
        ]

        branch = (
            (
                np.asarray(
                    event_rho[
                        positions
                    ],
                    dtype=np.float32
                )
                -
                rho_mean
            )
            /
            rho_std
        )

        target = (
            (
                np.asarray(
                    event_state[
                        positions
                    ],
                    dtype=np.float32
                )
                -
                state_mean
            )
            /
            state_std
        )

        branch_tensor = torch.as_tensor(
            branch,
            dtype=torch.float32,
            device=device
        )

        target_tensor = torch.as_tensor(
            target,
            dtype=torch.float32,
            device=device
        )

        query = (
            event_query
            .expand(
                len(positions),
                -1,
                -1
            )
        )

        prediction = (
            model.forward_event(
                branch_tensor,
                query
            )
        )

        loss = calculate_data_loss(
            prediction,
            target_tensor
        )

        event_losses.append(
            float(
                loss.item()
            )
        )

    global_mse = float(
        np.mean(
            global_losses
        )
    )

    event_mse = float(
        np.mean(
            event_losses
        )
    )

    combined = (
        0.5 * global_mse
        +
        0.5 * event_mse
    )

    return {
        "global_mse": global_mse,
        "event_mse": event_mse,
        "combined_mse": combined,
        "normalized_rmse": math.sqrt(
            combined
        ),
    }


# =====================================================================
# MAIN
# =====================================================================

def main():

    set_seed(
        SEED
    )

    root = find_project_root()

    production = (
        root
        / "step6_dataset"
        / "production_v1"
    )

    base_checkpoint = (
        root
        / "step7_pino"
        / "model_b_training"
        / "model_b_best.pt"
    )

    output_dir = (
        root
        / "step7_pino"
        / "physics_informed"
        / "model_b_kinetics"
    )

    output_dir.mkdir(
        parents=True,
        exist_ok=True
    )

    print("=" * 78)
    print(
        "STEP 7 MODEL-B + KINETICS PHYSICS "
        "TRAINING"
    )
    print("=" * 78)

    print()
    print(
        "Ablation:"
    )
    print(
        "  Model-B data loss"
    )
    print(
        "  + reactor point-kinetics residual"
    )
    print(
        "  + six precursor residuals"
    )
    print(
        "  + frozen temperature-feedback reactivity"
    )

    print()
    print(
        "Thermal physics:"
    )
    print(
        "  NOT INCLUDED IN THIS ABLATION"
    )

    print()
    print(
        f"Project root : {root}"
    )

    print(
        f"Dataset      : {production}"
    )

    print(
        f"Base model   : {base_checkpoint}"
    )

    # ---------------------------------------------------------------
    # DEVICE
    # ---------------------------------------------------------------

    device = torch.device(
        "cuda"
        if torch.cuda.is_available()
        else "cpu"
    )

    print()
    print(
        f"Device       : {device}"
    )

    if device.type == "cuda":

        print(
            "GPU          : "
            +
            torch.cuda.get_device_name(0)
        )

        free_memory, total_memory = (
            torch.cuda.mem_get_info()
        )

        print(
            f"GPU memory   : "
            f"{free_memory / 1024**3:.2f} GiB free / "
            f"{total_memory / 1024**3:.2f} GiB total"
        )

    # ---------------------------------------------------------------
    # SOURCE MODULES
    # ---------------------------------------------------------------

    print()
    print(
        "LOADING FROZEN MODEL AND PHYSICS SOURCES"
    )

    model_source = (
        find_model_b_source(
            root
        )
    )

    model_module = (
        load_module_from_file(
            "model_b_source_196",
            model_source
        )
    )

    kinetics_module = (
        load_kinetics_source(
            root
        )
    )

    print(
        f"Model-B source : {model_source}"
    )

    print(
        "Kinetics source: "
        +
        str(
            root
            / "70_reference_reactor_kinetics.py"
        )
    )

    # ---------------------------------------------------------------
    # DATA
    # ---------------------------------------------------------------

    print()
    print(
        "LOADING PRODUCTION-V1 DATASET"
    )

    global_time = load_npy(
        production,
        "global_time_s.npy"
    )

    global_rho = load_npy(
        production,
        "global_reactivity_delta_k_over_k.npy"
    )

    global_state = load_npy(
        production,
        "global_state.npy"
    )

    event_time = load_npy(
        production,
        "step_event_relative_time_s.npy"
    )

    event_rho = load_npy(
        production,
        "step_event_reactivity_delta_k_over_k.npy"
    )

    event_state = load_npy(
        production,
        "step_event_state.npy"
    )

    step_case_indices = np.asarray(
        load_npy(
            production,
            "step_case_indices.npy"
        ),
        dtype=np.int64
    )

    print(
        f"Global rho   : {global_rho.shape}"
    )

    print(
        f"Global state : {global_state.shape}"
    )

    print(
        f"Event rho    : {event_rho.shape}"
    )

    print(
        f"Event state  : {event_state.shape}"
    )

    # ---------------------------------------------------------------
    # EVENT MAPPING
    # ---------------------------------------------------------------

    event_mapping = (
        build_event_mapping(
            step_case_indices
        )
    )

    print(
        "Event partition mapping : PASS"
    )

    # ---------------------------------------------------------------
    # NORMALIZATION
    # ---------------------------------------------------------------

    checkpoint = torch.load(
        base_checkpoint,
        map_location="cpu",
        weights_only=False,
    )

    normalization = (
        checkpoint[
            "normalization"
        ]
    )

    rho_mean = float(
        normalization[
            "rho_mean"
        ]
    )

    rho_std = float(
        normalization[
            "rho_std"
        ]
    )

    state_mean = np.asarray(
        normalization[
            "state_mean"
        ],
        dtype=np.float64
    )

    state_std = np.asarray(
        normalization[
            "state_std"
        ],
        dtype=np.float64
    )

    print()
    print(
        "REUSING MODEL-B TRAIN NORMALIZATION"
    )

    print(
        f"rho mean : {rho_mean:.16e}"
    )

    print(
        f"rho std  : {rho_std:.16e}"
    )

    # ---------------------------------------------------------------
    # MODEL
    # ---------------------------------------------------------------

    model = model_module.ModelB()

    model.load_state_dict(
        checkpoint[
            "model_state_dict"
        ]
    )

    model = model.to(
        device
    )

    print()
    print(
        "Model-B checkpoint : LOADED"
    )

    print(
        f"Checkpoint epoch   : "
        f"{checkpoint.get('epoch', 'unknown')}"
    )

    # ---------------------------------------------------------------
    # TIME
    # ---------------------------------------------------------------

    global_time_norm = (
        normalize_time(
            global_time
        )
    )

    event_time_norm = (
        normalize_time(
            event_time
        )
    )

    global_horizon = float(
        np.asarray(
            global_time,
            dtype=np.float64
        )[-1]
        -
        np.asarray(
            global_time,
            dtype=np.float64
        )[0]
    )

    event_horizon = float(
        np.asarray(
            event_time,
            dtype=np.float64
        )[-1]
        -
        np.asarray(
            event_time,
            dtype=np.float64
        )[0]
    )

    print()
    print(
        f"Global horizon : {global_horizon:.6f} s"
    )

    print(
        f"Event horizon  : {event_horizon:.6f} s"
    )

    # ---------------------------------------------------------------
    # PHYSICS CONSTANTS
    # ---------------------------------------------------------------

    beta = torch.as_tensor(
        np.asarray(
            kinetics_module.BETA,
            dtype=np.float32
        ),
        dtype=torch.float32,
        device=device
    )

    lambdas = torch.as_tensor(
        np.asarray(
            kinetics_module.LAMBDA,
            dtype=np.float32
        ),
        dtype=torch.float32,
        device=device
    )

    generation_time = float(
        kinetics_module.GENERATION_TIME
    )

    fuel_coeff = torch.as_tensor(
        np.asarray(
            kinetics_module.FUEL_COEFF,
            dtype=np.float32
        ),
        dtype=torch.float32,
        device=device
    )

    block_coeff = torch.as_tensor(
        np.asarray(
            kinetics_module.BLOCK_COEFF,
            dtype=np.float32
        ),
        dtype=torch.float32,
        device=device
    )

    fuel_reference = float(
        getattr(
            kinetics_module,
            "FUEL_REFERENCE_TEMPERATURE",
            1056.0
        )
    )

    block_reference = float(
        getattr(
            kinetics_module,
            "BLOCK_REFERENCE_TEMPERATURE",
            964.7249
        )
    )

    # ---------------------------------------------------------------
    # PHYSICS SCALING
    # ---------------------------------------------------------------

    print()
    print(
        "CALCULATING TRAIN-ONLY PHYSICS SCALES"
    )

    physics_scales = (
        calculate_rhs_scales(
            global_state=global_state,
            global_rho=global_rho,
            event_state=event_state,
            event_rho=event_rho,
            event_positions=(
                event_mapping["TRAIN"]
            ),
            kinetics=kinetics_module,
        )
    )

    print(
        "Physics RHS scales:"
    )

    for i, value in enumerate(
        physics_scales
    ):

        print(
            f"  state {i}: "
            f"{value:.8e}"
        )

    physics_scales_t = torch.as_tensor(
        physics_scales,
        dtype=torch.float32,
        device=device
    )

    state_mean_t = torch.as_tensor(
        state_mean,
        dtype=torch.float32,
        device=device
    ).view(
        1,
        1,
        -1
    )

    state_std_t = torch.as_tensor(
        state_std,
        dtype=torch.float32,
        device=device
    ).view(
        1,
        1,
        -1
    )

    # ---------------------------------------------------------------
    # BASELINE VALIDATION
    # ---------------------------------------------------------------

    print()
    print(
        "BASE MODEL VALIDATION BEFORE "
        "PHYSICS FINE-TUNING"
    )

    baseline_validation = (
        evaluate_validation(
            model=model,
            global_rho=global_rho,
            global_state=global_state,
            event_rho=event_rho,
            event_state=event_state,
            event_positions=(
                event_mapping["VALIDATION"]
            ),
            global_time_norm=global_time_norm,
            event_time_norm=event_time_norm,
            rho_mean=rho_mean,
            rho_std=rho_std,
            state_mean=state_mean,
            state_std=state_std,
            device=device,
        )
    )

    print(
        f"Global MSE : "
        f"{baseline_validation['global_mse']:.8e}"
    )

    print(
        f"Event MSE  : "
        f"{baseline_validation['event_mse']:.8e}"
    )

    print(
        f"Combined   : "
        f"{baseline_validation['combined_mse']:.8e}"
    )

    print(
        f"Norm RMSE  : "
        f"{baseline_validation['normalized_rmse']:.8e}"
    )

    # ---------------------------------------------------------------
    # OPTIMIZER
    # ---------------------------------------------------------------

    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=LEARNING_RATE,
        weight_decay=WEIGHT_DECAY
    )

    # ---------------------------------------------------------------
    # TRAINING
    # ---------------------------------------------------------------

    train_global_indices = np.arange(
        PARTITIONS["TRAIN"][0],
        PARTITIONS["TRAIN"][1]
    )

    train_event_positions = np.asarray(
        event_mapping["TRAIN"],
        dtype=np.int64
    )

    rng = np.random.default_rng(
        SEED
    )

    best_validation = (
        baseline_validation[
            "combined_mse"
        ]
    )

    best_epoch = 0

    patience_counter = 0

    best_path = (
        output_dir
        / "model_b_kinetics_best.pt"
    )

    history = []

    print()
    print("=" * 78)
    print(
        "PHYSICS-INFORMED FINE-TUNING"
    )
    print("=" * 78)

    print(
        f"Physics weight : {PHYSICS_WEIGHT}"
    )

    print(
        f"Learning rate  : {LEARNING_RATE}"
    )

    print(
        f"Epochs         : {MAX_EPOCHS}"
    )

    print()

    for epoch in range(
        1,
        MAX_EPOCHS + 1
    ):

        epoch_start = time.time()

        model.train()

        global_data_values = []
        global_physics_values = []

        event_data_values = []
        event_physics_values = []

        number_batches = max(
            1,
            min(
                len(train_global_indices),
                len(train_event_positions)
            )
            // BATCH_SIZE
        )

        for _ in range(
            number_batches
        ):

            # =======================================================
            # GLOBAL BRANCH
            # =======================================================

            global_cases = rng.choice(
                train_global_indices,
                size=BATCH_SIZE,
                replace=False
            )

            global_query_indices = (
                rng.choice(
                    GLOBAL_POINTS,
                    size=GLOBAL_QUERY_POINTS,
                    replace=False
                )
            )

            global_query_indices.sort()

            branch_global = (
                (
                    np.asarray(
                        global_rho[
                            global_cases
                        ],
                        dtype=np.float32
                    )
                    -
                    rho_mean
                )
                /
                rho_std
            )

            target_global = (
                (
                    np.asarray(
                        global_state[
                            global_cases
                        ][:, global_query_indices],
                        dtype=np.float32
                    )
                    -
                    state_mean
                )
                /
                state_std
            )

            branch_global = torch.as_tensor(
                branch_global,
                dtype=torch.float32,
                device=device
            )

            target_global = torch.as_tensor(
                target_global,
                dtype=torch.float32,
                device=device
            )

            query_global = make_query(
                global_time_norm,
                global_query_indices,
                BATCH_SIZE,
                device
            )

            prediction_global = (
                model.forward_global(
                    branch_global,
                    query_global
                )
            )

            data_loss_global = (
                calculate_data_loss(
                    prediction_global,
                    target_global
                )
            )

            physics_loss_global = (
                calculate_physics_loss(
                    prediction=prediction_global,
                    query=query_global,
                    branch_normalized=(
                        branch_global
                        .unsqueeze(1)
                        .expand(
                            -1,
                            len(global_query_indices),
                            -1
                        )
                    ),
                    rho_mean=rho_mean,
                    rho_std=rho_std,
                    state_mean=state_mean_t,
                    state_std=state_std_t,
                    horizon_seconds=global_horizon,
                    scales=physics_scales_t,
                    beta=beta,
                    lambdas=lambdas,
                    generation_time=generation_time,
                    fuel_coeff=fuel_coeff,
                    block_coeff=block_coeff,
                    fuel_reference=fuel_reference,
                    block_reference=block_reference,
                )
            )

            loss_global = (
                data_loss_global
                +
                PHYSICS_WEIGHT
                * physics_loss_global
            )

            optimizer.zero_grad(
                set_to_none=True
            )

            loss_global.backward()

            torch.nn.utils.clip_grad_norm_(
                model.parameters(),
                GRADIENT_CLIP
            )

            # =======================================================
            # EVENT BRANCH
            # =======================================================

            event_positions_batch = rng.choice(
                train_event_positions,
                size=BATCH_SIZE,
                replace=False
            )

            raw_event_time = np.asarray(
                event_time,
                dtype=np.float64
            )

            fast = np.flatnonzero(
                raw_event_time
                <=
                0.010
            )

            slow = np.flatnonzero(
                raw_event_time
                >
                0.010
            )

            fast_count = min(
                EVENT_FAST_QUERY_POINTS,
                len(fast)
            )

            slow_count = min(
                EVENT_SLOW_QUERY_POINTS,
                len(slow)
            )

            fast_indices = (
                rng.choice(
                    fast,
                    size=fast_count,
                    replace=False
                )
                if fast_count > 0
                else np.array(
                    [],
                    dtype=np.int64
                )
            )

            slow_indices = (
                rng.choice(
                    slow,
                    size=slow_count,
                    replace=False
                )
                if slow_count > 0
                else np.array(
                    [],
                    dtype=np.int64
                )
            )

            event_query_indices = np.sort(
                np.concatenate(
                    [
                        fast_indices,
                        slow_indices,
                    ]
                )
            )

            branch_event = (
                (
                    np.asarray(
                        event_rho[
                            event_positions_batch
                        ],
                        dtype=np.float32
                    )
                    -
                    rho_mean
                )
                /
                rho_std
            )

            target_event = (
                (
                    np.asarray(
                        event_state[
                            event_positions_batch
                        ][:, event_query_indices],
                        dtype=np.float32
                    )
                    -
                    state_mean
                )
                /
                state_std
            )

            branch_event = torch.as_tensor(
                branch_event,
                dtype=torch.float32,
                device=device
            )

            target_event = torch.as_tensor(
                target_event,
                dtype=torch.float32,
                device=device
            )

            query_event = make_query(
                event_time_norm,
                event_query_indices,
                BATCH_SIZE,
                device
            )

            prediction_event = (
                model.forward_event(
                    branch_event,
                    query_event
                )
            )

            data_loss_event = (
                calculate_data_loss(
                    prediction_event,
                    target_event
                )
            )

            physics_loss_event = (
                calculate_physics_loss(
                    prediction=prediction_event,
                    query=query_event,
                    branch_normalized=(
                        branch_event
                        .unsqueeze(1)
                        .expand(
                            -1,
                            len(event_query_indices),
                            -1
                        )
                    ),
                    rho_mean=rho_mean,
                    rho_std=rho_std,
                    state_mean=state_mean_t,
                    state_std=state_std_t,
                    horizon_seconds=event_horizon,
                    scales=physics_scales_t,
                    beta=beta,
                    lambdas=lambdas,
                    generation_time=generation_time,
                    fuel_coeff=fuel_coeff,
                    block_coeff=block_coeff,
                    fuel_reference=fuel_reference,
                    block_reference=block_reference,
                )
            )

            loss_event = (
                data_loss_event
                +
                PHYSICS_WEIGHT
                * physics_loss_event
            )

            loss_event.backward()

            torch.nn.utils.clip_grad_norm_(
                model.parameters(),
                GRADIENT_CLIP
            )

            optimizer.step()

            global_data_values.append(
                float(
                    data_loss_global.item()
                )
            )

            global_physics_values.append(
                float(
                    physics_loss_global.item()
                )
            )

            event_data_values.append(
                float(
                    data_loss_event.item()
                )
            )

            event_physics_values.append(
                float(
                    physics_loss_event.item()
                )
            )

        validation = (
            evaluate_validation(
                model=model,
                global_rho=global_rho,
                global_state=global_state,
                event_rho=event_rho,
                event_state=event_state,
                event_positions=(
                    event_mapping["VALIDATION"]
                ),
                global_time_norm=global_time_norm,
                event_time_norm=event_time_norm,
                rho_mean=rho_mean,
                rho_std=rho_std,
                state_mean=state_mean,
                state_std=state_std,
                device=device,
            )
        )

        train_data = (
            0.5
            *
            (
                np.mean(
                    global_data_values
                )
                +
                np.mean(
                    event_data_values
                )
            )
        )

        train_physics = (
            0.5
            *
            (
                np.mean(
                    global_physics_values
                )
                +
                np.mean(
                    event_physics_values
                )
            )
        )

        train_total = (
            train_data
            +
            PHYSICS_WEIGHT
            * train_physics
        )

        improved = (
            validation["combined_mse"]
            <
            best_validation
            -
            MIN_VALIDATION_IMPROVEMENT
        )

        if improved:

            best_validation = (
                validation["combined_mse"]
            )

            best_epoch = epoch

            patience_counter = 0

            checkpoint_out = {

                "model_state_dict":
                    model.state_dict(),

                "optimizer_state_dict":
                    optimizer.state_dict(),

                "epoch":
                    epoch,

                "best_validation_mse":
                    best_validation,

                "base_model":
                    "Model-B Dual-Resolution "
                    "Coordinate DeepONet",

                "ablation":
                    (
                        "Model-B + reactor kinetics "
                        "and temperature-feedback physics"
                    ),

                "physics_weight":
                    PHYSICS_WEIGHT,

                "physics_residual_states":
                    [
                        "normalized_reactor_power",
                        "precursor_1",
                        "precursor_2",
                        "precursor_3",
                        "precursor_4",
                        "precursor_5",
                        "precursor_6",
                    ],

                "normalization":
                    normalization,

                "physics_scales":
                    physics_scales.tolist(),

                "architecture":
                    checkpoint.get(
                        "architecture",
                        {}
                    ),

                "seed":
                    SEED,
            }

            torch.save(
                checkpoint_out,
                best_path
            )

        else:

            patience_counter += 1

        epoch_seconds = (
            time.time()
            -
            epoch_start
        )

        history.append(
            {
                "epoch": epoch,
                "train_data_loss": train_data,
                "train_physics_loss": train_physics,
                "train_total_loss": train_total,
                "validation_mse":
                    validation[
                        "combined_mse"
                    ],
                "validation_rmse":
                    validation[
                        "normalized_rmse"
                    ],
                "epoch_seconds":
                    epoch_seconds,
            }
        )

        print(
            f"Epoch {epoch:03d} | "
            f"Data={train_data:.6e} | "
            f"Physics={train_physics:.6e} | "
            f"Total={train_total:.6e} | "
            f"Val={validation['combined_mse']:.6e} | "
            f"ValRMSE={validation['normalized_rmse']:.6e} | "
            f"Patience={patience_counter:02d} | "
            f"Time={epoch_seconds:.1f}s"
        )

        if (
            patience_counter
            >=
            EARLY_STOPPING_PATIENCE
        ):

            print()
            print(
                "EARLY STOPPING"
            )

            break

    # ---------------------------------------------------------------
    # SAVE HISTORY
    # ---------------------------------------------------------------

    history_path = (
        output_dir
        / "196_model_b_kinetics_training_history.json"
    )

    history_path.write_text(
        json.dumps(
            history,
            indent=2
        ),
        encoding="utf-8"
    )

    # ---------------------------------------------------------------
    # FINAL SUMMARY
    # ---------------------------------------------------------------

    print()
    print("=" * 78)
    print(
        "STEP 7 MODEL-B + KINETICS PHYSICS "
        "TRAINING COMPLETE"
    )
    print("=" * 78)

    print()
    print(
        f"Initial validation RMSE : "
        f"{baseline_validation['normalized_rmse']:.8e}"
    )

    print(
        f"Best validation RMSE    : "
        f"{math.sqrt(best_validation):.8e}"
    )

    print(
        f"Best epoch              : "
        f"{best_epoch}"
    )

    print()
    print(
        "Generated:"
    )

    print(
        best_path
    )

    print(
        history_path
    )

    print()
    print(
        "ID/OOD/STRESS:"
    )

    print(
        "NOT EVALUATED IN THIS TRAINING GATE"
    )

    print()
    print(
        "Thermal physics:"
    )

    print(
        "NOT YET INCLUDED"
    )

    print()
    print(
        "STATUS: MODEL-B + KINETICS PHYSICS "
        "ABLATION READY FOR EVALUATION"
    )


if __name__ == "__main__":

    main()