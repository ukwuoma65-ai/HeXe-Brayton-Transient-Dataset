#!/usr/bin/env python3
"""
213_step7_representative_transient_publication_figures.py

STEP 7 - REPRESENTATIVE TRANSIENT PUBLICATION FIGURES

Purpose
-------
Create manuscript-ready composite trajectory figures from the already frozen
File-212 representative-case archive. This file performs no model inference,
training, tuning, checkpoint selection, or representative-case selection.

Scientific rules
----------------
- NO training.
- NO tuning.
- NO checkpoint/model selection.
- NO representative-case reselection.
- Uses exactly the File-212 input-space medoids.
- Prediction errors are NOT used to choose which cases appear.
- Production-V1 is NOT modified.
- ID/OOD/STRESS are used only as already frozen post-selection evidence.

Primary outputs
---------------
- 213_representative_case_table.csv
- 213_step_global_power_comparison.png / .pdf
- 213_step_event_power_comparison.png / .pdf
- 213_ramp_global_power_comparison.png / .pdf
- 213_global_thermal_comparison.png / .pdf
- 213_representative_trajectory_atlas.pdf
- 213_figure_manifest.json
- 213_representative_transient_publication_report.json / .txt
"""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np

try:
    import matplotlib.pyplot as plt
    from matplotlib.backends.backend_pdf import PdfPages
except Exception as exc:
    raise RuntimeError(
        "matplotlib is required for File 213 publication figures."
    ) from exc


# =====================================================================
# FROZEN VISUALIZATION CONTRACT
# =====================================================================

EXPECTED_PARTITIONS = [
    "ID_TEST",
    "OOD_NEG_TEST",
    "OOD_POS_TEST",
    "STRESS_TEST",
]

POWER_INDEX = 0
FUEL_INDEX = 7
BLOCK_INDEX = 8
COOLANT_INDEX = 9

EPS = 1.0e-30


# =====================================================================
# GENERAL UTILITIES
# =====================================================================


def find_root() -> Path:
    current = Path.cwd().resolve()
    for path in [current, *current.parents]:
        if (path / "step6_dataset" / "production_v1").is_dir():
            return path
    raise FileNotFoundError("Could not locate He-Xe PINO project root.")


def require_file(path: Path) -> Path:
    if not path.exists():
        raise FileNotFoundError(f"Required file not found:\n{path}")
    return path


def serializable(value):
    if isinstance(value, dict):
        return {k: serializable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [serializable(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.floating):
        return float(value)
    if isinstance(value, np.integer):
        return int(value)
    return value


def percent_improvement(reference, candidate):
    reference = float(reference)
    candidate = float(candidate)
    if abs(reference) <= EPS:
        return float("nan")
    return 100.0 * (reference - candidate) / reference


def configure_matplotlib():
    plt.rcParams.update({
        "font.family": "serif",
        "font.serif": ["Times New Roman", "DejaVu Serif"],
        "font.size": 8.5,
        "axes.titlesize": 9.0,
        "axes.labelsize": 8.5,
        "legend.fontsize": 7.5,
        "xtick.labelsize": 7.5,
        "ytick.labelsize": 7.5,
        "figure.dpi": 120,
        "savefig.dpi": 400,
    })


def save_figure(fig, png_path: Path, pdf_path: Path):
    fig.savefig(png_path, dpi=400, bbox_inches="tight")
    fig.savefig(pdf_path, bbox_inches="tight")
    plt.close(fig)


def short_partition(name):
    return {
        "ID_TEST": "ID",
        "OOD_NEG_TEST": "OOD−",
        "OOD_POS_TEST": "OOD+",
        "STRESS_TEST": "Stress",
    }.get(name, name)


def sign_symbol(sign):
    return "+" if sign == "POSITIVE" else "−"


def make_case_title(record):
    amplitude = float(record.get("amplitude_cents", float("nan")))
    amp_text = f"{amplitude:+.2f}¢" if math.isfinite(amplitude) else ""
    return (
        f"{short_partition(record['partition'])} "
        f"{record['waveform'].replace('_HOLD', '')} "
        f"{sign_symbol(record['sign'])}  {amp_text}"
    ).strip()


def write_csv(path: Path, rows):
    if not rows:
        return
    fields = list(rows[0].keys())
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


# =====================================================================
# ARCHIVE ACCESS
# =====================================================================


def archive_key(record_index, case_index, suffix):
    return f"rep_{record_index:02d}_case_{int(case_index)}_{suffix}"


def load_case_data(archive, record_index, record):
    case = int(record["global_case_index"])
    prefix = f"rep_{record_index:02d}_case_{case}"

    required_global = [
        f"{prefix}_global_time",
        f"{prefix}_global_rho",
        f"{prefix}_global_reference",
        f"{prefix}_global_control",
        f"{prefix}_global_pino",
    ]

    for key in required_global:
        if key not in archive.files:
            raise RuntimeError(f"Missing File-212 archive field: {key}")

    result = {
        "global_time": np.asarray(archive[f"{prefix}_global_time"], dtype=np.float64),
        "global_rho": np.asarray(archive[f"{prefix}_global_rho"], dtype=np.float64),
        "global_reference": np.asarray(archive[f"{prefix}_global_reference"], dtype=np.float64),
        "global_control": np.asarray(archive[f"{prefix}_global_control"], dtype=np.float64),
        "global_pino": np.asarray(archive[f"{prefix}_global_pino"], dtype=np.float64),
    }

    event_keys = [
        f"{prefix}_event_time",
        f"{prefix}_event_rho",
        f"{prefix}_event_reference",
        f"{prefix}_event_control",
        f"{prefix}_event_pino",
    ]

    if all(key in archive.files for key in event_keys):
        result.update({
            "event_time": np.asarray(archive[f"{prefix}_event_time"], dtype=np.float64),
            "event_rho": np.asarray(archive[f"{prefix}_event_rho"], dtype=np.float64),
            "event_reference": np.asarray(archive[f"{prefix}_event_reference"], dtype=np.float64),
            "event_control": np.asarray(archive[f"{prefix}_event_control"], dtype=np.float64),
            "event_pino": np.asarray(archive[f"{prefix}_event_pino"], dtype=np.float64),
        })

    return result


def ordered_records(records, waveform):
    partition_order = {name: i for i, name in enumerate(EXPECTED_PARTITIONS)}
    sign_order = {"NEGATIVE": 0, "POSITIVE": 1}

    subset = [row for row in records if row["waveform"] == waveform]
    return sorted(
        subset,
        key=lambda row: (
            partition_order.get(row["partition"], 999),
            sign_order.get(row["sign"], 999),
        ),
    )


# =====================================================================
# COMPOSITE FIGURES
# =====================================================================


def add_three_model_lines(ax, time, reference, control, pino, ylabel=None):
    ax.plot(time, reference, linewidth=1.5, linestyle="-", label="Reference")
    ax.plot(time, control, linewidth=1.1, linestyle="--", label="Matched control")
    ax.plot(time, pino, linewidth=1.1, linestyle=":", label="Full PINO")
    if ylabel is not None:
        ax.set_ylabel(ylabel)
    ax.grid(True, alpha=0.20, linewidth=0.5)


def make_power_composite(records, case_data, waveform, output_dir):
    subset = ordered_records(records, waveform)
    if not subset:
        return None

    n = len(subset)
    cols = 2
    rows = int(math.ceil(n / cols))

    fig, axes = plt.subplots(
        rows,
        cols,
        figsize=(7.4, 2.25 * rows),
        sharex=False,
    )
    axes = np.asarray(axes).reshape(-1)

    for ax, record in zip(axes, subset):
        idx = records.index(record)
        data = case_data[idx]
        t = data["global_time"]
        add_three_model_lines(
            ax,
            t,
            data["global_reference"][:, POWER_INDEX],
            data["global_control"][:, POWER_INDEX],
            data["global_pino"][:, POWER_INDEX],
            ylabel="Normalized power",
        )
        ax.set_title(make_case_title(record))
        ax.set_xlabel("Time (s)")

        onset = float(record.get("approx_onset_time_s", float("nan")))
        if math.isfinite(onset):
            ax.axvline(onset, linewidth=0.7, linestyle="-.", alpha=0.65)

    for ax in axes[n:]:
        ax.axis("off")

    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(
        handles,
        labels,
        loc="upper center",
        ncol=3,
        frameon=False,
        bbox_to_anchor=(0.5, 1.01),
    )

    fig.tight_layout(rect=(0, 0, 1, 0.97))

    stem = (
        "213_step_global_power_comparison"
        if waveform == "STEP_HOLD"
        else "213_ramp_global_power_comparison"
    )

    png = output_dir / f"{stem}.png"
    pdf = output_dir / f"{stem}.pdf"
    save_figure(fig, png, pdf)
    return {"png": str(png), "pdf": str(pdf), "cases": n}


def make_step_event_composite(records, case_data, output_dir):
    subset = ordered_records(records, "STEP_HOLD")
    subset = [row for row in subset if "event_time" in case_data[records.index(row)]]
    if not subset:
        return None

    n = len(subset)
    cols = 2
    rows = int(math.ceil(n / cols))

    fig, axes = plt.subplots(
        rows,
        cols,
        figsize=(7.4, 2.25 * rows),
        sharex=False,
    )
    axes = np.asarray(axes).reshape(-1)

    for ax, record in zip(axes, subset):
        idx = records.index(record)
        data = case_data[idx]
        t = data["event_time"]

        add_three_model_lines(
            ax,
            t,
            data["event_reference"][:, POWER_INDEX],
            data["event_control"][:, POWER_INDEX],
            data["event_pino"][:, POWER_INDEX],
            ylabel="Normalized power",
        )
        ax.set_xscale("symlog", linthresh=1.0e-5, linscale=1.0)
        ax.set_xlabel("Time after STEP onset (s)")
        ax.set_title(make_case_title(record))

    for ax in axes[n:]:
        ax.axis("off")

    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(
        handles,
        labels,
        loc="upper center",
        ncol=3,
        frameon=False,
        bbox_to_anchor=(0.5, 1.01),
    )

    fig.tight_layout(rect=(0, 0, 1, 0.97))

    png = output_dir / "213_step_event_power_comparison.png"
    pdf = output_dir / "213_step_event_power_comparison.pdf"
    save_figure(fig, png, pdf)
    return {"png": str(png), "pdf": str(pdf), "cases": n}


def make_thermal_composite(records, case_data, output_dir):
    """
    Main thermal figure: all 12 frozen representative cases.

    Each panel shows coolant temperature because it is the thermal state directly
    coupled to the Brayton/core closure. Fuel/block trajectories remain in the
    atlas so the main figure stays readable.
    """
    n = len(records)
    cols = 3
    rows = int(math.ceil(n / cols))

    fig, axes = plt.subplots(
        rows,
        cols,
        figsize=(10.0, 2.20 * rows),
        sharex=False,
    )
    axes = np.asarray(axes).reshape(-1)

    for ax, record, data in zip(axes, records, case_data):
        t = data["global_time"]
        add_three_model_lines(
            ax,
            t,
            data["global_reference"][:, COOLANT_INDEX],
            data["global_control"][:, COOLANT_INDEX],
            data["global_pino"][:, COOLANT_INDEX],
            ylabel=r"$T_c$ (K)",
        )
        ax.set_title(make_case_title(record))
        ax.set_xlabel("Time (s)")

        onset = float(record.get("approx_onset_time_s", float("nan")))
        if math.isfinite(onset):
            ax.axvline(onset, linewidth=0.7, linestyle="-.", alpha=0.65)

    for ax in axes[n:]:
        ax.axis("off")

    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(
        handles,
        labels,
        loc="upper center",
        ncol=3,
        frameon=False,
        bbox_to_anchor=(0.5, 1.005),
    )

    fig.tight_layout(rect=(0, 0, 1, 0.975))

    png = output_dir / "213_global_coolant_temperature_comparison.png"
    pdf = output_dir / "213_global_coolant_temperature_comparison.pdf"
    save_figure(fig, png, pdf)
    return {"png": str(png), "pdf": str(pdf), "cases": n}


# =====================================================================
# TRAJECTORY ATLAS
# =====================================================================


def make_atlas(records, case_data, output_dir):
    atlas_path = output_dir / "213_representative_trajectory_atlas.pdf"

    with PdfPages(atlas_path) as pdf:
        for record, data in zip(records, case_data):
            t = data["global_time"]
            ref = data["global_reference"]
            control = data["global_control"]
            pino = data["global_pino"]
            rho = data["global_rho"]

            fig, axes = plt.subplots(
                3,
                2,
                figsize=(8.3, 9.4),
            )

            ax = axes[0, 0]
            ax.plot(t, rho * 1.0e5, linewidth=1.2)
            ax.set_ylabel("External reactivity (pcm)")
            ax.set_xlabel("Time (s)")
            ax.grid(True, alpha=0.20, linewidth=0.5)
            ax.set_title("Prescribed disturbance")

            ax = axes[0, 1]
            add_three_model_lines(
                ax,
                t,
                ref[:, POWER_INDEX],
                control[:, POWER_INDEX],
                pino[:, POWER_INDEX],
                ylabel="Normalized power",
            )
            ax.set_xlabel("Time (s)")
            ax.set_title("Reactor power")

            for ax, state_index, title in [
                (axes[1, 0], FUEL_INDEX, "Fuel temperature"),
                (axes[1, 1], BLOCK_INDEX, "Block temperature"),
                (axes[2, 0], COOLANT_INDEX, "Bulk-coolant temperature"),
            ]:
                add_three_model_lines(
                    ax,
                    t,
                    ref[:, state_index],
                    control[:, state_index],
                    pino[:, state_index],
                    ylabel="Temperature (K)",
                )
                ax.set_xlabel("Time (s)")
                ax.set_title(title)

            ax = axes[2, 1]
            control_error = np.sqrt(
                np.mean((control - ref) ** 2, axis=1)
            )
            pino_error = np.sqrt(
                np.mean((pino - ref) ** 2, axis=1)
            )
            ax.plot(t, control_error, linewidth=1.1, linestyle="--", label="Matched control")
            ax.plot(t, pino_error, linewidth=1.1, linestyle=":", label="Full PINO")
            ax.set_xlabel("Time (s)")
            ax.set_ylabel("10-state physical RMSE")
            ax.set_title("Instantaneous physical-state error")
            ax.grid(True, alpha=0.20, linewidth=0.5)

            handles, labels = axes[0, 1].get_legend_handles_labels()
            fig.legend(
                handles,
                labels,
                loc="upper center",
                ncol=3,
                frameon=False,
                bbox_to_anchor=(0.5, 0.985),
            )

            improvement = float(record.get("pino_global_improvement_percent", float("nan")))
            improvement_text = (
                f" | global normalized-MSE change {improvement:+.2f}%"
                if math.isfinite(improvement)
                else ""
            )

            fig.suptitle(
                make_case_title(record)
                + f" | global case {int(record['global_case_index'])}"
                + improvement_text,
                y=0.998,
                fontsize=10,
            )

            fig.tight_layout(rect=(0, 0, 1, 0.965))
            pdf.savefig(fig, bbox_inches="tight")
            plt.close(fig)

    return str(atlas_path)


# =====================================================================
# MAIN
# =====================================================================


def main():
    configure_matplotlib()

    root = find_root()

    input_dir = (
        root
        / "step7_pino"
        / "physics_informed"
        / "per_case_analysis"
    )

    representative_json_path = require_file(
        input_dir / "212_representative_cases.json"
    )

    representative_npz_path = require_file(
        input_dir / "212_representative_trajectories.npz"
    )

    report212_path = require_file(
        input_dir / "212_per_case_generalization_report.json"
    )

    output_dir = (
        root
        / "step7_pino"
        / "physics_informed"
        / "publication_figures"
    )
    output_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 78)
    print("STEP 7 REPRESENTATIVE TRANSIENT PUBLICATION FIGURES")
    print("=" * 78)
    print(f"Project root : {root}")
    print("Training     : NO")
    print("Tuning       : NO")
    print("Reselection  : NO")
    print("Dataset edit : NO")
    print()

    records = json.loads(
        representative_json_path.read_text(encoding="utf-8")
    )

    report212 = json.loads(
        report212_path.read_text(encoding="utf-8")
    )

    if report212.get("representative_selection", {}).get("uses_model_errors") is not False:
        raise RuntimeError(
            "File-212 representative-selection contract is not error-independent."
        )

    if len(records) != int(
        report212.get("representative_selection", {}).get("number_selected", -1)
    ):
        raise RuntimeError("Representative count does not match File-212 report.")

    if len(records) != 12:
        raise RuntimeError(
            f"Expected 12 frozen File-212 representatives, found {len(records)}."
        )

    partitions_present = sorted(set(row["partition"] for row in records))
    if sorted(EXPECTED_PARTITIONS) != partitions_present:
        raise RuntimeError(
            "Frozen representative set does not span all confirmatory partitions."
        )

    archive = np.load(representative_npz_path, allow_pickle=False)

    case_data = [
        load_case_data(archive, index, record)
        for index, record in enumerate(records)
    ]

    print("FROZEN REPRESENTATIVE AUDIT")
    print("-" * 78)
    print(f"Representative cases : {len(records)}")
    print("Selection source      : File 212 input-space medoids")
    print("Prediction-error selection used : NO")
    print("Partitions represented: ID, OOD-negative, OOD-positive, stress")
    print()

    # -----------------------------------------------------------------
    # CASE TABLE
    # -----------------------------------------------------------------

    table_rows = []

    for record in records:
        control_mse = float(
            record.get("control_global_normalized_mse", float("nan"))
        )
        pino_mse = float(
            record.get("pino_global_normalized_mse", float("nan"))
        )

        table_rows.append({
            "partition": record["partition"],
            "waveform": record["waveform"],
            "sign": record["sign"],
            "global_case_index": int(record["global_case_index"]),
            "amplitude_delta_k_over_k": float(record.get("amplitude_delta_k_over_k", float("nan"))),
            "amplitude_pcm": float(record.get("amplitude_pcm", float("nan"))),
            "amplitude_cents": float(record.get("amplitude_cents", float("nan"))),
            "approx_onset_time_s": float(record.get("approx_onset_time_s", float("nan"))),
            "control_global_normalized_mse": control_mse,
            "pino_global_normalized_mse": pino_mse,
            "pino_global_improvement_percent": (
                float(record.get("pino_global_improvement_percent"))
                if record.get("pino_global_improvement_percent") is not None
                else percent_improvement(control_mse, pino_mse)
            ),
            "selection_rule": record["selection_rule"],
        })

    case_table_path = output_dir / "213_representative_case_table.csv"
    write_csv(case_table_path, table_rows)

    # -----------------------------------------------------------------
    # COMPOSITE FIGURES
    # -----------------------------------------------------------------

    step_global = make_power_composite(
        records,
        case_data,
        "STEP_HOLD",
        output_dir,
    )

    ramp_global = make_power_composite(
        records,
        case_data,
        "LINEAR_RAMP_HOLD",
        output_dir,
    )

    step_event = make_step_event_composite(
        records,
        case_data,
        output_dir,
    )

    coolant = make_thermal_composite(
        records,
        case_data,
        output_dir,
    )

    atlas = make_atlas(
        records,
        case_data,
        output_dir,
    )

    # -----------------------------------------------------------------
    # FIGURE MANIFEST FOR MANUSCRIPT DRAFTING
    # -----------------------------------------------------------------

    manifest = {
        "source": "File 212 frozen input-space medoid representatives",
        "representative_reselection_performed": False,
        "prediction_error_used_for_selection": False,
        "main_paper_candidates": [
            {
                "provisional_figure": "Figure 9a",
                "file": step_global,
                "purpose": (
                    "Global STEP reactor-power trajectories across ID, OOD-negative, "
                    "OOD-positive, and stress representative subgroups."
                ),
            },
            {
                "provisional_figure": "Figure 9b",
                "file": step_event,
                "purpose": (
                    "Prompt/event-local STEP reactor-power trajectories on the multirate "
                    "event coordinate."
                ),
            },
            {
                "provisional_figure": "Figure 9c",
                "file": ramp_global,
                "purpose": (
                    "Global RAMP reactor-power trajectories across confirmatory regimes."
                ),
            },
            {
                "provisional_figure": "Figure 9d or Supplementary",
                "file": coolant,
                "purpose": (
                    "Bulk-coolant temperature trajectories showing the thermal state "
                    "directly coupled to the Brayton/core closure."
                ),
            },
        ],
        "supplementary_candidate": {
            "file": atlas,
            "purpose": (
                "Complete six-panel trajectory atlas for all 12 frozen representative cases, "
                "including disturbance, power, three thermal states, and instantaneous error."
            ),
        },
        "representative_case_table": str(case_table_path),
    }

    manifest_path = output_dir / "213_figure_manifest.json"
    manifest_path.write_text(
        json.dumps(serializable(manifest), indent=2, allow_nan=False),
        encoding="utf-8",
    )

    report_payload = {
        "script": "213_step7_representative_transient_publication_figures.py",
        "status": "REPRESENTATIVE_TRANSIENT_PUBLICATION_FIGURES_COMPLETE",
        "training_performed": False,
        "tuning_performed": False,
        "checkpoint_selection_performed": False,
        "representative_reselection_performed": False,
        "dataset_modified": False,
        "source_file": "212_step7_per_case_generalization_and_representative_transients.py",
        "number_representatives": len(records),
        "figure_manifest": manifest,
        "outputs": {
            "case_table_csv": str(case_table_path),
            "figure_manifest_json": str(manifest_path),
            "trajectory_atlas_pdf": atlas,
        },
    }

    output_json = output_dir / "213_representative_transient_publication_report.json"
    output_txt = output_dir / "213_representative_transient_publication_report.txt"

    output_json.write_text(
        json.dumps(serializable(report_payload), indent=2, allow_nan=False),
        encoding="utf-8",
    )

    lines = [
        "=" * 78,
        "STEP 7 REPRESENTATIVE TRANSIENT PUBLICATION FIGURE REPORT",
        "=" * 78,
        "",
        f"Frozen representatives : {len(records)}",
        "Representative reselection : NO",
        "Prediction-error selection : NO",
        "Training                  : NO",
        "Tuning                    : NO",
        "Production-V1 modified    : NO",
        "",
        f"Representative table : {case_table_path}",
        f"STEP global figure   : {step_global['png'] if step_global else 'N/A'}",
        f"STEP event figure    : {step_event['png'] if step_event else 'N/A'}",
        f"RAMP global figure   : {ramp_global['png'] if ramp_global else 'N/A'}",
        f"Coolant figure       : {coolant['png'] if coolant else 'N/A'}",
        f"Trajectory atlas     : {atlas}",
        f"Figure manifest      : {manifest_path}",
        "",
        "STATUS: REPRESENTATIVE_TRANSIENT_PUBLICATION_FIGURES_COMPLETE",
    ]

    output_txt.write_text("\n".join(lines) + "\n", encoding="utf-8")

    print("PUBLICATION FIGURES")
    print("-" * 78)
    if step_global:
        print(f"STEP global power : {step_global['png']}")
    if step_event:
        print(f"STEP event power  : {step_event['png']}")
    if ramp_global:
        print(f"RAMP global power : {ramp_global['png']}")
    if coolant:
        print(f"Coolant thermal   : {coolant['png']}")
    print(f"Trajectory atlas  : {atlas}")
    print(f"Case table        : {case_table_path}")
    print(f"Figure manifest   : {manifest_path}")
    print()
    print("=" * 78)
    print("STATUS: REPRESENTATIVE_TRANSIENT_PUBLICATION_FIGURES_COMPLETE")
    print("=" * 78)


if __name__ == "__main__":
    main()
