#!/usr/bin/env python3
"""
210_step7_full_physics_weight_gate.py

STEP 7 - FULL-PHYSICS PINO WEIGHT GATE

Physics families:
    Kinetics: 1 power + 6 precursor equations
    Thermal : fuel + block + bulk-coolant equations

Frozen composition from File 209:
    L_K       = mean(7 normalized kinetics residual MSEs)
    L_T       = mean(3 normalized thermal residual MSEs)
    L_physics = 0.5 * L_K + 0.5 * L_T
    L_total   = L_data + lambda_full * L_physics

Rules:
    - Every candidate starts from the original File-191 Model-B checkpoint.
    - Fine-tuning LR remains frozen at 5e-4.
    - Same optimizer state, batch/query schedule, and continuation budget.
    - Candidate fractions are pre-specified: 0.003, 0.010, 0.030.
    - TRAIN performs parameter updates.
    - VALIDATION performs checkpoint and candidate selection.
    - Matched data-only continuation is the attribution control.
    - ID/OOD/STRESS are not accessed.
    - Production-V1 is never modified.
    - No separate reactivity residual is invented.
    - No separate Brayton residual is invented.

A candidate is frozen only if:
    1. validation data MSE improves relative to the matched data-only control;
    2. the family-balanced full-physics residual shows stable paired
       validation improvement.

Kinetics and thermal residual changes are also reported separately for
attribution, but they are not additional tuning criteria.
"""

from __future__ import annotations

import copy
import gc
import importlib.util
import json
import math
import random
import sys
import time
from pathlib import Path

import numpy as np
import torch


# =====================================================================
# FROZEN EXPERIMENT CONTRACT
# =====================================================================

FROZEN_LEARNING_RATE = 5.0e-4
CONTINUATION_EPOCHS = 20
EFFECTIVE_BATCH_SIZE = 8
MICRO_BATCH_SIZE = 2
SCHEDULE_SEED = 20261999

CANDIDATE_FRACTIONS = [
    0.003,
    0.010,
    0.030,
]

KINETICS_FAMILY_WEIGHT = 0.5
THERMAL_FAMILY_WEIGHT = 0.5

AUDIT_REPLICATES = 12
AUDIT_BATCHES_PER_REPLICATE = 8
AUDIT_BATCH_SIZE = 4
AUDIT_SEED_BASE = 20262100
STABLE_POSITIVE_FRACTION = 0.80


# =====================================================================
# GENERAL UTILITIES
# =====================================================================

def find_root():
    current = Path.cwd().resolve()
    for path in [current, *current.parents]:
        if (path / "step6_dataset" / "production_v1").is_dir():
            return path
    raise FileNotFoundError("Could not locate He-Xe PINO project root.")


def require_file(path):
    if not path.exists():
        raise FileNotFoundError(path)
    return path


def load_module(name, path):
    path = require_file(path)
    spec = importlib.util.spec_from_file_location(name, str(path))
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not import:\n{path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def cpu_state_dict(model):
    return {
        key: value.detach().cpu().clone()
        for key, value in model.state_dict().items()
    }


def percent_improvement(reference, candidate):
    if reference == 0.0:
        return float("nan")
    return 100.0 * (reference - candidate) / reference


def serializable(value):
    if isinstance(value, dict):
        return {k: serializable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [serializable(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.floating):
        return float(value)
    if isinstance(value, np.integer):
        return int(value)
    return value


# =====================================================================
# FULL-PHYSICS TRAINING LOSS
# =====================================================================

def full_physics_loss_training(
    prediction,
    query,
    raw_branch,
    query_indices,
    state_mean_t,
    state_std_t,
    kinetics_scales_t,
    thermal_scales_t,
    beta_t,
    lambdas_t,
    generation_time,
    fuel_coeff_t,
    block_coeff_t,
    fuel_reference,
    block_reference,
    horizon_seconds,
    file196,
    file204,
    file208,
    file74,
    file206,
    thermal_model,
):
    kinetics_loss, kinetics_equation_mse = (
        file204.coupled_kinetics_loss_training(
            prediction=prediction,
            query=query,
            raw_branch=raw_branch,
            query_indices=query_indices,
            state_mean_t=state_mean_t,
            state_std_t=state_std_t,
            physics_scales_t=kinetics_scales_t,
            beta_t=beta_t,
            lambdas_t=lambdas_t,
            generation_time=generation_time,
            fuel_coeff_t=fuel_coeff_t,
            block_coeff_t=block_coeff_t,
            fuel_reference=fuel_reference,
            block_reference=block_reference,
            horizon_seconds=horizon_seconds,
            file196=file196,
        )
    )

    thermal_loss, thermal_equation_mse = (
        file208.thermal_physics_loss_training(
            prediction=prediction,
            query=query,
            state_mean_t=state_mean_t,
            state_std_t=state_std_t,
            thermal_scale_t=thermal_scales_t,
            horizon_seconds=horizon_seconds,
            file74=file74,
            file206=file206,
            thermal_model=thermal_model,
        )
    )

    full_physics_loss = (
        KINETICS_FAMILY_WEIGHT * kinetics_loss
        + THERMAL_FAMILY_WEIGHT * thermal_loss
    )

    return (
        full_physics_loss,
        kinetics_loss,
        thermal_loss,
        kinetics_equation_mse,
        thermal_equation_mse,
    )


# =====================================================================
# TRAIN ONE REPRESENTATION
# =====================================================================

def train_representation(
    *,
    model,
    optimizer,
    branch_array,
    state_array,
    ordered_cases,
    time_norm_tensor,
    query_sampler,
    query_generator,
    forward_method,
    rho_mean,
    rho_std,
    state_mean,
    state_std,
    state_mean_t,
    state_std_t,
    kinetics_scales_t,
    thermal_scales_t,
    physics_weight,
    beta_t,
    lambdas_t,
    generation_time,
    fuel_coeff_t,
    block_coeff_t,
    fuel_reference,
    block_reference,
    horizon_seconds,
    file191,
    file196,
    file204,
    file208,
    file74,
    file206,
    thermal_model,
    device,
):
    data_sum = 0.0
    full_sum = 0.0
    kinetics_sum = 0.0
    thermal_sum = 0.0
    kinetics_equation_sum = np.zeros(7, dtype=np.float64)
    thermal_equation_sum = np.zeros(3, dtype=np.float64)
    case_count = 0

    ordered_cases = np.asarray(ordered_cases, dtype=np.int64)

    for batch_start in range(
        0,
        len(ordered_cases),
        EFFECTIVE_BATCH_SIZE,
    ):
        effective_cases = ordered_cases[
            batch_start:batch_start + EFFECTIVE_BATCH_SIZE
        ]

        if len(effective_cases) == 0:
            continue

        query_indices_tensor = query_sampler(query_generator)
        query_indices = (
            query_indices_tensor
            .cpu()
            .numpy()
            .astype(np.int64, copy=False)
        )

        optimizer.zero_grad(set_to_none=True)
        effective_n = len(effective_cases)

        for micro_start in range(
            0,
            effective_n,
            MICRO_BATCH_SIZE,
        ):
            cases = effective_cases[
                micro_start:micro_start + MICRO_BATCH_SIZE
            ]
            micro_n = len(cases)

            raw_branch = np.asarray(
                branch_array[cases],
                dtype=np.float32,
            )

            branch_normalized = (
                raw_branch - np.float32(rho_mean)
            ) / np.float32(rho_std)

            target_full = (
                np.asarray(
                    state_array[cases],
                    dtype=np.float32,
                )
                - np.asarray(state_mean, dtype=np.float32)
            ) / np.asarray(state_std, dtype=np.float32)

            target = target_full[:, query_indices, :]

            branch_tensor = torch.from_numpy(
                branch_normalized
            ).to(device)

            target_tensor = torch.from_numpy(
                target
            ).to(device)

            query = (
                time_norm_tensor[query_indices_tensor]
                .view(1, -1, 1)
                .expand(micro_n, -1, -1)
                .clone()
                .detach()
                .requires_grad_(True)
            )

            prediction = forward_method(
                branch_tensor,
                query,
            )

            data_loss = torch.mean(
                (prediction - target_tensor) ** 2
            )

            (
                full_physics_loss,
                kinetics_loss,
                thermal_loss,
                kinetics_equation_mse,
                thermal_equation_mse,
            ) = full_physics_loss_training(
                prediction=prediction,
                query=query,
                raw_branch=raw_branch,
                query_indices=query_indices,
                state_mean_t=state_mean_t,
                state_std_t=state_std_t,
                kinetics_scales_t=kinetics_scales_t,
                thermal_scales_t=thermal_scales_t,
                beta_t=beta_t,
                lambdas_t=lambdas_t,
                generation_time=generation_time,
                fuel_coeff_t=fuel_coeff_t,
                block_coeff_t=block_coeff_t,
                fuel_reference=fuel_reference,
                block_reference=block_reference,
                horizon_seconds=horizon_seconds,
                file196=file196,
                file204=file204,
                file208=file208,
                file74=file74,
                file206=file206,
                thermal_model=thermal_model,
            )

            total_loss = (
                data_loss
                + physics_weight * full_physics_loss
            )

            gradient_weight = (
                float(micro_n) / float(effective_n)
            )

            (
                total_loss * gradient_weight
            ).backward()

            data_sum += float(
                data_loss.detach().cpu()
            ) * micro_n

            full_sum += float(
                full_physics_loss.detach().cpu()
            ) * micro_n

            kinetics_sum += float(
                kinetics_loss.detach().cpu()
            ) * micro_n

            thermal_sum += float(
                thermal_loss.detach().cpu()
            ) * micro_n

            kinetics_equation_sum += (
                kinetics_equation_mse
                .detach()
                .cpu()
                .numpy()
                .astype(np.float64)
                * micro_n
            )

            thermal_equation_sum += (
                thermal_equation_mse
                .detach()
                .cpu()
                .numpy()
                .astype(np.float64)
                * micro_n
            )

            case_count += micro_n

        torch.nn.utils.clip_grad_norm_(
            model.parameters(),
            file191.GRADIENT_CLIP,
        )

        optimizer.step()

    return {
        "data_loss": data_sum / case_count,
        "full_physics_loss": full_sum / case_count,
        "kinetics_loss": kinetics_sum / case_count,
        "thermal_loss": thermal_sum / case_count,
        "kinetics_equation_mse": (
            kinetics_equation_sum / case_count
        ).tolist(),
        "thermal_equation_mse": (
            thermal_equation_sum / case_count
        ).tolist(),
    }


# =====================================================================
# CHECKPOINT
# =====================================================================

def save_checkpoint(
    *,
    path,
    model,
    optimizer,
    epoch,
    validation_mse,
    fraction,
    physics_weight,
    base_checkpoint,
    normalization,
    kinetics_scales,
    thermal_scales,
):
    payload = {
        "model_state_dict": cpu_state_dict(model),
        "optimizer_state_dict": optimizer.state_dict(),
        "epoch": epoch,
        "best_validation_mse": validation_mse,
        "initialization": "File-191 model_b_best.pt",
        "initialization_epoch": base_checkpoint.get("epoch"),
        "physics_family": "full_kinetics_plus_thermal",
        "kinetics_residuals": True,
        "thermal_residuals": True,
        "kinetics_family_weight": KINETICS_FAMILY_WEIGHT,
        "thermal_family_weight": THERMAL_FAMILY_WEIGHT,
        "physics_fraction": fraction,
        "physics_weight": physics_weight,
        "kinetics_scales": kinetics_scales.tolist(),
        "thermal_scales": thermal_scales.tolist(),
        "learning_rate": FROZEN_LEARNING_RATE,
        "normalization": normalization,
        "test_partitions_used": False,
    }

    torch.save(payload, path)


# =====================================================================
# RUN ONE FULL-PHYSICS CANDIDATE
# =====================================================================

def run_candidate(
    *,
    fraction,
    physics_weight,
    file191,
    file196,
    file204,
    file208,
    file74,
    file206,
    thermal_model,
    base_checkpoint,
    normalization,
    global_rho,
    global_state,
    event_rho,
    event_state,
    event_mapping,
    global_time,
    event_time,
    global_time_norm_t,
    event_time_norm_t,
    rho_mean,
    rho_std,
    state_mean,
    state_std,
    state_mean_t,
    state_std_t,
    kinetics_scales,
    thermal_scales,
    kinetics_scales_t,
    thermal_scales_t,
    beta_t,
    lambdas_t,
    generation_time,
    fuel_coeff_t,
    block_coeff_t,
    fuel_reference,
    block_reference,
    device,
    output_dir,
):
    model = file191.ModelB().to(device)
    model.load_state_dict(
        base_checkpoint["model_state_dict"]
    )

    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=FROZEN_LEARNING_RATE,
        weight_decay=file191.WEIGHT_DECAY,
    )

    if "optimizer_state_dict" in base_checkpoint:
        optimizer.load_state_dict(
            copy.deepcopy(
                base_checkpoint["optimizer_state_dict"]
            )
        )

    for group in optimizer.param_groups:
        group["lr"] = FROZEN_LEARNING_RATE
        group["weight_decay"] = file191.WEIGHT_DECAY

    numpy_rng = np.random.default_rng(
        SCHEDULE_SEED
    )

    query_generator = torch.Generator(
        device="cpu"
    )
    query_generator.manual_seed(
        SCHEDULE_SEED + 1
    )

    train_global = np.arange(
        file191.PARTITIONS["TRAIN"][0],
        file191.PARTITIONS["TRAIN"][1],
        dtype=np.int64,
    )

    train_event = np.asarray(
        event_mapping["TRAIN"],
        dtype=np.int64,
    )

    global_horizon = float(
        global_time[-1] - global_time[0]
    )

    event_horizon = float(
        event_time[-1] - event_time[0]
    )

    def global_sampler(generator):
        return file191.sample_global_queries(
            global_time_norm_t,
            file191.GLOBAL_QUERY_POINTS,
            generator,
        )

    def event_sampler(generator):
        return file191.sample_event_queries(
            event_time,
            file191.EVENT_FAST_QUERY_POINTS,
            file191.EVENT_SLOW_QUERY_POINTS,
            generator,
        )

    validation_initial = file191.evaluate_partition(
        model,
        global_rho,
        global_state,
        event_rho,
        event_state,
        event_mapping["VALIDATION"],
        global_time_norm_t,
        event_time_norm_t,
        file191.PARTITIONS["VALIDATION"][0],
        file191.PARTITIONS["VALIDATION"][1],
        rho_mean,
        rho_std,
        state_mean,
        state_std,
        device,
    )

    best_validation = float(
        validation_initial["combined_mse"]
    )
    best_epoch = 0

    tag = f"{fraction:.3f}".replace(".", "p")

    checkpoint_path = (
        output_dir / f"full_physics_{tag}_best.pt"
    )

    history_path = (
        output_dir / f"full_physics_{tag}_history.json"
    )

    save_checkpoint(
        path=checkpoint_path,
        model=model,
        optimizer=optimizer,
        epoch=0,
        validation_mse=best_validation,
        fraction=fraction,
        physics_weight=physics_weight,
        base_checkpoint=base_checkpoint,
        normalization=normalization,
        kinetics_scales=kinetics_scales,
        thermal_scales=thermal_scales,
    )

    history = []

    print()
    print("=" * 78)
    print(
        f"FULL-PHYSICS FRACTION {fraction:.3f}"
    )
    print("=" * 78)
    print(
        f"Physics lambda : {physics_weight:.10e}"
    )
    print(
        f"Starting MSE   : {best_validation:.10e}"
    )

    for epoch in range(
        1,
        CONTINUATION_EPOCHS + 1,
    ):
        epoch_start = time.perf_counter()
        model.train()

        shuffled_global = numpy_rng.permutation(
            train_global
        )

        global_result = train_representation(
            model=model,
            optimizer=optimizer,
            branch_array=global_rho,
            state_array=global_state,
            ordered_cases=shuffled_global,
            time_norm_tensor=global_time_norm_t,
            query_sampler=global_sampler,
            query_generator=query_generator,
            forward_method=model.forward_global,
            rho_mean=rho_mean,
            rho_std=rho_std,
            state_mean=state_mean,
            state_std=state_std,
            state_mean_t=state_mean_t,
            state_std_t=state_std_t,
            kinetics_scales_t=kinetics_scales_t,
            thermal_scales_t=thermal_scales_t,
            physics_weight=physics_weight,
            beta_t=beta_t,
            lambdas_t=lambdas_t,
            generation_time=generation_time,
            fuel_coeff_t=fuel_coeff_t,
            block_coeff_t=block_coeff_t,
            fuel_reference=fuel_reference,
            block_reference=block_reference,
            horizon_seconds=global_horizon,
            file191=file191,
            file196=file196,
            file204=file204,
            file208=file208,
            file74=file74,
            file206=file206,
            thermal_model=thermal_model,
            device=device,
        )

        shuffled_event = numpy_rng.permutation(
            train_event
        )

        event_result = train_representation(
            model=model,
            optimizer=optimizer,
            branch_array=event_rho,
            state_array=event_state,
            ordered_cases=shuffled_event,
            time_norm_tensor=event_time_norm_t,
            query_sampler=event_sampler,
            query_generator=query_generator,
            forward_method=model.forward_event,
            rho_mean=rho_mean,
            rho_std=rho_std,
            state_mean=state_mean,
            state_std=state_std,
            state_mean_t=state_mean_t,
            state_std_t=state_std_t,
            kinetics_scales_t=kinetics_scales_t,
            thermal_scales_t=thermal_scales_t,
            physics_weight=physics_weight,
            beta_t=beta_t,
            lambdas_t=lambdas_t,
            generation_time=generation_time,
            fuel_coeff_t=fuel_coeff_t,
            block_coeff_t=block_coeff_t,
            fuel_reference=fuel_reference,
            block_reference=block_reference,
            horizon_seconds=event_horizon,
            file191=file191,
            file196=file196,
            file204=file204,
            file208=file208,
            file74=file74,
            file206=file206,
            thermal_model=thermal_model,
            device=device,
        )

        validation = file191.evaluate_partition(
            model,
            global_rho,
            global_state,
            event_rho,
            event_state,
            event_mapping["VALIDATION"],
            global_time_norm_t,
            event_time_norm_t,
            file191.PARTITIONS["VALIDATION"][0],
            file191.PARTITIONS["VALIDATION"][1],
            rho_mean,
            rho_std,
            state_mean,
            state_std,
            device,
        )

        wg = file191.GLOBAL_LOSS_WEIGHT
        we = file191.EVENT_LOSS_WEIGHT

        train_data = (
            wg * global_result["data_loss"]
            + we * event_result["data_loss"]
        )

        train_full = (
            wg * global_result["full_physics_loss"]
            + we * event_result["full_physics_loss"]
        )

        train_kinetics = (
            wg * global_result["kinetics_loss"]
            + we * event_result["kinetics_loss"]
        )

        train_thermal = (
            wg * global_result["thermal_loss"]
            + we * event_result["thermal_loss"]
        )

        total_loss = (
            train_data
            + physics_weight * train_full
        )

        improved = (
            validation["combined_mse"]
            < best_validation
            - file191.MIN_VALIDATION_IMPROVEMENT
        )

        if improved:
            best_validation = float(
                validation["combined_mse"]
            )
            best_epoch = epoch

            save_checkpoint(
                path=checkpoint_path,
                model=model,
                optimizer=optimizer,
                epoch=epoch,
                validation_mse=best_validation,
                fraction=fraction,
                physics_weight=physics_weight,
                base_checkpoint=base_checkpoint,
                normalization=normalization,
                kinetics_scales=kinetics_scales,
                thermal_scales=thermal_scales,
            )

        elapsed = time.perf_counter() - epoch_start

        history.append({
            "epoch": epoch,
            "global_data_loss": global_result["data_loss"],
            "event_data_loss": event_result["data_loss"],
            "combined_data_loss": train_data,
            "global_full_physics_loss": global_result["full_physics_loss"],
            "event_full_physics_loss": event_result["full_physics_loss"],
            "combined_full_physics_loss": train_full,
            "combined_kinetics_loss": train_kinetics,
            "combined_thermal_loss": train_thermal,
            "total_loss": total_loss,
            "validation_mse": validation["combined_mse"],
            "validation_rmse": validation["normalized_rmse"],
            "best_validation_mse": best_validation,
            "best_epoch": best_epoch,
            "seconds": elapsed,
        })

        print(
            f"Epoch {epoch:02d} | "
            f"Data={train_data:.6e} | "
            f"K={train_kinetics:.6e} | "
            f"T={train_thermal:.6e} | "
            f"Full={train_full:.6e} | "
            f"Val={validation['combined_mse']:.6e} | "
            f"Best={best_validation:.6e} | "
            f"BestEpoch={best_epoch:02d} | "
            f"Time={elapsed:.1f}s"
        )

    history_path.write_text(
        json.dumps(
            serializable(history),
            indent=2,
            allow_nan=False,
        ),
        encoding="utf-8",
    )

    checkpoint = torch.load(
        checkpoint_path,
        map_location=device,
        weights_only=False,
    )

    model.load_state_dict(
        checkpoint["model_state_dict"]
    )
    model.eval()

    return {
        "model": model,
        "checkpoint": checkpoint,
        "checkpoint_path": checkpoint_path,
        "history_path": history_path,
        "best_epoch": int(checkpoint["epoch"]),
        "best_validation_mse": float(
            checkpoint["best_validation_mse"]
        ),
    }


# =====================================================================
# FULL-PHYSICS RESIDUAL AUDIT
# =====================================================================

def full_residual_batch(
    *,
    model,
    forward_method,
    branch_array,
    selected_cases,
    query_indices,
    normalized_time,
    horizon_seconds,
    rho_mean,
    rho_std,
    state_mean_t,
    state_std_t,
    kinetics_scales_t,
    thermal_scales_t,
    beta_t,
    lambdas_t,
    generation_time,
    fuel_coeff_t,
    block_coeff_t,
    fuel_reference,
    block_reference,
    file196,
    file204,
    file208,
    file74,
    file206,
    thermal_model,
    device,
):
    kinetics = file204.coupled_residual_batch(
        model=model,
        forward_method=forward_method,
        branch_array=branch_array,
        selected_cases=selected_cases,
        query_indices=query_indices,
        normalized_time=normalized_time,
        horizon_seconds=horizon_seconds,
        rho_mean=rho_mean,
        rho_std=rho_std,
        state_mean_t=state_mean_t,
        state_std_t=state_std_t,
        physics_scales_t=kinetics_scales_t,
        beta_t=beta_t,
        lambdas_t=lambdas_t,
        generation_time=generation_time,
        fuel_coeff_t=fuel_coeff_t,
        block_coeff_t=block_coeff_t,
        fuel_reference=fuel_reference,
        block_reference=block_reference,
        file196=file196,
        device=device,
    )

    thermal = file208.thermal_residual_batch(
        model=model,
        forward_method=forward_method,
        branch_array=branch_array,
        selected_cases=selected_cases,
        query_indices=query_indices,
        normalized_time=normalized_time,
        horizon_seconds=horizon_seconds,
        rho_mean=rho_mean,
        rho_std=rho_std,
        state_mean_t=state_mean_t,
        state_std_t=state_std_t,
        thermal_scale_t=thermal_scales_t,
        file74=file74,
        file206=file206,
        thermal_model=thermal_model,
        device=device,
    )

    full = (
        KINETICS_FAMILY_WEIGHT * kinetics["coupled_mse"]
        + THERMAL_FAMILY_WEIGHT * thermal["thermal_mse"]
    )

    return {
        "full_mse": float(full),
        "kinetics_mse": float(kinetics["coupled_mse"]),
        "thermal_mse": float(thermal["thermal_mse"]),
        "kinetics_equation_mse": kinetics["equation_mse"],
        "thermal_equation_mse": thermal["equation_mse"],
    }


def paired_validation_replicate(
    *,
    control_model,
    candidate_model,
    seed,
    file191,
    file196,
    file204,
    file208,
    file74,
    file206,
    thermal_model,
    global_rho,
    event_rho,
    event_mapping,
    global_time,
    event_time,
    global_time_norm,
    event_time_norm,
    rho_mean,
    rho_std,
    state_mean_t,
    state_std_t,
    kinetics_scales_t,
    thermal_scales_t,
    beta_t,
    lambdas_t,
    generation_time,
    fuel_coeff_t,
    block_coeff_t,
    fuel_reference,
    block_reference,
    device,
):
    rng = np.random.default_rng(seed)

    start, stop = file191.PARTITIONS["VALIDATION"]
    global_available = np.arange(
        start,
        stop,
        dtype=np.int64,
    )
    event_available = np.asarray(
        event_mapping["VALIDATION"],
        dtype=np.int64,
    )

    records = {
        "control_global_full": [],
        "candidate_global_full": [],
        "control_event_full": [],
        "candidate_event_full": [],
        "control_global_kinetics": [],
        "candidate_global_kinetics": [],
        "control_event_kinetics": [],
        "candidate_event_kinetics": [],
        "control_global_thermal": [],
        "candidate_global_thermal": [],
        "control_event_thermal": [],
        "candidate_event_thermal": [],
    }

    for _ in range(
        AUDIT_BATCHES_PER_REPLICATE
    ):
        global_cases = rng.choice(
            global_available,
            size=AUDIT_BATCH_SIZE,
            replace=False,
        )

        global_queries = file196.sample_global(
            total_points=file191.GLOBAL_POINTS,
            number_points=file191.GLOBAL_QUERY_POINTS,
            rng=rng,
        )

        control_g = full_residual_batch(
            model=control_model,
            forward_method=control_model.forward_global,
            branch_array=global_rho,
            selected_cases=global_cases,
            query_indices=global_queries,
            normalized_time=global_time_norm,
            horizon_seconds=float(
                global_time[-1] - global_time[0]
            ),
            rho_mean=rho_mean,
            rho_std=rho_std,
            state_mean_t=state_mean_t,
            state_std_t=state_std_t,
            kinetics_scales_t=kinetics_scales_t,
            thermal_scales_t=thermal_scales_t,
            beta_t=beta_t,
            lambdas_t=lambdas_t,
            generation_time=generation_time,
            fuel_coeff_t=fuel_coeff_t,
            block_coeff_t=block_coeff_t,
            fuel_reference=fuel_reference,
            block_reference=block_reference,
            file196=file196,
            file204=file204,
            file208=file208,
            file74=file74,
            file206=file206,
            thermal_model=thermal_model,
            device=device,
        )

        candidate_g = full_residual_batch(
            model=candidate_model,
            forward_method=candidate_model.forward_global,
            branch_array=global_rho,
            selected_cases=global_cases,
            query_indices=global_queries,
            normalized_time=global_time_norm,
            horizon_seconds=float(
                global_time[-1] - global_time[0]
            ),
            rho_mean=rho_mean,
            rho_std=rho_std,
            state_mean_t=state_mean_t,
            state_std_t=state_std_t,
            kinetics_scales_t=kinetics_scales_t,
            thermal_scales_t=thermal_scales_t,
            beta_t=beta_t,
            lambdas_t=lambdas_t,
            generation_time=generation_time,
            fuel_coeff_t=fuel_coeff_t,
            block_coeff_t=block_coeff_t,
            fuel_reference=fuel_reference,
            block_reference=block_reference,
            file196=file196,
            file204=file204,
            file208=file208,
            file74=file74,
            file206=file206,
            thermal_model=thermal_model,
            device=device,
        )

        event_cases = rng.choice(
            event_available,
            size=AUDIT_BATCH_SIZE,
            replace=False,
        )

        event_queries = file196.sample_event(
            event_time=event_time,
            fast_number=file191.EVENT_FAST_QUERY_POINTS,
            slow_number=file191.EVENT_SLOW_QUERY_POINTS,
            rng=rng,
        )

        control_e = full_residual_batch(
            model=control_model,
            forward_method=control_model.forward_event,
            branch_array=event_rho,
            selected_cases=event_cases,
            query_indices=event_queries,
            normalized_time=event_time_norm,
            horizon_seconds=float(
                event_time[-1] - event_time[0]
            ),
            rho_mean=rho_mean,
            rho_std=rho_std,
            state_mean_t=state_mean_t,
            state_std_t=state_std_t,
            kinetics_scales_t=kinetics_scales_t,
            thermal_scales_t=thermal_scales_t,
            beta_t=beta_t,
            lambdas_t=lambdas_t,
            generation_time=generation_time,
            fuel_coeff_t=fuel_coeff_t,
            block_coeff_t=block_coeff_t,
            fuel_reference=fuel_reference,
            block_reference=block_reference,
            file196=file196,
            file204=file204,
            file208=file208,
            file74=file74,
            file206=file206,
            thermal_model=thermal_model,
            device=device,
        )

        candidate_e = full_residual_batch(
            model=candidate_model,
            forward_method=candidate_model.forward_event,
            branch_array=event_rho,
            selected_cases=event_cases,
            query_indices=event_queries,
            normalized_time=event_time_norm,
            horizon_seconds=float(
                event_time[-1] - event_time[0]
            ),
            rho_mean=rho_mean,
            rho_std=rho_std,
            state_mean_t=state_mean_t,
            state_std_t=state_std_t,
            kinetics_scales_t=kinetics_scales_t,
            thermal_scales_t=thermal_scales_t,
            beta_t=beta_t,
            lambdas_t=lambdas_t,
            generation_time=generation_time,
            fuel_coeff_t=fuel_coeff_t,
            block_coeff_t=block_coeff_t,
            fuel_reference=fuel_reference,
            block_reference=block_reference,
            file196=file196,
            file204=file204,
            file208=file208,
            file74=file74,
            file206=file206,
            thermal_model=thermal_model,
            device=device,
        )

        for family, key in [
            ("full", "full_mse"),
            ("kinetics", "kinetics_mse"),
            ("thermal", "thermal_mse"),
        ]:
            records[f"control_global_{family}"].append(
                control_g[key]
            )
            records[f"candidate_global_{family}"].append(
                candidate_g[key]
            )
            records[f"control_event_{family}"].append(
                control_e[key]
            )
            records[f"candidate_event_{family}"].append(
                candidate_e[key]
            )

    result = {"seed": seed}

    for family in [
        "full",
        "kinetics",
        "thermal",
    ]:
        control_global = float(
            np.mean(records[f"control_global_{family}"])
        )
        candidate_global = float(
            np.mean(records[f"candidate_global_{family}"])
        )
        control_event = float(
            np.mean(records[f"control_event_{family}"])
        )
        candidate_event = float(
            np.mean(records[f"candidate_event_{family}"])
        )

        control_combined = (
            file191.GLOBAL_LOSS_WEIGHT * control_global
            + file191.EVENT_LOSS_WEIGHT * control_event
        )
        candidate_combined = (
            file191.GLOBAL_LOSS_WEIGHT * candidate_global
            + file191.EVENT_LOSS_WEIGHT * candidate_event
        )

        result[family] = {
            "control_global": control_global,
            "candidate_global": candidate_global,
            "control_event": control_event,
            "candidate_event": candidate_event,
            "control_combined": control_combined,
            "candidate_combined": candidate_combined,
            "combined_improvement_percent": percent_improvement(
                control_combined,
                candidate_combined,
            ),
        }

    return result


def summarize_family_stability(
    records,
    family,
):
    improvements = np.asarray(
        [
            row[family]["combined_improvement_percent"]
            for row in records
        ],
        dtype=np.float64,
    )

    positive = int(
        np.sum(improvements > 0.0)
    )

    required_positive = math.ceil(
        STABLE_POSITIVE_FRACTION * len(records)
    )

    mean_improvement = float(
        np.mean(improvements)
    )

    stable_improvement = bool(
        positive >= required_positive
        and mean_improvement > 0.0
    )

    return {
        "replicates": len(records),
        "positive_replicates": positive,
        "required_positive": required_positive,
        "mean_improvement_percent": mean_improvement,
        "median_improvement_percent": float(
            np.median(improvements)
        ),
        "minimum_improvement_percent": float(
            np.min(improvements)
        ),
        "maximum_improvement_percent": float(
            np.max(improvements)
        ),
        "q10_percent": float(
            np.quantile(improvements, 0.10)
        ),
        "q90_percent": float(
            np.quantile(improvements, 0.90)
        ),
        "stable_improvement": stable_improvement,
    }


# =====================================================================
# MAIN
# =====================================================================

def main():
    set_seed(20261002)

    root = find_root()
    production = root / "step6_dataset" / "production_v1"

    file191 = load_module(
        "file191_210",
        root / "191_step7_model_b_training.py",
    )
    file196 = load_module(
        "file196_210",
        root / "196_step7_kinetics_physics_preflight_gate.py",
    )
    file204 = load_module(
        "file204_210",
        root / "204_step7_coupled_kinetics_weight_gate.py",
    )
    file206 = load_module(
        "file206_210",
        root / "206_step7_exact_thermal_autograd_closure_audit.py",
    )
    file208 = load_module(
        "file208_210",
        root / "208_step7_thermal_only_weight_gate.py",
    )
    file70 = load_module(
        "file70_210",
        root / "70_reference_reactor_kinetics.py",
    )
    file74 = load_module(
        "file74_210",
        root / "74_master_coupled_reference_model.py",
    )

    file198_path = (
        root
        / "step7_pino"
        / "physics_informed"
        / "preflight"
        / "198_dimensionless_kinetics_residual_gate.json"
    )

    file207_path = (
        root
        / "step7_pino"
        / "physics_informed"
        / "thermal_preflight"
        / "207_thermal_residual_normalization_gate.json"
    )

    file209_path = (
        root
        / "step7_pino"
        / "physics_informed"
        / "full_physics_preflight"
        / "209_full_physics_composition_preflight.json"
    )

    base_checkpoint_path = (
        root
        / "step7_pino"
        / "model_b_training"
        / "model_b_best.pt"
    )

    control_checkpoint_path = (
        root
        / "step7_pino"
        / "physics_informed"
        / "power_lr_gate"
        / "lr_0p5_data_control_best.pt"
    )

    output_dir = (
        root
        / "step7_pino"
        / "physics_informed"
        / "full_physics"
    )
    output_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    output_json = (
        output_dir
        / "210_full_physics_weight_gate.json"
    )
    output_txt = (
        output_dir
        / "210_full_physics_weight_gate.txt"
    )

    print("=" * 78)
    print("STEP 7 FULL-PHYSICS PINO WEIGHT GATE")
    print("=" * 78)
    print(f"Project root : {root}")

    file198 = json.loads(
        require_file(file198_path).read_text(
            encoding="utf-8"
        )
    )
    file207 = json.loads(
        require_file(file207_path).read_text(
            encoding="utf-8"
        )
    )
    file209 = json.loads(
        require_file(file209_path).read_text(
            encoding="utf-8"
        )
    )

    if file198.get("status") != "PASS":
        raise RuntimeError("File 198 has not passed.")

    if (
        file207.get("status")
        != "THERMAL_RESIDUAL_NORMALIZATION_READY"
    ):
        raise RuntimeError("File 207 has not passed.")

    if (
        file209.get("status")
        != "FULL_PHYSICS_COMPOSITION_READY"
    ):
        raise RuntimeError(
            "File 209 full-physics composition is not ready."
        )

    family_contract = file209[
        "equation_count_bias_audit"
    ]["family_balanced"]

    if not (
        math.isclose(
            float(family_contract["kinetics_family_weight"]),
            KINETICS_FAMILY_WEIGHT,
            abs_tol=1.0e-15,
        )
        and math.isclose(
            float(family_contract["thermal_family_weight"]),
            THERMAL_FAMILY_WEIGHT,
            abs_tol=1.0e-15,
        )
    ):
        raise RuntimeError(
            "File 209 family-weight contract mismatch."
        )

    equal_lambda = float(
        file209[
            "diagnostic_weight_scale"
        ]["equal_contribution_lambda"]
    )

    candidates = [
        {
            "fraction": fraction,
            "lambda": fraction * equal_lambda,
        }
        for fraction in CANDIDATE_FRACTIONS
    ]

    kinetics_scales = np.asarray(
        file198["physics_scales"],
        dtype=np.float64,
    )

    thermal_scales = np.asarray(
        file207[
            "normalization_contract"
        ]["thermal_scales"],
        dtype=np.float64,
    )

    print()
    print("FULL-PHYSICS CONTRACT")
    print("-" * 78)
    print("Kinetics equations : 7")
    print("Thermal equations  : 3")
    print("Family weights     : 0.5 kinetics / 0.5 thermal")
    print(f"Equal-scale lambda : {equal_lambda:.10e}")
    print(f"Frozen LR          : {FROZEN_LEARNING_RATE:.10e}")
    print(f"Continuation       : {CONTINUATION_EPOCHS} epochs")
    print("Candidate fractions: 0.003, 0.010, 0.030")

    device = torch.device(
        "cuda" if torch.cuda.is_available() else "cpu"
    )

    print()
    print(f"Device : {device}")
    if device.type == "cuda":
        print(
            "GPU    : "
            + torch.cuda.get_device_name(0)
        )

    global_time = np.asarray(
        file191.load_npy(
            production,
            "global_time_s.npy",
        ),
        dtype=np.float32,
    )
    global_rho = file191.load_npy(
        production,
        "global_reactivity_delta_k_over_k.npy",
    )
    global_state = file191.load_npy(
        production,
        "global_state.npy",
    )

    event_time = np.asarray(
        file191.load_npy(
            production,
            "step_event_relative_time_s.npy",
        ),
        dtype=np.float32,
    )
    event_rho = file191.load_npy(
        production,
        "step_event_reactivity_delta_k_over_k.npy",
    )
    event_state = file191.load_npy(
        production,
        "step_event_state.npy",
    )
    step_case_indices = np.asarray(
        file191.load_npy(
            production,
            "step_case_indices.npy",
        ),
        dtype=np.int64,
    )

    event_mapping = file191.build_event_partition_mapping(
        step_case_indices
    )

    global_time_norm_np = file191.normalize_time(
        global_time
    )
    event_time_norm_np = file191.normalize_time(
        event_time
    )

    global_time_norm_t = torch.from_numpy(
        np.asarray(global_time_norm_np, dtype=np.float32)
    ).to(device)
    event_time_norm_t = torch.from_numpy(
        np.asarray(event_time_norm_np, dtype=np.float32)
    ).to(device)

    base_checkpoint = torch.load(
        require_file(base_checkpoint_path),
        map_location="cpu",
        weights_only=False,
    )
    control_checkpoint = torch.load(
        require_file(control_checkpoint_path),
        map_location="cpu",
        weights_only=False,
    )

    normalization = base_checkpoint["normalization"]

    rho_mean = float(normalization["rho_mean"])
    rho_std = float(normalization["rho_std"])
    state_mean = np.asarray(
        normalization["state_mean"],
        dtype=np.float64,
    )
    state_std = np.asarray(
        normalization["state_std"],
        dtype=np.float64,
    )

    state_mean_t = torch.as_tensor(
        state_mean,
        dtype=torch.float32,
        device=device,
    ).view(1, 1, -1)

    state_std_t = torch.as_tensor(
        state_std,
        dtype=torch.float32,
        device=device,
    ).view(1, 1, -1)

    control_model = file191.ModelB().to(device)
    control_model.load_state_dict(
        control_checkpoint["model_state_dict"]
    )
    control_model.eval()
    for parameter in control_model.parameters():
        parameter.requires_grad_(False)

    control_validation_mse = float(
        control_checkpoint["best_validation_mse"]
    )

    print()
    print("MATCHED CONTROL")
    print("-" * 78)
    print(
        f"Control epoch   : {control_checkpoint.get('epoch')}"
    )
    print(
        f"Control Val MSE : {control_validation_mse:.10e}"
    )

    beta = np.asarray(
        file70.BETA,
        dtype=np.float64,
    )
    lambdas = np.asarray(
        file70.LAMBDA,
        dtype=np.float64,
    )
    generation_time = float(
        file70.GENERATION_TIME
    )
    fuel_coeff = np.asarray(
        file70.FUEL_COEFF,
        dtype=np.float64,
    )
    block_coeff = np.asarray(
        file70.BLOCK_COEFF,
        dtype=np.float64,
    )
    fuel_reference = float(file74.T_FUEL_REF)
    block_reference = float(file74.T_BLOCK_REF)

    beta_t = torch.as_tensor(
        beta,
        dtype=torch.float32,
        device=device,
    )
    lambdas_t = torch.as_tensor(
        lambdas,
        dtype=torch.float32,
        device=device,
    )
    fuel_coeff_t = torch.as_tensor(
        fuel_coeff,
        dtype=torch.float32,
        device=device,
    )
    block_coeff_t = torch.as_tensor(
        block_coeff,
        dtype=torch.float32,
        device=device,
    )

    kinetics_scales_t = torch.as_tensor(
        kinetics_scales,
        dtype=torch.float32,
        device=device,
    ).view(1, 1, 7)

    thermal_scales_t = torch.as_tensor(
        thermal_scales,
        dtype=torch.float32,
        device=device,
    ).view(1, 1, 3)

    thermal_model = file74.MasterCoupledReferenceModel()

    candidate_results = []

    for candidate in candidates:
        fraction = candidate["fraction"]
        physics_weight = candidate["lambda"]

        run = run_candidate(
            fraction=fraction,
            physics_weight=physics_weight,
            file191=file191,
            file196=file196,
            file204=file204,
            file208=file208,
            file74=file74,
            file206=file206,
            thermal_model=thermal_model,
            base_checkpoint=base_checkpoint,
            normalization=normalization,
            global_rho=global_rho,
            global_state=global_state,
            event_rho=event_rho,
            event_state=event_state,
            event_mapping=event_mapping,
            global_time=global_time,
            event_time=event_time,
            global_time_norm_t=global_time_norm_t,
            event_time_norm_t=event_time_norm_t,
            rho_mean=rho_mean,
            rho_std=rho_std,
            state_mean=state_mean,
            state_std=state_std,
            state_mean_t=state_mean_t,
            state_std_t=state_std_t,
            kinetics_scales=kinetics_scales,
            thermal_scales=thermal_scales,
            kinetics_scales_t=kinetics_scales_t,
            thermal_scales_t=thermal_scales_t,
            beta_t=beta_t,
            lambdas_t=lambdas_t,
            generation_time=generation_time,
            fuel_coeff_t=fuel_coeff_t,
            block_coeff_t=block_coeff_t,
            fuel_reference=fuel_reference,
            block_reference=block_reference,
            device=device,
            output_dir=output_dir,
        )

        model = run["model"]

        print()
        print("PAIRED VALIDATION FULL-PHYSICS AUDIT")
        print("-" * 78)

        audit_records = []

        for replicate in range(AUDIT_REPLICATES):
            record = paired_validation_replicate(
                control_model=control_model,
                candidate_model=model,
                seed=AUDIT_SEED_BASE + replicate,
                file191=file191,
                file196=file196,
                file204=file204,
                file208=file208,
                file74=file74,
                file206=file206,
                thermal_model=thermal_model,
                global_rho=global_rho,
                event_rho=event_rho,
                event_mapping=event_mapping,
                global_time=global_time,
                event_time=event_time,
                global_time_norm=global_time_norm_np,
                event_time_norm=event_time_norm_np,
                rho_mean=rho_mean,
                rho_std=rho_std,
                state_mean_t=state_mean_t,
                state_std_t=state_std_t,
                kinetics_scales_t=kinetics_scales_t,
                thermal_scales_t=thermal_scales_t,
                beta_t=beta_t,
                lambdas_t=lambdas_t,
                generation_time=generation_time,
                fuel_coeff_t=fuel_coeff_t,
                block_coeff_t=block_coeff_t,
                fuel_reference=fuel_reference,
                block_reference=block_reference,
                device=device,
            )

            audit_records.append(record)

            print(
                f"Rep {replicate + 1:02d} | "
                f"Full={record['full']['combined_improvement_percent']:+.3f}% | "
                f"K={record['kinetics']['combined_improvement_percent']:+.3f}% | "
                f"T={record['thermal']['combined_improvement_percent']:+.3f}%"
            )

        full_stability = summarize_family_stability(
            audit_records,
            "full",
        )
        kinetics_stability = summarize_family_stability(
            audit_records,
            "kinetics",
        )
        thermal_stability = summarize_family_stability(
            audit_records,
            "thermal",
        )

        validation_mse = float(
            run["best_validation_mse"]
        )

        accuracy_improvement = percent_improvement(
            control_validation_mse,
            validation_mse,
        )

        accuracy_pass = bool(
            validation_mse
            < control_validation_mse
            - file191.MIN_VALIDATION_IMPROVEMENT
        )

        residual_pass = bool(
            full_stability["stable_improvement"]
        )

        joint_pass = bool(
            accuracy_pass and residual_pass
        )

        result = {
            "fraction": fraction,
            "lambda": physics_weight,
            "best_epoch": run["best_epoch"],
            "validation_mse": validation_mse,
            "validation_rmse": math.sqrt(validation_mse),
            "accuracy_improvement_vs_control_percent": (
                accuracy_improvement
            ),
            "accuracy_pass": accuracy_pass,
            "full_residual_stability": full_stability,
            "kinetics_residual_stability": kinetics_stability,
            "thermal_residual_stability": thermal_stability,
            "residual_pass": residual_pass,
            "joint_pass": joint_pass,
            "checkpoint": str(run["checkpoint_path"]),
            "history": str(run["history_path"]),
        }

        candidate_results.append(result)

        print()
        print("CANDIDATE SUMMARY")
        print("-" * 78)
        print(f"Best epoch          : {result['best_epoch']}")
        print(f"Validation MSE      : {validation_mse:.10e}")
        print(
            f"Accuracy vs control : {accuracy_improvement:+.4f}%"
        )
        print(
            "Full residual change: "
            f"{full_stability['mean_improvement_percent']:+.4f}% "
            f"({full_stability['positive_replicates']}/{AUDIT_REPLICATES})"
        )
        print(
            "Kinetics change     : "
            f"{kinetics_stability['mean_improvement_percent']:+.4f}% "
            f"({kinetics_stability['positive_replicates']}/{AUDIT_REPLICATES})"
        )
        print(
            "Thermal change      : "
            f"{thermal_stability['mean_improvement_percent']:+.4f}% "
            f"({thermal_stability['positive_replicates']}/{AUDIT_REPLICATES})"
        )
        print(f"Accuracy pass       : {accuracy_pass}")
        print(f"Full residual pass  : {residual_pass}")
        print(f"JOINT PASS          : {joint_pass}")

        del model
        del run
        gc.collect()
        if device.type == "cuda":
            torch.cuda.empty_cache()

    joint_candidates = [
        row
        for row in candidate_results
        if row["joint_pass"]
    ]

    if joint_candidates:
        joint_candidates = sorted(
            joint_candidates,
            key=lambda row: (
                row["validation_mse"],
                -row[
                    "full_residual_stability"
                ]["mean_improvement_percent"],
            ),
        )
        selected = joint_candidates[0]
        selection_status = (
            "FULL_PHYSICS_PINO_CANDIDATE_FROZEN"
        )
    else:
        selected = None
        selection_status = (
            "NO_FULL_PHYSICS_JOINT_DOMINANCE"
        )

    print()
    print("=" * 78)
    print("VALIDATION-ONLY FULL-PINO DECISION")
    print("=" * 78)
    print("Required:")
    print(
        "1. lower validation MSE than matched data-only control"
    )
    print(
        "2. stable family-balanced full-physics residual improvement"
    )
    print()
    print(f"Decision : {selection_status}")

    if selected is not None:
        print()
        print(
            f"Selected fraction : {selected['fraction']:.3f}"
        )
        print(
            f"Selected lambda   : {selected['lambda']:.10e}"
        )
        print(
            f"Best epoch        : {selected['best_epoch']}"
        )
        print(
            f"Validation MSE    : {selected['validation_mse']:.10e}"
        )
        print(
            "Full residual improvement : "
            f"{selected['full_residual_stability']['mean_improvement_percent']:+.4f}%"
        )
        print(
            "Kinetics residual change  : "
            f"{selected['kinetics_residual_stability']['mean_improvement_percent']:+.4f}%"
        )
        print(
            "Thermal residual change   : "
            f"{selected['thermal_residual_stability']['mean_improvement_percent']:+.4f}%"
        )

    payload = {
        "script": "210_step7_full_physics_weight_gate.py",
        "status": "COMPLETE",
        "experiment": (
            "Model-B plus family-balanced kinetics and thermal residuals"
        ),
        "training_partition": "TRAIN",
        "selection_partition": "VALIDATION",
        "id_ood_stress_accessed": False,
        "production_v1_modified": False,
        "initialization": "File-191 model_b_best.pt for every candidate",
        "learning_rate": FROZEN_LEARNING_RATE,
        "continuation_epochs": CONTINUATION_EPOCHS,
        "matched_control": {
            "checkpoint": str(control_checkpoint_path),
            "validation_mse": control_validation_mse,
            "learning_rate": FROZEN_LEARNING_RATE,
        },
        "physics_contract": {
            "kinetics_equations": 7,
            "thermal_equations": 3,
            "kinetics_family_weight": KINETICS_FAMILY_WEIGHT,
            "thermal_family_weight": THERMAL_FAMILY_WEIGHT,
            "full_physics_loss": (
                "0.5 * kinetics_family_loss + 0.5 * thermal_family_loss"
            ),
            "kinetics_normalization": (
                "File-198 beta_eff/Lambda and beta_i/Lambda scales"
            ),
            "thermal_normalization": (
                "File-207 TRAIN pooled equation-balance RMS scales"
            ),
            "equal_scale_lambda": equal_lambda,
            "candidate_fractions": CANDIDATE_FRACTIONS,
            "candidate_lambdas": [
                row["lambda"]
                for row in candidates
            ],
            "separate_reactivity_residual": False,
            "separate_brayton_residual": False,
        },
        "residual_stability_contract": {
            "replicates": AUDIT_REPLICATES,
            "batches_per_replicate": AUDIT_BATCHES_PER_REPLICATE,
            "probe_batch_size": AUDIT_BATCH_SIZE,
            "stable_positive_fraction": STABLE_POSITIVE_FRACTION,
            "paired_samples": True,
            "partition": "VALIDATION",
            "selection_residual": (
                "family-balanced full-physics residual"
            ),
            "family_residuals_reported_separately": True,
        },
        "candidates": candidate_results,
        "selection_status": selection_status,
        "selected_candidate": selected,
    }

    output_json.write_text(
        json.dumps(
            serializable(payload),
            indent=2,
            allow_nan=False,
        ),
        encoding="utf-8",
    )

    report = [
        "=" * 78,
        "STEP 7 FULL-PHYSICS PINO WEIGHT GATE",
        "=" * 78,
        "",
        f"Learning rate       : {FROZEN_LEARNING_RATE:.10e}",
        f"Control MSE         : {control_validation_mse:.10e}",
        f"Equal-scale lambda  : {equal_lambda:.10e}",
        "Family weights      : 0.5 kinetics / 0.5 thermal",
        "",
        "CANDIDATES",
    ]

    for row in candidate_results:
        report.append(
            f"fraction={row['fraction']:.3f} "
            f"lambda={row['lambda']:.10e} "
            f"epoch={row['best_epoch']} "
            f"valMSE={row['validation_mse']:.10e} "
            f"accuracyVsControl="
            f"{row['accuracy_improvement_vs_control_percent']:+.4f}% "
            f"fullResidual="
            f"{row['full_residual_stability']['mean_improvement_percent']:+.4f}% "
            f"K="
            f"{row['kinetics_residual_stability']['mean_improvement_percent']:+.4f}% "
            f"T="
            f"{row['thermal_residual_stability']['mean_improvement_percent']:+.4f}% "
            f"positiveFull="
            f"{row['full_residual_stability']['positive_replicates']}"
            f"/{AUDIT_REPLICATES} "
            f"jointPass={row['joint_pass']}"
        )

    report.extend([
        "",
        f"Decision: {selection_status}",
        "",
        "TRAIN updates            : YES",
        "VALIDATION selection     : YES",
        "ID/OOD/STRESS accessed  : NO",
        "Production-V1 modified  : NO",
        "",
        "STATUS: COMPLETE",
    ])

    output_txt.write_text(
        "\n".join(report) + "\n",
        encoding="utf-8",
    )

    print()
    print("OUTPUT FILES")
    print("-" * 78)
    print(output_json)
    print(output_txt)
    print()
    print("ID/OOD/STRESS accessed : NO")
    print("Production-V1 modified : NO")
    print()
    print("=" * 78)
    print("STATUS: FULL-PHYSICS PINO WEIGHT GATE COMPLETE")
    print("=" * 78)


if __name__ == "__main__":
    main()
