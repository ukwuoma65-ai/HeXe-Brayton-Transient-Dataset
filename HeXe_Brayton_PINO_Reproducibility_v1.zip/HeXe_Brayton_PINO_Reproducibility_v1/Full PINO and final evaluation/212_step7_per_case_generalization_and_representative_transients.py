#!/usr/bin/env python3
"""
212_step7_per_case_generalization_and_representative_transients.py

STEP 7 - PER-CASE GENERALIZATION AND REPRESENTATIVE TRANSIENT ANALYSIS

Purpose
-------
Create publication-ready, post-selection diagnostics for the already frozen
File-210 full-PINO model. This file does not train, tune, select, or alter any
model. It characterizes where the frozen PINO improves or degrades relative to
the matched data-only continuation and prepares deterministic representative
transients without selecting examples by model performance.

Scientific rules
----------------
- NO training.
- NO checkpoint/model selection.
- NO hyperparameter tuning.
- Production-V1 is NOT modified.
- ID/OOD/STRESS are used only for post-selection analysis.
- Representative cases are selected from the INPUT reactivity histories,
  independent of prediction error, using deterministic medoid selection.
- Model-error values are never used to choose representative trajectories.
- Global and event-local errors are reported separately.

Primary outputs
---------------
- 212_per_case_global_metrics.csv
- 212_per_case_event_metrics.csv
- 212_state_error_ratio.csv
- 212_representative_cases.json
- 212_representative_trajectories.npz
- 212_error_vs_amplitude.png / .pdf
- 212_state_error_ratio_global.png / .pdf
- 212_state_error_ratio_event.png / .pdf
- representative global/event trajectory figures
- 212_per_case_generalization_report.json / .txt
"""

from __future__ import annotations

import csv
import importlib.util
import json
import math
import sys
from pathlib import Path

import numpy as np
import torch

try:
    import matplotlib.pyplot as plt
except Exception as exc:
    raise RuntimeError(
        "matplotlib is required for File 212 publication figures."
    ) from exc


# =====================================================================
# FROZEN POST-SELECTION CONTRACT
# =====================================================================

SEED = 20262120

EVALUATION_PARTITIONS = [
    "ID_TEST",
    "OOD_NEG_TEST",
    "OOD_POS_TEST",
    "STRESS_TEST",
]

MODEL_NAMES = [
    "MATCHED_CONTROL",
    "FULL_PINO",
]

BATCH_SIZE = 32
EPS = 1.0e-30


# =====================================================================
# GENERAL UTILITIES
# =====================================================================


def find_root() -> Path:
    current = Path.cwd().resolve()
    for path in [current, *current.parents]:
        if (path / "step6_dataset" / "production_v1").is_dir():
            return path
    raise FileNotFoundError("Could not locate He-Xe PINO project root.")


def require_file(path: Path) -> Path:
    if not path.exists():
        raise FileNotFoundError(path)
    return path


def load_module(name: str, path: Path):
    path = require_file(path)
    spec = importlib.util.spec_from_file_location(name, str(path))
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not import:\n{path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def load_model(file191, checkpoint_path: Path, device):
    checkpoint = torch.load(
        require_file(checkpoint_path),
        map_location="cpu",
        weights_only=False,
    )
    model = file191.ModelB().to(device)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    return model, checkpoint


def normalization_match(reference, candidate) -> bool:
    required = ["rho_mean", "rho_std", "state_mean", "state_std"]
    if candidate is None or not all(k in candidate for k in required):
        return False
    return bool(
        math.isclose(
            float(reference["rho_mean"]),
            float(candidate["rho_mean"]),
            rel_tol=1.0e-12,
            abs_tol=1.0e-15,
        )
        and math.isclose(
            float(reference["rho_std"]),
            float(candidate["rho_std"]),
            rel_tol=1.0e-12,
            abs_tol=1.0e-15,
        )
        and np.allclose(
            np.asarray(reference["state_mean"], dtype=np.float64),
            np.asarray(candidate["state_mean"], dtype=np.float64),
            rtol=1.0e-12,
            atol=1.0e-12,
        )
        and np.allclose(
            np.asarray(reference["state_std"], dtype=np.float64),
            np.asarray(candidate["state_std"], dtype=np.float64),
            rtol=1.0e-12,
            atol=1.0e-12,
        )
    )


def percent_improvement(reference, candidate):
    if abs(float(reference)) <= EPS:
        return float("nan")
    return 100.0 * (float(reference) - float(candidate)) / float(reference)


def serializable(value):
    if isinstance(value, dict):
        return {k: serializable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [serializable(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.floating):
        return float(value)
    if isinstance(value, np.integer):
        return int(value)
    return value


def sanitize(text: str) -> str:
    return (
        str(text)
        .replace(" ", "_")
        .replace("/", "_")
        .replace("+", "pos")
        .replace("-", "neg")
        .lower()
    )


# =====================================================================
# INPUT-DISTURBANCE CHARACTERIZATION
# =====================================================================


def signed_peak_amplitude(rho_history):
    rho = np.asarray(rho_history, dtype=np.float64)
    index = int(np.argmax(np.abs(rho)))
    return float(rho[index])


def approximate_onset_time(time_array, rho_history):
    time_array = np.asarray(time_array, dtype=np.float64)
    rho = np.asarray(rho_history, dtype=np.float64)
    threshold = max(1.0e-14, 1.0e-8 * float(np.max(np.abs(rho))))
    active = np.flatnonzero(np.abs(rho) > threshold)
    if len(active) == 0:
        return float("nan")
    return float(time_array[int(active[0])])


def waveform_family_for_case(case_index, step_case_set):
    return "STEP_HOLD" if int(case_index) in step_case_set else "LINEAR_RAMP_HOLD"


def sign_label(amplitude):
    if amplitude > 0.0:
        return "POSITIVE"
    if amplitude < 0.0:
        return "NEGATIVE"
    return "ZERO"


# =====================================================================
# MODEL INFERENCE AND PER-CASE METRICS
# =====================================================================


def predict_representation(
    *,
    model,
    forward_method,
    branch_array,
    indices,
    time_norm_t,
    rho_mean,
    rho_std,
    state_mean,
    state_std,
    device,
):
    indices = np.asarray(indices, dtype=np.int64)
    predictions = []

    with torch.no_grad():
        for start in range(0, len(indices), BATCH_SIZE):
            selected = indices[start:start + BATCH_SIZE]

            raw_branch = np.asarray(
                branch_array[selected],
                dtype=np.float32,
            )

            branch_norm = (
                raw_branch - np.float32(rho_mean)
            ) / np.float32(rho_std)

            branch_t = torch.as_tensor(
                branch_norm,
                dtype=torch.float32,
                device=device,
            )

            query = (
                time_norm_t
                .view(1, -1, 1)
                .expand(len(selected), -1, -1)
            )

            pred_norm = (
                forward_method(branch_t, query)
                .detach()
                .cpu()
                .numpy()
                .astype(np.float64)
            )

            pred_phys = (
                pred_norm
                * np.asarray(state_std, dtype=np.float64)
                + np.asarray(state_mean, dtype=np.float64)
            )

            predictions.append(pred_phys)

    return np.concatenate(predictions, axis=0)


def per_case_metrics(target, prediction, state_mean, state_std):
    target = np.asarray(target, dtype=np.float64)
    prediction = np.asarray(prediction, dtype=np.float64)
    state_mean = np.asarray(state_mean, dtype=np.float64)
    state_std = np.asarray(state_std, dtype=np.float64)

    target_norm = (target - state_mean) / state_std
    pred_norm = (prediction - state_mean) / state_std

    norm_error = pred_norm - target_norm
    phys_error = prediction - target

    normalized_state_mse = np.mean(norm_error ** 2, axis=1)
    normalized_state_rmse = np.sqrt(normalized_state_mse)
    normalized_mse = np.mean(normalized_state_mse, axis=1)
    normalized_rmse = np.sqrt(normalized_mse)

    physical_state_rmse = np.sqrt(
        np.mean(phys_error ** 2, axis=1)
    )
    physical_state_mae = np.mean(
        np.abs(phys_error),
        axis=1,
    )
    physical_state_max_abs = np.max(
        np.abs(phys_error),
        axis=1,
    )

    return {
        "normalized_mse": normalized_mse,
        "normalized_rmse": normalized_rmse,
        "normalized_state_rmse": normalized_state_rmse,
        "physical_state_rmse": physical_state_rmse,
        "physical_state_mae": physical_state_mae,
        "physical_state_max_abs_error": physical_state_max_abs,
    }


# =====================================================================
# REPRESENTATIVE CASE SELECTION
# =====================================================================


def medoid_case(case_indices, rho_array):
    """
    Deterministic input-space medoid.

    Representative selection depends only on the prescribed external-reactivity
    histories. Prediction errors are deliberately not used.
    """
    case_indices = np.asarray(case_indices, dtype=np.int64)
    if len(case_indices) == 0:
        return None
    if len(case_indices) == 1:
        return int(case_indices[0])

    histories = np.asarray(
        rho_array[case_indices],
        dtype=np.float64,
    )

    # True medoid under squared Euclidean distance in the prescribed
    # reactivity-history space. Amplitude, onset timing, and ramp/hold
    # shape therefore remain part of the representative-case definition.
    squared_norm = np.sum(histories ** 2, axis=1)
    gram = histories @ histories.T
    distances = (
        squared_norm[:, None]
        + squared_norm[None, :]
        - 2.0 * gram
    )
    distances = np.maximum(distances, 0.0)
    total_distance = np.sum(distances, axis=1)

    order = np.lexsort((case_indices, total_distance))
    return int(case_indices[int(order[0])])


def select_representatives(
    *,
    file191,
    global_rho,
    step_case_set,
):
    selected = []

    for partition in EVALUATION_PARTITIONS:
        start, stop = file191.PARTITIONS[partition]
        partition_cases = np.arange(start, stop, dtype=np.int64)

        for waveform in ["STEP_HOLD", "LINEAR_RAMP_HOLD"]:
            waveform_cases = np.asarray(
                [
                    case
                    for case in partition_cases
                    if waveform_family_for_case(case, step_case_set) == waveform
                ],
                dtype=np.int64,
            )

            for sign in ["NEGATIVE", "POSITIVE"]:
                signed_cases = []
                for case in waveform_cases:
                    amplitude = signed_peak_amplitude(global_rho[case])
                    if sign_label(amplitude) == sign:
                        signed_cases.append(int(case))

                signed_cases = np.asarray(signed_cases, dtype=np.int64)

                case = medoid_case(
                    signed_cases,
                    global_rho,
                )

                if case is not None:
                    selected.append({
                        "partition": partition,
                        "waveform": waveform,
                        "sign": sign,
                        "global_case_index": int(case),
                        "selection_rule": (
                            "input-space medoid within partition/waveform/sign subgroup; "
                            "prediction errors not used"
                        ),
                    })

    return selected


# =====================================================================
# CSV WRITERS
# =====================================================================


def write_rows_csv(path, rows):
    if not rows:
        return
    fieldnames = list(rows[0].keys())
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


# =====================================================================
# PLOTTING
# =====================================================================


def save_figure(fig, png_path, pdf_path):
    fig.savefig(png_path, dpi=400, bbox_inches="tight")
    fig.savefig(pdf_path, bbox_inches="tight")
    plt.close(fig)


def plot_error_vs_amplitude(rows, output_dir):
    fig, ax = plt.subplots(figsize=(8.4, 5.6))

    markers = {
        "STEP_HOLD": "o",
        "LINEAR_RAMP_HOLD": "^",
    }

    partitions = EVALUATION_PARTITIONS

    for partition in partitions:
        for waveform in markers:
            subset = [
                row for row in rows
                if row["partition"] == partition
                and row["waveform"] == waveform
            ]
            if not subset:
                continue

            x = np.asarray(
                [row["amplitude_cents"] for row in subset],
                dtype=np.float64,
            )
            y = np.asarray(
                [row["pino_to_control_mse_ratio"] for row in subset],
                dtype=np.float64,
            )

            ax.scatter(
                x,
                y,
                s=24,
                alpha=0.65,
                marker=markers[waveform],
                label=f"{partition} | {waveform}",
            )

    ax.axhline(1.0, linewidth=1.2, linestyle="--")
    ax.set_yscale("log")
    ax.set_xlabel("External-reactivity amplitude (cents)")
    ax.set_ylabel("Per-case global MSE ratio, PINO / matched control")
    ax.set_title("Frozen PINO predictive error versus disturbance amplitude")
    ax.grid(True, which="both", alpha=0.2)
    ax.legend(fontsize=7, ncol=2, frameon=False)

    save_figure(
        fig,
        output_dir / "212_error_vs_amplitude.png",
        output_dir / "212_error_vs_amplitude.pdf",
    )


def plot_state_ratio_heatmap(rows, representation, state_names, output_dir):
    matrix = np.full(
        (len(EVALUATION_PARTITIONS), len(state_names)),
        np.nan,
        dtype=np.float64,
    )

    for i, partition in enumerate(EVALUATION_PARTITIONS):
        for j, state_name in enumerate(state_names):
            matches = [
                row for row in rows
                if row["partition"] == partition
                and row["representation"] == representation
                and row["state_name"] == state_name
            ]
            if matches:
                matrix[i, j] = float(matches[0]["rmse_ratio_pino_to_control"])

    fig, ax = plt.subplots(figsize=(10.2, 4.8))
    shown = np.log10(np.maximum(matrix, EPS))
    image = ax.imshow(
        shown,
        aspect="auto",
        interpolation="nearest",
    )

    ax.set_xticks(np.arange(len(state_names)))
    ax.set_xticklabels(state_names, rotation=45, ha="right")
    ax.set_yticks(np.arange(len(EVALUATION_PARTITIONS)))
    ax.set_yticklabels(EVALUATION_PARTITIONS)
    ax.set_title(
        f"State-wise PINO/control RMSE ratio ({representation})"
    )

    for i in range(matrix.shape[0]):
        for j in range(matrix.shape[1]):
            if np.isfinite(matrix[i, j]):
                ax.text(
                    j,
                    i,
                    f"{matrix[i, j]:.2f}",
                    ha="center",
                    va="center",
                    fontsize=7,
                )

    cbar = fig.colorbar(image, ax=ax)
    cbar.set_label("log10(PINO RMSE / control RMSE)")

    save_figure(
        fig,
        output_dir / f"212_state_error_ratio_{representation}.png",
        output_dir / f"212_state_error_ratio_{representation}.pdf",
    )


def plot_representative_global(
    *,
    record,
    global_time,
    rho,
    target,
    control,
    pino,
    state_names,
    output_dir,
):
    case = record["global_case_index"]
    stem = (
        f"212_rep_global_{sanitize(record['partition'])}_"
        f"{sanitize(record['waveform'])}_{sanitize(record['sign'])}_case{case}"
    )

    fig, axes = plt.subplots(
        4,
        1,
        figsize=(8.4, 10.0),
        sharex=True,
    )

    axes[0].plot(global_time, rho, label="External reactivity")
    axes[0].set_ylabel("rho_ext")
    axes[0].legend(frameon=False, fontsize=8)

    axes[1].plot(global_time, target[:, 0], label="Reference")
    axes[1].plot(global_time, control[:, 0], linestyle="--", label="Matched control")
    axes[1].plot(global_time, pino[:, 0], linestyle=":", label="Full PINO")
    axes[1].set_ylabel(state_names[0])
    axes[1].legend(frameon=False, fontsize=8, ncol=3)

    for index in [7, 8, 9]:
        axes[2].plot(global_time, target[:, index], label=f"Ref {state_names[index]}")
        axes[2].plot(
            global_time,
            pino[:, index],
            linestyle="--",
            label=f"PINO {state_names[index]}",
        )
    axes[2].set_ylabel("Temperature")
    axes[2].legend(frameon=False, fontsize=7, ncol=2)

    control_abs = np.mean(np.abs(control - target), axis=1)
    pino_abs = np.mean(np.abs(pino - target), axis=1)
    axes[3].plot(global_time, control_abs, label="Matched control")
    axes[3].plot(global_time, pino_abs, linestyle="--", label="Full PINO")
    axes[3].set_ylabel("Mean abs. state error")
    axes[3].set_xlabel("Time (s)")
    axes[3].legend(frameon=False, fontsize=8)

    fig.suptitle(
        f"{record['partition']} | {record['waveform']} | {record['sign']} | case {case}"
    )

    for ax in axes:
        ax.grid(True, alpha=0.2)

    save_figure(
        fig,
        output_dir / f"{stem}.png",
        output_dir / f"{stem}.pdf",
    )

    return stem


def plot_representative_event(
    *,
    record,
    event_position,
    event_time,
    rho,
    target,
    control,
    pino,
    state_names,
    output_dir,
):
    case = record["global_case_index"]
    stem = (
        f"212_rep_event_{sanitize(record['partition'])}_"
        f"{sanitize(record['sign'])}_case{case}"
    )

    fig, axes = plt.subplots(
        3,
        1,
        figsize=(8.4, 8.0),
        sharex=True,
    )

    axes[0].plot(event_time, rho, label="External reactivity")
    axes[0].set_ylabel("rho_ext")
    axes[0].legend(frameon=False, fontsize=8)

    axes[1].plot(event_time, target[:, 0], label="Reference")
    axes[1].plot(event_time, control[:, 0], linestyle="--", label="Matched control")
    axes[1].plot(event_time, pino[:, 0], linestyle=":", label="Full PINO")
    axes[1].set_ylabel(state_names[0])
    axes[1].legend(frameon=False, fontsize=8, ncol=3)

    control_abs = np.mean(np.abs(control - target), axis=1)
    pino_abs = np.mean(np.abs(pino - target), axis=1)
    axes[2].plot(event_time, control_abs, label="Matched control")
    axes[2].plot(event_time, pino_abs, linestyle="--", label="Full PINO")
    axes[2].set_ylabel("Mean abs. state error")
    axes[2].set_xlabel("Time after STEP onset (s)")
    axes[2].legend(frameon=False, fontsize=8)

    axes[2].set_xscale("symlog", linthresh=1.0e-5)

    fig.suptitle(
        f"Event-local {record['partition']} | {record['sign']} | case {case}"
    )

    for ax in axes:
        ax.grid(True, alpha=0.2)

    save_figure(
        fig,
        output_dir / f"{stem}.png",
        output_dir / f"{stem}.pdf",
    )

    return stem


# =====================================================================
# MAIN
# =====================================================================


def main():
    np.random.seed(SEED)
    torch.manual_seed(SEED)

    root = find_root()
    production = root / "step6_dataset" / "production_v1"

    file191 = load_module(
        "file191_212",
        root / "191_step7_model_b_training.py",
    )

    file70 = load_module(
        "file70_212",
        root / "70_reference_reactor_kinetics.py",
    )

    file210_json_path = (
        root
        / "step7_pino"
        / "physics_informed"
        / "full_physics"
        / "210_full_physics_weight_gate.json"
    )

    base_checkpoint_path = (
        root
        / "step7_pino"
        / "model_b_training"
        / "model_b_best.pt"
    )

    control_checkpoint_path = (
        root
        / "step7_pino"
        / "physics_informed"
        / "power_lr_gate"
        / "lr_0p5_data_control_best.pt"
    )

    output_dir = (
        root
        / "step7_pino"
        / "physics_informed"
        / "per_case_analysis"
    )
    output_dir.mkdir(parents=True, exist_ok=True)

    file210 = json.loads(
        require_file(file210_json_path).read_text(encoding="utf-8")
    )

    if file210.get("selection_status") != "FULL_PHYSICS_PINO_CANDIDATE_FROZEN":
        raise RuntimeError("File 210 full-PINO candidate is not frozen.")

    selected = file210.get("selected_candidate")
    if selected is None:
        raise RuntimeError("File 210 selected candidate is missing.")

    pino_checkpoint_path = Path(selected["checkpoint"])
    if not pino_checkpoint_path.exists():
        tag = f"{float(selected['fraction']):.3f}".replace(".", "p")
        pino_checkpoint_path = (
            root
            / "step7_pino"
            / "physics_informed"
            / "full_physics"
            / f"full_physics_{tag}_best.pt"
        )
    pino_checkpoint_path = require_file(pino_checkpoint_path)

    print("=" * 78)
    print("STEP 7 PER-CASE GENERALIZATION AND REPRESENTATIVE TRANSIENT ANALYSIS")
    print("=" * 78)
    print(f"Project root : {root}")
    print("Training     : NO")
    print("Tuning       : NO")
    print("Selection    : NO")
    print("Dataset edit : NO")
    print()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device : {device}")
    if device.type == "cuda":
        print("GPU    : " + torch.cuda.get_device_name(0))
    print()

    # -----------------------------------------------------------------
    # DATA
    # -----------------------------------------------------------------

    global_time = np.asarray(
        file191.load_npy(production, "global_time_s.npy"),
        dtype=np.float64,
    )
    global_rho = file191.load_npy(
        production,
        "global_reactivity_delta_k_over_k.npy",
    )
    global_state = file191.load_npy(
        production,
        "global_state.npy",
    )

    event_time = np.asarray(
        file191.load_npy(production, "step_event_relative_time_s.npy"),
        dtype=np.float64,
    )
    event_rho = file191.load_npy(
        production,
        "step_event_reactivity_delta_k_over_k.npy",
    )
    event_state = file191.load_npy(
        production,
        "step_event_state.npy",
    )
    step_case_indices = np.asarray(
        file191.load_npy(production, "step_case_indices.npy"),
        dtype=np.int64,
    )
    state_names = [
        str(value)
        for value in np.asarray(
            file191.load_npy(production, "state_names.npy")
        ).tolist()
    ]

    event_mapping = file191.build_event_partition_mapping(step_case_indices)
    step_case_set = set(int(value) for value in step_case_indices.tolist())
    global_to_event = {
        int(global_case): int(event_pos)
        for event_pos, global_case in enumerate(step_case_indices.tolist())
    }

    global_time_norm_t = torch.as_tensor(
        file191.normalize_time(global_time),
        dtype=torch.float32,
        device=device,
    )
    event_time_norm_t = torch.as_tensor(
        file191.normalize_time(event_time),
        dtype=torch.float32,
        device=device,
    )

    # -----------------------------------------------------------------
    # MODELS AND NORMALIZATION
    # -----------------------------------------------------------------

    _, base_checkpoint = load_model(
        file191,
        base_checkpoint_path,
        device,
    )
    control_model, control_checkpoint = load_model(
        file191,
        control_checkpoint_path,
        device,
    )
    pino_model, pino_checkpoint = load_model(
        file191,
        pino_checkpoint_path,
        device,
    )

    normalization = base_checkpoint["normalization"]
    if not normalization_match(normalization, control_checkpoint.get("normalization")):
        raise RuntimeError("Matched-control normalization mismatch.")
    if not normalization_match(normalization, pino_checkpoint.get("normalization")):
        raise RuntimeError("Full-PINO normalization mismatch.")

    rho_mean = float(normalization["rho_mean"])
    rho_std = float(normalization["rho_std"])
    state_mean = np.asarray(normalization["state_mean"], dtype=np.float64)
    state_std = np.asarray(normalization["state_std"], dtype=np.float64)

    beta_eff = float(np.sum(np.asarray(file70.BETA, dtype=np.float64)))

    print("FROZEN MODEL AUDIT")
    print("-" * 78)
    print(f"PINO fraction : {float(selected['fraction']):.3f}")
    print(f"PINO lambda   : {float(selected['lambda']):.10e}")
    print(f"PINO epoch    : {pino_checkpoint.get('epoch')}")
    print("Normalization : PASS")
    print()

    # -----------------------------------------------------------------
    # PER-PARTITION INFERENCE
    # -----------------------------------------------------------------

    global_rows = []
    event_rows = []
    state_ratio_rows = []

    partition_cache = {}

    print("PER-CASE GENERALIZATION SUMMARY")
    print("-" * 78)

    for partition in EVALUATION_PARTITIONS:
        start, stop = file191.PARTITIONS[partition]
        global_indices = np.arange(start, stop, dtype=np.int64)
        event_positions = np.asarray(event_mapping[partition], dtype=np.int64)
        event_global_cases = step_case_indices[event_positions]

        target_global = np.asarray(global_state[global_indices], dtype=np.float64)
        target_event = np.asarray(event_state[event_positions], dtype=np.float64)

        control_global = predict_representation(
            model=control_model,
            forward_method=control_model.forward_global,
            branch_array=global_rho,
            indices=global_indices,
            time_norm_t=global_time_norm_t,
            rho_mean=rho_mean,
            rho_std=rho_std,
            state_mean=state_mean,
            state_std=state_std,
            device=device,
        )
        pino_global = predict_representation(
            model=pino_model,
            forward_method=pino_model.forward_global,
            branch_array=global_rho,
            indices=global_indices,
            time_norm_t=global_time_norm_t,
            rho_mean=rho_mean,
            rho_std=rho_std,
            state_mean=state_mean,
            state_std=state_std,
            device=device,
        )

        control_event = predict_representation(
            model=control_model,
            forward_method=control_model.forward_event,
            branch_array=event_rho,
            indices=event_positions,
            time_norm_t=event_time_norm_t,
            rho_mean=rho_mean,
            rho_std=rho_std,
            state_mean=state_mean,
            state_std=state_std,
            device=device,
        )
        pino_event = predict_representation(
            model=pino_model,
            forward_method=pino_model.forward_event,
            branch_array=event_rho,
            indices=event_positions,
            time_norm_t=event_time_norm_t,
            rho_mean=rho_mean,
            rho_std=rho_std,
            state_mean=state_mean,
            state_std=state_std,
            device=device,
        )

        metrics_control_global = per_case_metrics(
            target_global,
            control_global,
            state_mean,
            state_std,
        )
        metrics_pino_global = per_case_metrics(
            target_global,
            pino_global,
            state_mean,
            state_std,
        )
        metrics_control_event = per_case_metrics(
            target_event,
            control_event,
            state_mean,
            state_std,
        )
        metrics_pino_event = per_case_metrics(
            target_event,
            pino_event,
            state_mean,
            state_std,
        )

        partition_cache[partition] = {
            "global_indices": global_indices,
            "event_positions": event_positions,
            "event_global_cases": event_global_cases,
            "target_global": target_global,
            "control_global": control_global,
            "pino_global": pino_global,
            "target_event": target_event,
            "control_event": control_event,
            "pino_event": pino_event,
        }

        # Per-case global rows.
        for local_index, case in enumerate(global_indices):
            amplitude = signed_peak_amplitude(global_rho[case])
            control_mse = float(metrics_control_global["normalized_mse"][local_index])
            pino_mse = float(metrics_pino_global["normalized_mse"][local_index])

            global_rows.append({
                "partition": partition,
                "global_case_index": int(case),
                "waveform": waveform_family_for_case(case, step_case_set),
                "sign": sign_label(amplitude),
                "amplitude_delta_k_over_k": amplitude,
                "amplitude_pcm": amplitude * 1.0e5,
                "amplitude_cents": 100.0 * amplitude / beta_eff,
                "approx_onset_time_s": approximate_onset_time(global_time, global_rho[case]),
                "control_normalized_mse": control_mse,
                "pino_normalized_mse": pino_mse,
                "pino_to_control_mse_ratio": pino_mse / max(control_mse, EPS),
                "pino_improvement_percent": percent_improvement(control_mse, pino_mse),
                "pino_better": bool(pino_mse < control_mse),
            })

        # Per-case event rows.
        for local_index, event_pos in enumerate(event_positions):
            case = int(step_case_indices[event_pos])
            amplitude = signed_peak_amplitude(global_rho[case])
            control_mse = float(metrics_control_event["normalized_mse"][local_index])
            pino_mse = float(metrics_pino_event["normalized_mse"][local_index])

            event_rows.append({
                "partition": partition,
                "global_case_index": case,
                "event_position": int(event_pos),
                "waveform": "STEP_HOLD",
                "sign": sign_label(amplitude),
                "amplitude_delta_k_over_k": amplitude,
                "amplitude_pcm": amplitude * 1.0e5,
                "amplitude_cents": 100.0 * amplitude / beta_eff,
                "control_normalized_mse": control_mse,
                "pino_normalized_mse": pino_mse,
                "pino_to_control_mse_ratio": pino_mse / max(control_mse, EPS),
                "pino_improvement_percent": percent_improvement(control_mse, pino_mse),
                "pino_better": bool(pino_mse < control_mse),
            })

        # State-level aggregate RMSE ratios from the same complete partition.
        for representation, control_metrics, pino_metrics in [
            ("global", metrics_control_global, metrics_pino_global),
            ("event", metrics_control_event, metrics_pino_event),
        ]:
            control_state_rmse = np.sqrt(
                np.mean(
                    np.asarray(control_metrics["normalized_state_rmse"]) ** 2,
                    axis=0,
                )
            )
            pino_state_rmse = np.sqrt(
                np.mean(
                    np.asarray(pino_metrics["normalized_state_rmse"]) ** 2,
                    axis=0,
                )
            )

            for state_index, state_name in enumerate(state_names):
                c = float(control_state_rmse[state_index])
                p = float(pino_state_rmse[state_index])
                state_ratio_rows.append({
                    "partition": partition,
                    "representation": representation,
                    "state_index": state_index,
                    "state_name": state_name,
                    "control_normalized_rmse": c,
                    "pino_normalized_rmse": p,
                    "rmse_ratio_pino_to_control": p / max(c, EPS),
                    "pino_improvement_percent": percent_improvement(c, p),
                })

        partition_global_rows = [
            row for row in global_rows
            if row["partition"] == partition
        ]
        improvements = np.asarray(
            [row["pino_improvement_percent"] for row in partition_global_rows],
            dtype=np.float64,
        )
        better = np.asarray(
            [row["pino_better"] for row in partition_global_rows],
            dtype=bool,
        )

        print(
            f"{partition:<14} "
            f"cases={len(partition_global_rows):3d} | "
            f"PINO better={100.0*np.mean(better):6.2f}% | "
            f"median change={np.median(improvements):+8.3f}% | "
            f"q10={np.quantile(improvements,0.10):+8.3f}% | "
            f"q90={np.quantile(improvements,0.90):+8.3f}%"
        )

    print()

    # -----------------------------------------------------------------
    # REPRESENTATIVE INPUT-SPACE MEDOIDS
    # -----------------------------------------------------------------

    representatives = select_representatives(
        file191=file191,
        global_rho=global_rho,
        step_case_set=step_case_set,
    )

    print("REPRESENTATIVE-CASE SELECTION")
    print("-" * 78)
    print("Rule: input-space medoid within partition/waveform/sign subgroup")
    print("Prediction errors used for selection: NO")
    print(f"Representative cases selected: {len(representatives)}")

    # Attach descriptive input metadata and predictive metrics after selection.
    global_row_lookup = {
        int(row["global_case_index"]): row
        for row in global_rows
    }

    for record in representatives:
        case = int(record["global_case_index"])
        amplitude = signed_peak_amplitude(global_rho[case])
        record["amplitude_delta_k_over_k"] = amplitude
        record["amplitude_pcm"] = amplitude * 1.0e5
        record["amplitude_cents"] = 100.0 * amplitude / beta_eff
        record["approx_onset_time_s"] = approximate_onset_time(
            global_time,
            global_rho[case],
        )
        if case in global_row_lookup:
            row = global_row_lookup[case]
            record["control_global_normalized_mse"] = row["control_normalized_mse"]
            record["pino_global_normalized_mse"] = row["pino_normalized_mse"]
            record["pino_global_improvement_percent"] = row["pino_improvement_percent"]

    # -----------------------------------------------------------------
    # REPRESENTATIVE TRAJECTORY ARCHIVE + FIGURES
    # -----------------------------------------------------------------

    archive = {}
    figure_stems = []

    for record_index, record in enumerate(representatives):
        partition = record["partition"]
        case = int(record["global_case_index"])
        cache = partition_cache[partition]
        global_indices = cache["global_indices"]
        local = int(np.flatnonzero(global_indices == case)[0])

        target = cache["target_global"][local]
        control = cache["control_global"][local]
        pino = cache["pino_global"][local]
        rho = np.asarray(global_rho[case], dtype=np.float64)

        key = f"rep_{record_index:02d}_case_{case}"
        archive[f"{key}_global_time"] = global_time
        archive[f"{key}_global_rho"] = rho
        archive[f"{key}_global_reference"] = target
        archive[f"{key}_global_control"] = control
        archive[f"{key}_global_pino"] = pino

        stem = plot_representative_global(
            record=record,
            global_time=global_time,
            rho=rho,
            target=target,
            control=control,
            pino=pino,
            state_names=state_names,
            output_dir=output_dir,
        )
        figure_stems.append(stem)

        if record["waveform"] == "STEP_HOLD" and case in global_to_event:
            event_pos = global_to_event[case]
            event_positions = cache["event_positions"]
            event_local_matches = np.flatnonzero(event_positions == event_pos)
            if len(event_local_matches) == 1:
                event_local = int(event_local_matches[0])
                e_target = cache["target_event"][event_local]
                e_control = cache["control_event"][event_local]
                e_pino = cache["pino_event"][event_local]
                e_rho = np.asarray(event_rho[event_pos], dtype=np.float64)

                archive[f"{key}_event_time"] = event_time
                archive[f"{key}_event_rho"] = e_rho
                archive[f"{key}_event_reference"] = e_target
                archive[f"{key}_event_control"] = e_control
                archive[f"{key}_event_pino"] = e_pino

                event_stem = plot_representative_event(
                    record=record,
                    event_position=event_pos,
                    event_time=event_time,
                    rho=e_rho,
                    target=e_target,
                    control=e_control,
                    pino=e_pino,
                    state_names=state_names,
                    output_dir=output_dir,
                )
                figure_stems.append(event_stem)

    np.savez_compressed(
        output_dir / "212_representative_trajectories.npz",
        **archive,
    )

    # -----------------------------------------------------------------
    # PAPER-READY SUMMARY FIGURES
    # -----------------------------------------------------------------

    plot_error_vs_amplitude(
        global_rows,
        output_dir,
    )

    plot_state_ratio_heatmap(
        state_ratio_rows,
        "global",
        state_names,
        output_dir,
    )

    plot_state_ratio_heatmap(
        state_ratio_rows,
        "event",
        state_names,
        output_dir,
    )

    # -----------------------------------------------------------------
    # SUBGROUP SUMMARY
    # -----------------------------------------------------------------

    subgroup_summary = []

    for partition in EVALUATION_PARTITIONS:
        for waveform in ["STEP_HOLD", "LINEAR_RAMP_HOLD"]:
            for sign in ["NEGATIVE", "POSITIVE"]:
                subset = [
                    row for row in global_rows
                    if row["partition"] == partition
                    and row["waveform"] == waveform
                    and row["sign"] == sign
                ]
                if not subset:
                    continue

                changes = np.asarray(
                    [row["pino_improvement_percent"] for row in subset],
                    dtype=np.float64,
                )
                ratios = np.asarray(
                    [row["pino_to_control_mse_ratio"] for row in subset],
                    dtype=np.float64,
                )

                subgroup_summary.append({
                    "partition": partition,
                    "waveform": waveform,
                    "sign": sign,
                    "cases": len(subset),
                    "fraction_pino_better": float(np.mean(ratios < 1.0)),
                    "mean_improvement_percent": float(np.mean(changes)),
                    "median_improvement_percent": float(np.median(changes)),
                    "q10_improvement_percent": float(np.quantile(changes, 0.10)),
                    "q90_improvement_percent": float(np.quantile(changes, 0.90)),
                })

    # -----------------------------------------------------------------
    # SAVE TABLES AND REPORTS
    # -----------------------------------------------------------------

    global_csv = output_dir / "212_per_case_global_metrics.csv"
    event_csv = output_dir / "212_per_case_event_metrics.csv"
    state_csv = output_dir / "212_state_error_ratio.csv"
    subgroup_csv = output_dir / "212_subgroup_generalization_summary.csv"
    representative_json = output_dir / "212_representative_cases.json"
    output_json = output_dir / "212_per_case_generalization_report.json"
    output_txt = output_dir / "212_per_case_generalization_report.txt"

    write_rows_csv(global_csv, global_rows)
    write_rows_csv(event_csv, event_rows)
    write_rows_csv(state_csv, state_ratio_rows)
    write_rows_csv(subgroup_csv, subgroup_summary)

    representative_json.write_text(
        json.dumps(serializable(representatives), indent=2, allow_nan=False),
        encoding="utf-8",
    )

    partition_summary = {}
    for partition in EVALUATION_PARTITIONS:
        subset = [row for row in global_rows if row["partition"] == partition]
        changes = np.asarray(
            [row["pino_improvement_percent"] for row in subset],
            dtype=np.float64,
        )
        ratios = np.asarray(
            [row["pino_to_control_mse_ratio"] for row in subset],
            dtype=np.float64,
        )
        partition_summary[partition] = {
            "cases": len(subset),
            "fraction_pino_better": float(np.mean(ratios < 1.0)),
            "mean_improvement_percent": float(np.mean(changes)),
            "median_improvement_percent": float(np.median(changes)),
            "q10_improvement_percent": float(np.quantile(changes, 0.10)),
            "q90_improvement_percent": float(np.quantile(changes, 0.90)),
            "minimum_improvement_percent": float(np.min(changes)),
            "maximum_improvement_percent": float(np.max(changes)),
        }

    report_payload = {
        "script": "212_step7_per_case_generalization_and_representative_transients.py",
        "status": "PER_CASE_GENERALIZATION_AND_REPRESENTATIVE_ANALYSIS_COMPLETE",
        "training_performed": False,
        "tuning_performed": False,
        "checkpoint_selection_performed": False,
        "dataset_modified": False,
        "test_partitions_accessed_for_post_selection_analysis": EVALUATION_PARTITIONS,
        "frozen_model": {
            "fraction": float(selected["fraction"]),
            "lambda": float(selected["lambda"]),
            "checkpoint": str(pino_checkpoint_path),
        },
        "representative_selection": {
            "rule": (
                "input-space medoid within each partition/waveform/sign subgroup"
            ),
            "uses_model_errors": False,
            "number_selected": len(representatives),
        },
        "partition_summary": partition_summary,
        "subgroup_summary": subgroup_summary,
        "representative_cases": representatives,
        "state_error_ratio_rows": state_ratio_rows,
        "outputs": {
            "per_case_global_csv": str(global_csv),
            "per_case_event_csv": str(event_csv),
            "state_ratio_csv": str(state_csv),
            "subgroup_csv": str(subgroup_csv),
            "representative_json": str(representative_json),
            "representative_npz": str(
                output_dir / "212_representative_trajectories.npz"
            ),
            "error_vs_amplitude_figure": str(
                output_dir / "212_error_vs_amplitude.png"
            ),
            "global_state_heatmap": str(
                output_dir / "212_state_error_ratio_global.png"
            ),
            "event_state_heatmap": str(
                output_dir / "212_state_error_ratio_event.png"
            ),
            "representative_figure_stems": figure_stems,
        },
    }

    output_json.write_text(
        json.dumps(serializable(report_payload), indent=2, allow_nan=False),
        encoding="utf-8",
    )

    report_lines = [
        "=" * 78,
        "STEP 7 PER-CASE GENERALIZATION AND REPRESENTATIVE TRANSIENT REPORT",
        "=" * 78,
        "",
        "Frozen model altered                 : NO",
        "Training performed                   : NO",
        "Tuning performed                     : NO",
        "Post-test model selection performed  : NO",
        "Production-V1 modified               : NO",
        "",
        "Representative selection:",
        "  input-space medoid within partition/waveform/sign subgroup",
        "  model-error values used for selection: NO",
        "",
        "PER-PARTITION GLOBAL PER-CASE SUMMARY",
        "-" * 78,
    ]

    for partition in EVALUATION_PARTITIONS:
        summary = partition_summary[partition]
        report_lines.append(
            f"{partition:<14} "
            f"cases={summary['cases']:3d} | "
            f"better={100.0*summary['fraction_pino_better']:6.2f}% | "
            f"mean={summary['mean_improvement_percent']:+8.3f}% | "
            f"median={summary['median_improvement_percent']:+8.3f}% | "
            f"q10={summary['q10_improvement_percent']:+8.3f}% | "
            f"q90={summary['q90_improvement_percent']:+8.3f}%"
        )

    report_lines.extend([
        "",
        f"Representative cases selected : {len(representatives)}",
        "",
        f"Global per-case CSV : {global_csv}",
        f"Event per-case CSV  : {event_csv}",
        f"State-ratio CSV     : {state_csv}",
        f"Subgroup CSV        : {subgroup_csv}",
        f"Representative JSON : {representative_json}",
        f"Report JSON         : {output_json}",
        "",
        "STATUS: PER_CASE_GENERALIZATION_AND_REPRESENTATIVE_ANALYSIS_COMPLETE",
    ])

    output_txt.write_text(
        "\n".join(report_lines) + "\n",
        encoding="utf-8",
    )

    print()
    print("OUTPUTS")
    print("-" * 78)
    print(global_csv)
    print(event_csv)
    print(state_csv)
    print(subgroup_csv)
    print(representative_json)
    print(output_json)
    print(output_txt)
    print(output_dir / "212_error_vs_amplitude.png")
    print(output_dir / "212_state_error_ratio_global.png")
    print(output_dir / "212_state_error_ratio_event.png")
    print()
    print("=" * 78)
    print("STATUS: PER_CASE_GENERALIZATION_AND_REPRESENTATIVE_ANALYSIS_COMPLETE")
    print("=" * 78)


if __name__ == "__main__":
    main()
