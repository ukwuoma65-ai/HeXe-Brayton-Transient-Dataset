#!/usr/bin/env python3
"""
211_step7_frozen_full_pino_confirmatory_evaluation.py

STEP 7 - FROZEN FULL-PINO CONFIRMATORY EVALUATION

Purpose:
    Evaluate the already selected File-210 full-PINO checkpoint on the
    untouched ID, OOD-negative, OOD-positive, and stress partitions.

Rules:
    - NO training.
    - NO checkpoint selection.
    - NO hyperparameter tuning.
    - File-210 selected checkpoint is frozen before test access.
    - Production-V1 is not modified.
    - Test partitions are used only for confirmatory evaluation.
    - Predictive accuracy is compared against both the original File-191
      Model-B and the matched data-only continuation control.
    - The frozen thermal-only ablation is included when available.
    - Physics consistency is compared against the matched data-only control
      using the same family-balanced residual contract as File 210.
    - Physics residual audits use paired samples and the pre-existing
      12-replicate protocol; results are descriptive and cannot alter the
      selected model.
"""

from __future__ import annotations

import csv
import importlib.util
import json
import math
import sys
from pathlib import Path

import numpy as np
import torch


# =====================================================================
# FROZEN CONFIRMATORY CONTRACT
# =====================================================================

SEED = 20262110

EVALUATION_PARTITIONS = [
    "ID_TEST",
    "OOD_NEG_TEST",
    "OOD_POS_TEST",
    "STRESS_TEST",
]

AUDIT_REPLICATES = 12
AUDIT_BATCHES_PER_REPLICATE = 8
AUDIT_BATCH_SIZE = 4
AUDIT_SEED_BASE = 20262110
STABLE_POSITIVE_FRACTION = 0.80

KINETICS_FAMILY_WEIGHT = 0.5
THERMAL_FAMILY_WEIGHT = 0.5


# =====================================================================
# GENERAL UTILITIES
# =====================================================================

def find_root() -> Path:
    current = Path.cwd().resolve()
    for path in [current, *current.parents]:
        if (path / "step6_dataset" / "production_v1").is_dir():
            return path
    raise FileNotFoundError("Could not locate He-Xe PINO project root.")


def require_file(path: Path) -> Path:
    if not path.exists():
        raise FileNotFoundError(path)
    return path


def load_module(name: str, path: Path):
    path = require_file(path)
    spec = importlib.util.spec_from_file_location(name, str(path))
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not import:\n{path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def percent_improvement(reference, candidate):
    if reference == 0.0:
        return float("nan")
    return 100.0 * (reference - candidate) / reference


def serializable(value):
    if isinstance(value, dict):
        return {k: serializable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [serializable(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.floating):
        return float(value)
    if isinstance(value, np.integer):
        return int(value)
    return value


def normalization_match(reference, candidate):
    if candidate is None:
        return False

    required = [
        "rho_mean",
        "rho_std",
        "state_mean",
        "state_std",
    ]

    if not all(key in candidate for key in required):
        return False

    return bool(
        math.isclose(
            float(reference["rho_mean"]),
            float(candidate["rho_mean"]),
            rel_tol=1.0e-12,
            abs_tol=1.0e-15,
        )
        and math.isclose(
            float(reference["rho_std"]),
            float(candidate["rho_std"]),
            rel_tol=1.0e-12,
            abs_tol=1.0e-15,
        )
        and np.allclose(
            np.asarray(reference["state_mean"], dtype=np.float64),
            np.asarray(candidate["state_mean"], dtype=np.float64),
            rtol=1.0e-12,
            atol=1.0e-12,
        )
        and np.allclose(
            np.asarray(reference["state_std"], dtype=np.float64),
            np.asarray(candidate["state_std"], dtype=np.float64),
            rtol=1.0e-12,
            atol=1.0e-12,
        )
    )


def load_model(file191, checkpoint_path, device):
    checkpoint = torch.load(
        require_file(checkpoint_path),
        map_location="cpu",
        weights_only=False,
    )

    model = file191.ModelB().to(device)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()

    for parameter in model.parameters():
        parameter.requires_grad_(False)

    return model, checkpoint


# =====================================================================
# DETAILED PREDICTIVE METRICS
# =====================================================================

def representation_metrics(
    *,
    model,
    forward_method,
    branch_array,
    state_array,
    indices,
    time_norm_t,
    rho_mean,
    rho_std,
    state_mean,
    state_std,
    device,
):
    indices = np.asarray(indices, dtype=np.int64)

    n_states = len(state_mean)
    norm_sq_sum = np.zeros(n_states, dtype=np.float64)
    phys_sq_sum = np.zeros(n_states, dtype=np.float64)
    phys_abs_sum = np.zeros(n_states, dtype=np.float64)
    phys_max_abs = np.zeros(n_states, dtype=np.float64)

    trajectory_mse = []
    point_count = 0

    with torch.no_grad():
        for start in range(0, len(indices), 32):
            batch_indices = indices[start:start + 32]

            raw_branch = np.asarray(
                branch_array[batch_indices],
                dtype=np.float32,
            )

            branch = (
                raw_branch - np.float32(rho_mean)
            ) / np.float32(rho_std)

            target_raw = np.asarray(
                state_array[batch_indices],
                dtype=np.float32,
            )

            target_norm = (
                target_raw
                - np.asarray(state_mean, dtype=np.float32)
            ) / np.asarray(state_std, dtype=np.float32)

            branch_t = torch.as_tensor(
                branch,
                dtype=torch.float32,
                device=device,
            )

            query = (
                time_norm_t
                .view(1, -1, 1)
                .expand(len(batch_indices), -1, -1)
            )

            pred_norm_t = forward_method(
                branch_t,
                query,
            )

            pred_norm = (
                pred_norm_t
                .detach()
                .cpu()
                .numpy()
                .astype(np.float64)
            )

            target_norm64 = target_norm.astype(np.float64)
            norm_error = pred_norm - target_norm64

            pred_phys = (
                pred_norm
                * np.asarray(state_std, dtype=np.float64)
                + np.asarray(state_mean, dtype=np.float64)
            )

            target_phys = target_raw.astype(np.float64)
            phys_error = pred_phys - target_phys

            axes = (0, 1)

            norm_sq_sum += np.sum(
                norm_error ** 2,
                axis=axes,
            )

            phys_sq_sum += np.sum(
                phys_error ** 2,
                axis=axes,
            )

            phys_abs_sum += np.sum(
                np.abs(phys_error),
                axis=axes,
            )

            phys_max_abs = np.maximum(
                phys_max_abs,
                np.max(
                    np.abs(phys_error),
                    axis=axes,
                ),
            )

            per_trajectory = np.mean(
                norm_error ** 2,
                axis=(1, 2),
            )

            trajectory_mse.extend(
                per_trajectory.tolist()
            )

            point_count += int(
                len(batch_indices)
                * target_raw.shape[1]
            )

    norm_state_mse = norm_sq_sum / point_count
    norm_state_rmse = np.sqrt(norm_state_mse)

    phys_state_rmse = np.sqrt(
        phys_sq_sum / point_count
    )

    phys_state_mae = (
        phys_abs_sum / point_count
    )

    trajectory_mse = np.asarray(
        trajectory_mse,
        dtype=np.float64,
    )

    return {
        "normalized_mse": float(
            np.mean(norm_state_mse)
        ),
        "normalized_rmse": float(
            math.sqrt(
                np.mean(norm_state_mse)
            )
        ),
        "normalized_state_mse": norm_state_mse,
        "normalized_state_rmse": norm_state_rmse,
        "physical_state_rmse": phys_state_rmse,
        "physical_state_mae": phys_state_mae,
        "physical_state_max_abs_error": phys_max_abs,
        "trajectory_normalized_mse": {
            "mean": float(np.mean(trajectory_mse)),
            "median": float(np.median(trajectory_mse)),
            "q90": float(np.quantile(trajectory_mse, 0.90)),
            "q95": float(np.quantile(trajectory_mse, 0.95)),
            "maximum": float(np.max(trajectory_mse)),
        },
        "cases": int(len(indices)),
        "time_points": int(state_array.shape[1]),
    }


def evaluate_model_partition(
    *,
    model,
    partition,
    file191,
    global_rho,
    global_state,
    event_rho,
    event_state,
    event_mapping,
    global_time_norm_t,
    event_time_norm_t,
    rho_mean,
    rho_std,
    state_mean,
    state_std,
    device,
):
    start, stop = file191.PARTITIONS[partition]

    global_indices = np.arange(
        start,
        stop,
        dtype=np.int64,
    )

    event_indices = np.asarray(
        event_mapping[partition],
        dtype=np.int64,
    )

    global_metrics = representation_metrics(
        model=model,
        forward_method=model.forward_global,
        branch_array=global_rho,
        state_array=global_state,
        indices=global_indices,
        time_norm_t=global_time_norm_t,
        rho_mean=rho_mean,
        rho_std=rho_std,
        state_mean=state_mean,
        state_std=state_std,
        device=device,
    )

    event_metrics = representation_metrics(
        model=model,
        forward_method=model.forward_event,
        branch_array=event_rho,
        state_array=event_state,
        indices=event_indices,
        time_norm_t=event_time_norm_t,
        rho_mean=rho_mean,
        rho_std=rho_std,
        state_mean=state_mean,
        state_std=state_std,
        device=device,
    )

    combined_mse = (
        file191.GLOBAL_LOSS_WEIGHT
        * global_metrics["normalized_mse"]
        + file191.EVENT_LOSS_WEIGHT
        * event_metrics["normalized_mse"]
    )

    return {
        "partition": partition,
        "global": global_metrics,
        "event": event_metrics,
        "combined_normalized_mse": float(combined_mse),
        "combined_normalized_rmse": float(
            math.sqrt(combined_mse)
        ),
    }


# =====================================================================
# PAIRED PHYSICS-CONSISTENCY AUDIT
# =====================================================================

def paired_partition_residual_replicate(
    *,
    partition,
    control_model,
    pino_model,
    seed,
    file191,
    file196,
    file204,
    file208,
    file210,
    file74,
    file206,
    thermal_model,
    global_rho,
    event_rho,
    event_mapping,
    global_time,
    event_time,
    global_time_norm,
    event_time_norm,
    rho_mean,
    rho_std,
    state_mean_t,
    state_std_t,
    kinetics_scales_t,
    thermal_scales_t,
    beta_t,
    lambdas_t,
    generation_time,
    fuel_coeff_t,
    block_coeff_t,
    fuel_reference,
    block_reference,
    device,
):
    rng = np.random.default_rng(seed)

    start, stop = file191.PARTITIONS[partition]

    global_available = np.arange(
        start,
        stop,
        dtype=np.int64,
    )

    event_available = np.asarray(
        event_mapping[partition],
        dtype=np.int64,
    )

    records = {
        "control_global_full": [],
        "pino_global_full": [],
        "control_event_full": [],
        "pino_event_full": [],
        "control_global_kinetics": [],
        "pino_global_kinetics": [],
        "control_event_kinetics": [],
        "pino_event_kinetics": [],
        "control_global_thermal": [],
        "pino_global_thermal": [],
        "control_event_thermal": [],
        "pino_event_thermal": [],
    }

    for _ in range(AUDIT_BATCHES_PER_REPLICATE):
        global_cases = rng.choice(
            global_available,
            size=AUDIT_BATCH_SIZE,
            replace=False,
        )

        global_queries = file196.sample_global(
            total_points=file191.GLOBAL_POINTS,
            number_points=file191.GLOBAL_QUERY_POINTS,
            rng=rng,
        )

        control_g = file210.full_residual_batch(
            model=control_model,
            forward_method=control_model.forward_global,
            branch_array=global_rho,
            selected_cases=global_cases,
            query_indices=global_queries,
            normalized_time=global_time_norm,
            horizon_seconds=float(
                global_time[-1] - global_time[0]
            ),
            rho_mean=rho_mean,
            rho_std=rho_std,
            state_mean_t=state_mean_t,
            state_std_t=state_std_t,
            kinetics_scales_t=kinetics_scales_t,
            thermal_scales_t=thermal_scales_t,
            beta_t=beta_t,
            lambdas_t=lambdas_t,
            generation_time=generation_time,
            fuel_coeff_t=fuel_coeff_t,
            block_coeff_t=block_coeff_t,
            fuel_reference=fuel_reference,
            block_reference=block_reference,
            file196=file196,
            file204=file204,
            file208=file208,
            file74=file74,
            file206=file206,
            thermal_model=thermal_model,
            device=device,
        )

        pino_g = file210.full_residual_batch(
            model=pino_model,
            forward_method=pino_model.forward_global,
            branch_array=global_rho,
            selected_cases=global_cases,
            query_indices=global_queries,
            normalized_time=global_time_norm,
            horizon_seconds=float(
                global_time[-1] - global_time[0]
            ),
            rho_mean=rho_mean,
            rho_std=rho_std,
            state_mean_t=state_mean_t,
            state_std_t=state_std_t,
            kinetics_scales_t=kinetics_scales_t,
            thermal_scales_t=thermal_scales_t,
            beta_t=beta_t,
            lambdas_t=lambdas_t,
            generation_time=generation_time,
            fuel_coeff_t=fuel_coeff_t,
            block_coeff_t=block_coeff_t,
            fuel_reference=fuel_reference,
            block_reference=block_reference,
            file196=file196,
            file204=file204,
            file208=file208,
            file74=file74,
            file206=file206,
            thermal_model=thermal_model,
            device=device,
        )

        event_cases = rng.choice(
            event_available,
            size=AUDIT_BATCH_SIZE,
            replace=False,
        )

        event_queries = file196.sample_event(
            event_time=event_time,
            fast_number=file191.EVENT_FAST_QUERY_POINTS,
            slow_number=file191.EVENT_SLOW_QUERY_POINTS,
            rng=rng,
        )

        control_e = file210.full_residual_batch(
            model=control_model,
            forward_method=control_model.forward_event,
            branch_array=event_rho,
            selected_cases=event_cases,
            query_indices=event_queries,
            normalized_time=event_time_norm,
            horizon_seconds=float(
                event_time[-1] - event_time[0]
            ),
            rho_mean=rho_mean,
            rho_std=rho_std,
            state_mean_t=state_mean_t,
            state_std_t=state_std_t,
            kinetics_scales_t=kinetics_scales_t,
            thermal_scales_t=thermal_scales_t,
            beta_t=beta_t,
            lambdas_t=lambdas_t,
            generation_time=generation_time,
            fuel_coeff_t=fuel_coeff_t,
            block_coeff_t=block_coeff_t,
            fuel_reference=fuel_reference,
            block_reference=block_reference,
            file196=file196,
            file204=file204,
            file208=file208,
            file74=file74,
            file206=file206,
            thermal_model=thermal_model,
            device=device,
        )

        pino_e = file210.full_residual_batch(
            model=pino_model,
            forward_method=pino_model.forward_event,
            branch_array=event_rho,
            selected_cases=event_cases,
            query_indices=event_queries,
            normalized_time=event_time_norm,
            horizon_seconds=float(
                event_time[-1] - event_time[0]
            ),
            rho_mean=rho_mean,
            rho_std=rho_std,
            state_mean_t=state_mean_t,
            state_std_t=state_std_t,
            kinetics_scales_t=kinetics_scales_t,
            thermal_scales_t=thermal_scales_t,
            beta_t=beta_t,
            lambdas_t=lambdas_t,
            generation_time=generation_time,
            fuel_coeff_t=fuel_coeff_t,
            block_coeff_t=block_coeff_t,
            fuel_reference=fuel_reference,
            block_reference=block_reference,
            file196=file196,
            file204=file204,
            file208=file208,
            file74=file74,
            file206=file206,
            thermal_model=thermal_model,
            device=device,
        )

        for family, key in [
            ("full", "full_mse"),
            ("kinetics", "kinetics_mse"),
            ("thermal", "thermal_mse"),
        ]:
            records[f"control_global_{family}"].append(
                control_g[key]
            )
            records[f"pino_global_{family}"].append(
                pino_g[key]
            )
            records[f"control_event_{family}"].append(
                control_e[key]
            )
            records[f"pino_event_{family}"].append(
                pino_e[key]
            )

    result = {
        "partition": partition,
        "seed": seed,
    }

    for family in [
        "full",
        "kinetics",
        "thermal",
    ]:
        control_global = float(
            np.mean(
                records[f"control_global_{family}"]
            )
        )
        pino_global = float(
            np.mean(
                records[f"pino_global_{family}"]
            )
        )
        control_event = float(
            np.mean(
                records[f"control_event_{family}"]
            )
        )
        pino_event = float(
            np.mean(
                records[f"pino_event_{family}"]
            )
        )

        control_combined = (
            file191.GLOBAL_LOSS_WEIGHT * control_global
            + file191.EVENT_LOSS_WEIGHT * control_event
        )

        pino_combined = (
            file191.GLOBAL_LOSS_WEIGHT * pino_global
            + file191.EVENT_LOSS_WEIGHT * pino_event
        )

        result[family] = {
            "control_global": control_global,
            "pino_global": pino_global,
            "control_event": control_event,
            "pino_event": pino_event,
            "control_combined": control_combined,
            "pino_combined": pino_combined,
            "improvement_percent": percent_improvement(
                control_combined,
                pino_combined,
            ),
        }

    return result


def summarize_residual_replicates(records, family):
    improvements = np.asarray(
        [
            row[family]["improvement_percent"]
            for row in records
        ],
        dtype=np.float64,
    )

    control = np.asarray(
        [
            row[family]["control_combined"]
            for row in records
        ],
        dtype=np.float64,
    )

    pino = np.asarray(
        [
            row[family]["pino_combined"]
            for row in records
        ],
        dtype=np.float64,
    )

    positive = int(
        np.sum(improvements > 0.0)
    )

    required_positive = math.ceil(
        STABLE_POSITIVE_FRACTION
        * len(records)
    )

    mean_improvement = float(
        np.mean(improvements)
    )

    stable_positive = bool(
        positive >= required_positive
        and mean_improvement > 0.0
    )

    if stable_positive:
        classification = "STABLE_IMPROVEMENT"
    elif positive == 0 and mean_improvement < 0.0:
        classification = "STABLE_DEGRADATION"
    else:
        classification = "MIXED_EFFECT"

    return {
        "replicates": len(records),
        "positive_replicates": positive,
        "required_positive": required_positive,
        "mean_control_residual": float(np.mean(control)),
        "mean_pino_residual": float(np.mean(pino)),
        "mean_improvement_percent": mean_improvement,
        "median_improvement_percent": float(
            np.median(improvements)
        ),
        "minimum_improvement_percent": float(
            np.min(improvements)
        ),
        "maximum_improvement_percent": float(
            np.max(improvements)
        ),
        "q10_percent": float(
            np.quantile(improvements, 0.10)
        ),
        "q90_percent": float(
            np.quantile(improvements, 0.90)
        ),
        "stable_improvement": stable_positive,
        "classification": classification,
    }


# =====================================================================
# CSV OUTPUTS
# =====================================================================

def write_predictive_csv(path, predictive_results):
    fieldnames = [
        "partition",
        "model",
        "global_mse",
        "event_mse",
        "combined_mse",
        "combined_rmse",
        "improvement_vs_model_b_percent",
        "improvement_vs_matched_control_percent",
    ]

    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=fieldnames,
        )
        writer.writeheader()

        for partition, block in predictive_results.items():
            model_b = block["MODEL_B"]["combined_normalized_mse"]
            control = block["MATCHED_CONTROL"]["combined_normalized_mse"]

            for model_name, result in block.items():
                writer.writerow({
                    "partition": partition,
                    "model": model_name,
                    "global_mse": result["global"]["normalized_mse"],
                    "event_mse": result["event"]["normalized_mse"],
                    "combined_mse": result["combined_normalized_mse"],
                    "combined_rmse": result["combined_normalized_rmse"],
                    "improvement_vs_model_b_percent": (
                        percent_improvement(
                            model_b,
                            result["combined_normalized_mse"],
                        )
                    ),
                    "improvement_vs_matched_control_percent": (
                        percent_improvement(
                            control,
                            result["combined_normalized_mse"],
                        )
                    ),
                })


def write_state_csv(path, predictive_results, state_names):
    fieldnames = [
        "partition",
        "model",
        "representation",
        "state_index",
        "state_name",
        "normalized_rmse",
        "physical_rmse",
        "physical_mae",
        "physical_max_abs_error",
    ]

    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=fieldnames,
        )
        writer.writeheader()

        for partition, block in predictive_results.items():
            for model_name, result in block.items():
                for representation in ["global", "event"]:
                    metrics = result[representation]

                    for index, state_name in enumerate(state_names):
                        writer.writerow({
                            "partition": partition,
                            "model": model_name,
                            "representation": representation,
                            "state_index": index,
                            "state_name": state_name,
                            "normalized_rmse": metrics[
                                "normalized_state_rmse"
                            ][index],
                            "physical_rmse": metrics[
                                "physical_state_rmse"
                            ][index],
                            "physical_mae": metrics[
                                "physical_state_mae"
                            ][index],
                            "physical_max_abs_error": metrics[
                                "physical_state_max_abs_error"
                            ][index],
                        })


def write_residual_csv(path, residual_results):
    fieldnames = [
        "partition",
        "family",
        "control_mean_residual",
        "pino_mean_residual",
        "mean_improvement_percent",
        "positive_replicates",
        "replicates",
        "classification",
    ]

    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=fieldnames,
        )
        writer.writeheader()

        for partition, block in residual_results.items():
            for family in [
                "full",
                "kinetics",
                "thermal",
            ]:
                summary = block[family]
                writer.writerow({
                    "partition": partition,
                    "family": family,
                    "control_mean_residual": summary[
                        "mean_control_residual"
                    ],
                    "pino_mean_residual": summary[
                        "mean_pino_residual"
                    ],
                    "mean_improvement_percent": summary[
                        "mean_improvement_percent"
                    ],
                    "positive_replicates": summary[
                        "positive_replicates"
                    ],
                    "replicates": summary[
                        "replicates"
                    ],
                    "classification": summary[
                        "classification"
                    ],
                })


# =====================================================================
# MAIN
# =====================================================================

def main():
    root = find_root()
    production = root / "step6_dataset" / "production_v1"

    file191 = load_module(
        "file191_211",
        root / "191_step7_model_b_training.py",
    )
    file196 = load_module(
        "file196_211",
        root / "196_step7_kinetics_physics_preflight_gate.py",
    )
    file204 = load_module(
        "file204_211",
        root / "204_step7_coupled_kinetics_weight_gate.py",
    )
    file206 = load_module(
        "file206_211",
        root / "206_step7_exact_thermal_autograd_closure_audit.py",
    )
    file208 = load_module(
        "file208_211",
        root / "208_step7_thermal_only_weight_gate.py",
    )
    file210 = load_module(
        "file210_211",
        root / "210_step7_full_physics_weight_gate.py",
    )
    file70 = load_module(
        "file70_211",
        root / "70_reference_reactor_kinetics.py",
    )
    file74 = load_module(
        "file74_211",
        root / "74_master_coupled_reference_model.py",
    )

    file198_path = (
        root
        / "step7_pino"
        / "physics_informed"
        / "preflight"
        / "198_dimensionless_kinetics_residual_gate.json"
    )

    file207_path = (
        root
        / "step7_pino"
        / "physics_informed"
        / "thermal_preflight"
        / "207_thermal_residual_normalization_gate.json"
    )

    file208_json_path = (
        root
        / "step7_pino"
        / "physics_informed"
        / "thermal_only"
        / "208_thermal_only_weight_gate.json"
    )

    file210_json_path = (
        root
        / "step7_pino"
        / "physics_informed"
        / "full_physics"
        / "210_full_physics_weight_gate.json"
    )

    base_checkpoint_path = (
        root
        / "step7_pino"
        / "model_b_training"
        / "model_b_best.pt"
    )

    control_checkpoint_path = (
        root
        / "step7_pino"
        / "physics_informed"
        / "power_lr_gate"
        / "lr_0p5_data_control_best.pt"
    )

    output_dir = (
        root
        / "step7_pino"
        / "physics_informed"
        / "confirmatory_evaluation"
    )

    output_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    output_json = (
        output_dir
        / "211_frozen_full_pino_confirmatory_evaluation.json"
    )

    output_txt = (
        output_dir
        / "211_frozen_full_pino_confirmatory_evaluation.txt"
    )

    predictive_csv = (
        output_dir
        / "211_predictive_summary.csv"
    )

    state_csv = (
        output_dir
        / "211_state_metrics.csv"
    )

    residual_csv = (
        output_dir
        / "211_residual_summary.csv"
    )

    print("=" * 78)
    print("STEP 7 FROZEN FULL-PINO CONFIRMATORY EVALUATION")
    print("=" * 78)
    print(f"Project root : {root}")
    print()

    file198 = json.loads(
        require_file(file198_path).read_text(
            encoding="utf-8"
        )
    )

    file207 = json.loads(
        require_file(file207_path).read_text(
            encoding="utf-8"
        )
    )

    file210_json = json.loads(
        require_file(file210_json_path).read_text(
            encoding="utf-8"
        )
    )

    if file198.get("status") != "PASS":
        raise RuntimeError("File 198 has not passed.")

    if (
        file207.get("status")
        != "THERMAL_RESIDUAL_NORMALIZATION_READY"
    ):
        raise RuntimeError("File 207 has not passed.")

    if (
        file210_json.get("selection_status")
        != "FULL_PHYSICS_PINO_CANDIDATE_FROZEN"
    ):
        raise RuntimeError(
            "File 210 did not freeze a full-PINO candidate."
        )

    selected = file210_json.get("selected_candidate")

    if selected is None:
        raise RuntimeError(
            "File 210 selected candidate is missing."
        )

    selected_fraction = float(
        selected["fraction"]
    )

    selected_lambda = float(
        selected["lambda"]
    )

    selected_checkpoint_path = Path(
        selected["checkpoint"]
    )

    if not selected_checkpoint_path.exists():
        tag = (
            f"{selected_fraction:.3f}"
            .replace(".", "p")
        )
        selected_checkpoint_path = (
            root
            / "step7_pino"
            / "physics_informed"
            / "full_physics"
            / f"full_physics_{tag}_best.pt"
        )

    selected_checkpoint_path = require_file(
        selected_checkpoint_path
    )

    print("FROZEN FILE-210 MODEL")
    print("-" * 78)
    print(
        f"Selected fraction : {selected_fraction:.3f}"
    )
    print(
        f"Selected lambda   : {selected_lambda:.10e}"
    )
    print(
        f"Selected epoch    : {selected['best_epoch']}"
    )
    print(
        f"Validation MSE    : {selected['validation_mse']:.10e}"
    )
    print(
        "Selection status  : FULL_PHYSICS_PINO_CANDIDATE_FROZEN"
    )
    print()

    device = torch.device(
        "cuda" if torch.cuda.is_available() else "cpu"
    )

    print(f"Device : {device}")
    if device.type == "cuda":
        print(
            "GPU    : "
            + torch.cuda.get_device_name(0)
        )
    print()

    global_time = np.asarray(
        file191.load_npy(
            production,
            "global_time_s.npy",
        ),
        dtype=np.float32,
    )

    global_rho = file191.load_npy(
        production,
        "global_reactivity_delta_k_over_k.npy",
    )

    global_state = file191.load_npy(
        production,
        "global_state.npy",
    )

    event_time = np.asarray(
        file191.load_npy(
            production,
            "step_event_relative_time_s.npy",
        ),
        dtype=np.float32,
    )

    event_rho = file191.load_npy(
        production,
        "step_event_reactivity_delta_k_over_k.npy",
    )

    event_state = file191.load_npy(
        production,
        "step_event_state.npy",
    )

    step_case_indices = np.asarray(
        file191.load_npy(
            production,
            "step_case_indices.npy",
        ),
        dtype=np.int64,
    )

    state_names = [
        str(value)
        for value in np.asarray(
            file191.load_npy(
                production,
                "state_names.npy",
            )
        ).tolist()
    ]

    event_mapping = (
        file191.build_event_partition_mapping(
            step_case_indices
        )
    )

    global_time_norm_np = file191.normalize_time(
        global_time
    )

    event_time_norm_np = file191.normalize_time(
        event_time
    )

    global_time_norm_t = torch.as_tensor(
        global_time_norm_np,
        dtype=torch.float32,
        device=device,
    )

    event_time_norm_t = torch.as_tensor(
        event_time_norm_np,
        dtype=torch.float32,
        device=device,
    )

    model_b, model_b_checkpoint = load_model(
        file191,
        base_checkpoint_path,
        device,
    )

    control_model, control_checkpoint = load_model(
        file191,
        control_checkpoint_path,
        device,
    )

    pino_model, pino_checkpoint = load_model(
        file191,
        selected_checkpoint_path,
        device,
    )

    normalization = model_b_checkpoint[
        "normalization"
    ]

    normalization_audit = {
        "model_b": True,
        "matched_control": normalization_match(
            normalization,
            control_checkpoint.get("normalization"),
        ),
        "full_pino": normalization_match(
            normalization,
            pino_checkpoint.get("normalization"),
        ),
    }

    if not all(normalization_audit.values()):
        raise RuntimeError(
            "Checkpoint normalization mismatch."
        )

    rho_mean = float(
        normalization["rho_mean"]
    )

    rho_std = float(
        normalization["rho_std"]
    )

    state_mean = np.asarray(
        normalization["state_mean"],
        dtype=np.float64,
    )

    state_std = np.asarray(
        normalization["state_std"],
        dtype=np.float64,
    )

    state_mean_t = torch.as_tensor(
        state_mean,
        dtype=torch.float32,
        device=device,
    ).view(1, 1, -1)

    state_std_t = torch.as_tensor(
        state_std,
        dtype=torch.float32,
        device=device,
    ).view(1, 1, -1)

    print("CHECKPOINT AUDIT")
    print("-" * 78)
    print(
        f"Model-B epoch        : {model_b_checkpoint.get('epoch')}"
    )
    print(
        f"Matched-control epoch: {control_checkpoint.get('epoch')}"
    )
    print(
        f"Full-PINO epoch      : {pino_checkpoint.get('epoch')}"
    )
    print("Normalization match  : PASS")
    print()

    # Optional frozen thermal-only ablation.
    thermal_model_nn = None
    thermal_checkpoint = None
    thermal_selected = None

    if file208_json_path.exists():
        file208_json = json.loads(
            file208_json_path.read_text(
                encoding="utf-8"
            )
        )

        thermal_selected = file208_json.get(
            "selected_candidate"
        )

        if thermal_selected is not None:
            thermal_checkpoint_path = Path(
                thermal_selected["checkpoint"]
            )

            if thermal_checkpoint_path.exists():
                (
                    thermal_model_nn,
                    thermal_checkpoint,
                ) = load_model(
                    file191,
                    thermal_checkpoint_path,
                    device,
                )

                if not normalization_match(
                    normalization,
                    thermal_checkpoint.get(
                        "normalization"
                    ),
                ):
                    raise RuntimeError(
                        "Thermal-only normalization mismatch."
                    )

    models = {
        "MODEL_B": model_b,
        "MATCHED_CONTROL": control_model,
        "FULL_PINO": pino_model,
    }

    if thermal_model_nn is not None:
        models["THERMAL_ONLY"] = thermal_model_nn

    print("PREDICTIVE CONFIRMATORY EVALUATION")
    print("-" * 78)

    predictive_results = {}

    for partition in EVALUATION_PARTITIONS:
        predictive_results[partition] = {}

        for model_name, model in models.items():
            result = evaluate_model_partition(
                model=model,
                partition=partition,
                file191=file191,
                global_rho=global_rho,
                global_state=global_state,
                event_rho=event_rho,
                event_state=event_state,
                event_mapping=event_mapping,
                global_time_norm_t=global_time_norm_t,
                event_time_norm_t=event_time_norm_t,
                rho_mean=rho_mean,
                rho_std=rho_std,
                state_mean=state_mean,
                state_std=state_std,
                device=device,
            )

            predictive_results[
                partition
            ][
                model_name
            ] = result

        control_mse = predictive_results[
            partition
        ][
            "MATCHED_CONTROL"
        ][
            "combined_normalized_mse"
        ]

        pino_mse = predictive_results[
            partition
        ][
            "FULL_PINO"
        ][
            "combined_normalized_mse"
        ]

        improvement = percent_improvement(
            control_mse,
            pino_mse,
        )

        pino_result = predictive_results[
            partition
        ][
            "FULL_PINO"
        ]

        print(
            f"{partition:<14} "
            f"Control={control_mse:.8e} | "
            f"PINO={pino_mse:.8e} | "
            f"Improvement={improvement:+.3f}% | "
            f"Global={pino_result['global']['normalized_mse']:.8e} | "
            f"Event={pino_result['event']['normalized_mse']:.8e}"
        )

    print()
    print("PAIRED PHYSICS-CONSISTENCY CONFIRMATION")
    print("-" * 78)

    kinetics_scales = np.asarray(
        file198["physics_scales"],
        dtype=np.float64,
    )

    thermal_scales = np.asarray(
        file207[
            "normalization_contract"
        ][
            "thermal_scales"
        ],
        dtype=np.float64,
    )

    if not (
        kinetics_scales.shape == (7,)
        and thermal_scales.shape == (3,)
    ):
        raise RuntimeError(
            "Residual-scale shape mismatch."
        )

    kinetics_scales_t = torch.as_tensor(
        kinetics_scales,
        dtype=torch.float32,
        device=device,
    ).view(1, 1, 7)

    thermal_scales_t = torch.as_tensor(
        thermal_scales,
        dtype=torch.float32,
        device=device,
    ).view(1, 1, 3)

    beta = np.asarray(
        file70.BETA,
        dtype=np.float64,
    )

    lambdas = np.asarray(
        file70.LAMBDA,
        dtype=np.float64,
    )

    generation_time = float(
        file70.GENERATION_TIME
    )

    fuel_coeff = np.asarray(
        file70.FUEL_COEFF,
        dtype=np.float64,
    )

    block_coeff = np.asarray(
        file70.BLOCK_COEFF,
        dtype=np.float64,
    )

    fuel_reference = float(
        file74.T_FUEL_REF
    )

    block_reference = float(
        file74.T_BLOCK_REF
    )

    beta_t = torch.as_tensor(
        beta,
        dtype=torch.float32,
        device=device,
    )

    lambdas_t = torch.as_tensor(
        lambdas,
        dtype=torch.float32,
        device=device,
    )

    fuel_coeff_t = torch.as_tensor(
        fuel_coeff,
        dtype=torch.float32,
        device=device,
    )

    block_coeff_t = torch.as_tensor(
        block_coeff,
        dtype=torch.float32,
        device=device,
    )

    physical_thermal_model = (
        file74.MasterCoupledReferenceModel()
    )

    residual_results = {}

    for partition_index, partition in enumerate(
        EVALUATION_PARTITIONS
    ):
        records = []

        for replicate in range(AUDIT_REPLICATES):
            record = paired_partition_residual_replicate(
                partition=partition,
                control_model=control_model,
                pino_model=pino_model,
                seed=(
                    AUDIT_SEED_BASE
                    + 1000 * partition_index
                    + replicate
                ),
                file191=file191,
                file196=file196,
                file204=file204,
                file208=file208,
                file210=file210,
                file74=file74,
                file206=file206,
                thermal_model=physical_thermal_model,
                global_rho=global_rho,
                event_rho=event_rho,
                event_mapping=event_mapping,
                global_time=global_time,
                event_time=event_time,
                global_time_norm=global_time_norm_np,
                event_time_norm=event_time_norm_np,
                rho_mean=rho_mean,
                rho_std=rho_std,
                state_mean_t=state_mean_t,
                state_std_t=state_std_t,
                kinetics_scales_t=kinetics_scales_t,
                thermal_scales_t=thermal_scales_t,
                beta_t=beta_t,
                lambdas_t=lambdas_t,
                generation_time=generation_time,
                fuel_coeff_t=fuel_coeff_t,
                block_coeff_t=block_coeff_t,
                fuel_reference=fuel_reference,
                block_reference=block_reference,
                device=device,
            )

            records.append(record)

        residual_results[partition] = {
            "full": summarize_residual_replicates(
                records,
                "full",
            ),
            "kinetics": summarize_residual_replicates(
                records,
                "kinetics",
            ),
            "thermal": summarize_residual_replicates(
                records,
                "thermal",
            ),
            "replicate_records": records,
        }

        full_summary = residual_results[
            partition
        ][
            "full"
        ]

        kinetics_summary = residual_results[
            partition
        ][
            "kinetics"
        ]

        thermal_summary = residual_results[
            partition
        ][
            "thermal"
        ]

        print(
            f"{partition:<14} "
            f"Full={full_summary['mean_improvement_percent']:+.3f}% "
            f"({full_summary['positive_replicates']}/{AUDIT_REPLICATES}) | "
            f"K={kinetics_summary['mean_improvement_percent']:+.3f}% | "
            f"T={thermal_summary['mean_improvement_percent']:+.3f}% | "
            f"Class={full_summary['classification']}"
        )

    # -----------------------------------------------------------------
    # DESCRIPTIVE MACRO SUMMARY. NOT A SELECTION SCORE.
    # -----------------------------------------------------------------

    pino_vs_control_improvements = []
    pino_vs_model_b_improvements = []

    for partition in EVALUATION_PARTITIONS:
        block = predictive_results[partition]

        pino_mse = block[
            "FULL_PINO"
        ][
            "combined_normalized_mse"
        ]

        control_mse = block[
            "MATCHED_CONTROL"
        ][
            "combined_normalized_mse"
        ]

        model_b_mse = block[
            "MODEL_B"
        ][
            "combined_normalized_mse"
        ]

        pino_vs_control_improvements.append(
            percent_improvement(
                control_mse,
                pino_mse,
            )
        )

        pino_vs_model_b_improvements.append(
            percent_improvement(
                model_b_mse,
                pino_mse,
            )
        )

    macro_summary = {
        "mean_predictive_improvement_vs_matched_control_percent": float(
            np.mean(pino_vs_control_improvements)
        ),
        "mean_predictive_improvement_vs_model_b_percent": float(
            np.mean(pino_vs_model_b_improvements)
        ),
        "partitions_better_than_matched_control": int(
            np.sum(
                np.asarray(
                    pino_vs_control_improvements
                ) > 0.0
            )
        ),
        "number_of_reserved_partitions": len(
            EVALUATION_PARTITIONS
        ),
        "selection_role": (
            "DESCRIPTIVE_ONLY_NO_MODEL_SELECTION"
        ),
    }

    payload = {
        "script": (
            "211_step7_frozen_full_pino_confirmatory_evaluation.py"
        ),
        "status": (
            "FROZEN_FULL_PINO_CONFIRMATORY_EVALUATION_COMPLETE"
        ),
        "training_performed": False,
        "hyperparameter_tuning": False,
        "checkpoint_selection_performed": False,
        "production_v1_modified": False,
        "test_partitions_accessed": True,
        "test_partitions_used_for_tuning": False,
        "evaluation_partitions": EVALUATION_PARTITIONS,
        "frozen_model": {
            "source": (
                "File 210 validation-only selection"
            ),
            "fraction": selected_fraction,
            "lambda": selected_lambda,
            "epoch": int(selected["best_epoch"]),
            "validation_mse": float(
                selected["validation_mse"]
            ),
            "checkpoint": str(
                selected_checkpoint_path
            ),
        },
        "comparators": {
            "model_b": str(
                base_checkpoint_path
            ),
            "matched_data_only_control": str(
                control_checkpoint_path
            ),
            "thermal_only_included": (
                thermal_model_nn is not None
            ),
            "thermal_only_selected_candidate": (
                thermal_selected
            ),
        },
        "normalization_audit": normalization_audit,
        "state_names": state_names,
        "predictive_results": predictive_results,
        "physics_residual_contract": {
            "kinetics_family_weight": (
                KINETICS_FAMILY_WEIGHT
            ),
            "thermal_family_weight": (
                THERMAL_FAMILY_WEIGHT
            ),
            "kinetics_scales": kinetics_scales,
            "thermal_scales": thermal_scales,
            "audit_replicates": AUDIT_REPLICATES,
            "batches_per_replicate": (
                AUDIT_BATCHES_PER_REPLICATE
            ),
            "batch_size": AUDIT_BATCH_SIZE,
            "paired_against": (
                "matched data-only continuation"
            ),
            "post_selection_descriptive_only": True,
        },
        "residual_results": residual_results,
        "macro_summary": macro_summary,
    }

    output_json.write_text(
        json.dumps(
            serializable(payload),
            indent=2,
            allow_nan=False,
        ),
        encoding="utf-8",
    )

    write_predictive_csv(
        predictive_csv,
        predictive_results,
    )

    write_state_csv(
        state_csv,
        predictive_results,
        state_names,
    )

    write_residual_csv(
        residual_csv,
        residual_results,
    )

    report = [
        "=" * 78,
        "STEP 7 FROZEN FULL-PINO CONFIRMATORY EVALUATION",
        "=" * 78,
        "",
        f"Frozen physics fraction : {selected_fraction:.3f}",
        f"Frozen lambda           : {selected_lambda:.10e}",
        f"Frozen best epoch       : {selected['best_epoch']}",
        "",
        "PREDICTIVE RESULTS",
        "-" * 78,
    ]

    for partition in EVALUATION_PARTITIONS:
        block = predictive_results[partition]
        model_b_mse = block[
            "MODEL_B"
        ][
            "combined_normalized_mse"
        ]
        control_mse = block[
            "MATCHED_CONTROL"
        ][
            "combined_normalized_mse"
        ]
        pino_mse = block[
            "FULL_PINO"
        ][
            "combined_normalized_mse"
        ]

        report.append(
            f"{partition:<14} "
            f"ModelB={model_b_mse:.10e} "
            f"Control={control_mse:.10e} "
            f"PINO={pino_mse:.10e} "
            f"PINOvsControl={percent_improvement(control_mse, pino_mse):+.4f}%"
        )

    report.extend([
        "",
        "PHYSICS-CONSISTENCY RESULTS",
        "-" * 78,
    ])

    for partition in EVALUATION_PARTITIONS:
        block = residual_results[partition]
        report.append(
            f"{partition:<14} "
            f"Full={block['full']['mean_improvement_percent']:+.4f}% "
            f"K={block['kinetics']['mean_improvement_percent']:+.4f}% "
            f"T={block['thermal']['mean_improvement_percent']:+.4f}% "
            f"FullClass={block['full']['classification']}"
        )

    report.extend([
        "",
        "MACRO DESCRIPTIVE SUMMARY",
        "-" * 78,
        (
            "Mean PINO improvement vs matched control : "
            f"{macro_summary['mean_predictive_improvement_vs_matched_control_percent']:+.4f}%"
        ),
        (
            "Mean PINO improvement vs original Model-B: "
            f"{macro_summary['mean_predictive_improvement_vs_model_b_percent']:+.4f}%"
        ),
        (
            "Reserved partitions better than control : "
            f"{macro_summary['partitions_better_than_matched_control']}"
            f"/{macro_summary['number_of_reserved_partitions']}"
        ),
        "",
        "Training performed             : NO",
        "Hyperparameter tuning          : NO",
        "Checkpoint selection           : NO",
        "Test partitions accessed       : YES",
        "Test partitions used for tuning: NO",
        "Production-V1 modified         : NO",
        "",
        "STATUS: FROZEN_FULL_PINO_CONFIRMATORY_EVALUATION_COMPLETE",
    ])

    output_txt.write_text(
        "\n".join(report) + "\n",
        encoding="utf-8",
    )

    print()
    print("=" * 78)
    print("CONFIRMATORY EVALUATION COMPLETE")
    print("=" * 78)
    print(
        "Model selection/tuning after test access : NO"
    )
    print(
        "Production-V1 modified                  : NO"
    )
    print()
    print(f"JSON report      : {output_json}")
    print(f"Text report      : {output_txt}")
    print(f"Predictive CSV   : {predictive_csv}")
    print(f"State metrics CSV: {state_csv}")
    print(f"Residual CSV     : {residual_csv}")
    print()
    print(
        "STATUS: FROZEN_FULL_PINO_CONFIRMATORY_EVALUATION_COMPLETE"
    )


if __name__ == "__main__":
    main()
