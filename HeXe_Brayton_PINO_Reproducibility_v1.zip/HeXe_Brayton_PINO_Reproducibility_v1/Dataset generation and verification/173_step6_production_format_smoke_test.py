from __future__ import annotations

import csv
import dataclasses
import hashlib
import importlib.util
import json
import os
import sys
import traceback
from pathlib import Path
from typing import Any, Callable

import numpy as np
from scipy.integrate import solve_ivp


# ============================================================================
# 173_step6_production_format_smoke_test.py
#
# STEP 6
# PRODUCTION-FORMAT GENERATOR SMOKE TEST
#
# CORRECTION
# ----------
# The first File-173 run produced:
#
#   10 / 11 successful cases
#
# All disturbed trajectories passed.
#
# The BASELINE case alone failed because its production representation is
# intentionally created by repeating the exact frozen rated equilibrium:
#
#   generate_baseline_case()
#
# That shortcut performs no transient integration, so File-72
# viscosity/thermal_conductivity were never called. The runtime transport
# profiler therefore reported zero calls and classified the baseline as a
# failed transport gate.
#
# This was an AUDIT-LOGIC issue, not a model or transport-support failure.
#
# CORRECTION:
# -----------
# For the exact baseline only:
#
#   1. keep the exact repeated equilibrium trajectory;
#   2. instantiate File-74;
#   3. set zero external reactivity;
#   4. evaluate derivatives once at the rated state while the File-72
#      profiler is active;
#   5. require that derivative to be finite.
#
# This exercises the actual baseline File-74 -> File-73 -> File-72 runtime
# path without introducing artificial baseline integration drift.
#
# No physics, model parameter, production sample count, partition, or
# temporal resolution is changed.
# ============================================================================


# ============================================================================
# PROJECT FILES
# ============================================================================

FILE72 = "72_hexe_transport_properties.py"
FILE74 = "74_master_coupled_reference_model.py"

DATASET_DIRECTORY = "step6_dataset"

FILE166_CONTRACT = (
    "166_step6_pilot_dataset_contract.json"
)

FILE172_MANIFEST = (
    "172_step6_production_manifest.csv"
)

FILE172_CONTRACT = (
    "172_step6_production_dataset_contract.json"
)


# ============================================================================
# OUTPUT DIRECTORY
# ============================================================================

SMOKE_DIRECTORY = "production_smoke_test"

SELECTED_MANIFEST_NAME = (
    "173_smoke_selected_manifest.csv"
)

SUMMARY_CSV_NAME = (
    "173_smoke_execution_summary.csv"
)

METADATA_JSON_NAME = (
    "173_smoke_dataset_metadata.json"
)

REPORT_NAME = (
    "173_step6_production_format_smoke_test_report.txt"
)


# ============================================================================
# NUMERICAL SOLVER
# ============================================================================

RTOL = 1.0e-7
ATOL = 1.0e-9

GLOBAL_MAX_STEP_S = 1.0


# ============================================================================
# TRANSPORT SUPPORT
# ============================================================================

TRANSPORT_MIN_K = 400.0
TRANSPORT_MAX_K = 1200.0


# ============================================================================
# HELPERS
# ============================================================================


def require_file(
    path: Path,
) -> Path:

    if not path.exists():

        raise FileNotFoundError(
            f"Required file missing: {path}"
        )

    return path


def sha256_file(
    path: Path,
) -> str:

    digest = hashlib.sha256()

    with path.open(
        "rb"
    ) as f:

        while True:

            block = f.read(
                1024 * 1024
            )

            if not block:

                break

            digest.update(
                block
            )

    return digest.hexdigest()


def load_module_from_file(
    module_name: str,
    path: Path,
):

    spec = importlib.util.spec_from_file_location(
        module_name,
        path,
    )

    if (
        spec is None
        or spec.loader is None
    ):

        raise ImportError(
            f"Could not load {path}"
        )

    module = importlib.util.module_from_spec(
        spec
    )

    sys.modules[
        module_name
    ] = module

    spec.loader.exec_module(
        module
    )

    return module


def read_csv(
    path: Path,
) -> list[dict[str, str]]:

    with path.open(
        "r",
        encoding="utf-8-sig",
        newline="",
    ) as f:

        return list(
            csv.DictReader(
                f
            )
        )


def write_csv(
    path: Path,
    rows: list[dict[str, object]],
) -> None:

    if not rows:

        raise RuntimeError(
            f"Cannot write empty CSV: {path}"
        )

    fields = []

    for row in rows:

        for key in row.keys():

            if key not in fields:

                fields.append(
                    key
                )

    with path.open(
        "w",
        encoding="utf-8-sig",
        newline="",
    ) as f:

        writer = csv.DictWriter(
            f,
            fieldnames=fields,
        )

        writer.writeheader()

        writer.writerows(
            rows
        )


def finite_float(
    value,
) -> float | None:

    if isinstance(
        value,
        bool,
    ):

        return None

    if isinstance(
        value,
        (
            int,
            float,
            np.integer,
            np.floating,
        ),
    ):

        x = float(
            value
        )

        if np.isfinite(
            x
        ):

            return x

    return None


def float_value(
    row: dict[str, str],
    key: str,
    default: float | None = None,
) -> float:

    value = row.get(
        key,
        "",
    )

    if (
        value is None
        or
        str(
            value
        ).strip()
        == ""
    ):

        if default is None:

            raise ValueError(
                f"Missing manifest field: {key}"
            )

        return float(
            default
        )

    return float(
        value
    )


# ============================================================================
# RECURSIVE CYCLE OUTPUT FLATTENING
# ============================================================================


def flatten_numeric(
    obj: Any,
    prefix: str = "cycle",
    depth: int = 0,
    seen: set[int] | None = None,
) -> dict[str, float]:

    if seen is None:

        seen = set()

    if depth > 7:

        return {}

    scalar = finite_float(
        obj
    )

    if scalar is not None:

        return {
            prefix:
                scalar
        }

    if obj is None:

        return {}

    object_id = id(
        obj
    )

    if object_id in seen:

        return {}

    seen.add(
        object_id
    )

    output: dict[
        str,
        float,
    ] = {}

    # ------------------------------------------------------------------
    # Dictionary
    # ------------------------------------------------------------------

    if isinstance(
        obj,
        dict,
    ):

        for key, value in (
            obj.items()
        ):

            child = flatten_numeric(
                value,

                prefix=(
                    f"{prefix}.{key}"
                ),

                depth=(
                    depth + 1
                ),

                seen=seen,
            )

            output.update(
                child
            )

        return output

    # ------------------------------------------------------------------
    # Dataclass
    # ------------------------------------------------------------------

    if (
        dataclasses.is_dataclass(
            obj
        )
        and
        not isinstance(
            obj,
            type,
        )
    ):

        for field in (
            dataclasses.fields(
                obj
            )
        ):

            value = getattr(
                obj,
                field.name,
            )

            child = flatten_numeric(
                value,

                prefix=(
                    f"{prefix}.{field.name}"
                ),

                depth=(
                    depth + 1
                ),

                seen=seen,
            )

            output.update(
                child
            )

        return output

    # ------------------------------------------------------------------
    # Named tuple
    # ------------------------------------------------------------------

    if hasattr(
        obj,
        "_asdict",
    ):

        try:

            return flatten_numeric(
                obj._asdict(),

                prefix=prefix,

                depth=(
                    depth + 1
                ),

                seen=seen,
            )

        except Exception:

            pass

    # ------------------------------------------------------------------
    # ndarray
    # ------------------------------------------------------------------

    if isinstance(
        obj,
        np.ndarray,
    ):

        array = np.asarray(
            obj
        )

        if array.ndim == 0:

            scalar = finite_float(
                array.item()
            )

            if scalar is not None:

                output[
                    prefix
                ] = scalar

            return output

        if array.size > 128:

            return {}

        for index in np.ndindex(
            array.shape
        ):

            scalar = finite_float(
                array[
                    index
                ]
            )

            if scalar is None:

                continue

            index_text = "_".join(
                str(
                    value
                )
                for value
                in index
            )

            output[
                f"{prefix}[{index_text}]"
            ] = scalar

        return output

    # ------------------------------------------------------------------
    # Tuple / list
    # ------------------------------------------------------------------

    if isinstance(
        obj,
        (
            tuple,
            list,
        ),
    ):

        for index, value in enumerate(
            obj
        ):

            child = flatten_numeric(
                value,

                prefix=(
                    f"{prefix}[{index}]"
                ),

                depth=(
                    depth + 1
                ),

                seen=seen,
            )

            output.update(
                child
            )

        return output

    # ------------------------------------------------------------------
    # Public object attributes
    # ------------------------------------------------------------------

    if hasattr(
        obj,
        "__dict__",
    ):

        try:

            attributes = vars(
                obj
            )

        except Exception:

            attributes = {}

        for name, value in (
            attributes.items()
        ):

            if str(
                name
            ).startswith(
                "_"
            ):

                continue

            if callable(
                value
            ):

                continue

            child = flatten_numeric(
                value,

                prefix=(
                    f"{prefix}.{name}"
                ),

                depth=(
                    depth + 1
                ),

                seen=seen,
            )

            output.update(
                child
            )

    return output


# ============================================================================
# FILE-72 TRANSPORT PROFILER
# ============================================================================


class TransportProfiler:

    MONITORED = {
        "viscosity",
        "thermal_conductivity",
    }

    def __init__(
        self,
        file72_path: Path,
    ):

        self.target = os.path.normcase(
            os.path.abspath(
                str(
                    file72_path.resolve()
                )
            )
        )

        self.calls = 0

        self.viscosity_calls = 0

        self.conductivity_calls = 0

        self.minimum_temperature = None

        self.maximum_temperature = None

        self.previous_profile = None


    def _extract_temperature(
        self,
        frame,
    ) -> float | None:

        local_values = (
            frame.f_locals
        )

        for name in (
            "T",
            "temperature",
            "temperature_K",
            "T_K",
        ):

            if name not in local_values:

                continue

            value = finite_float(
                local_values[
                    name
                ]
            )

            if value is not None:

                return value

        argument_count = (
            frame.f_code.co_argcount
        )

        names = (
            frame.f_code.co_varnames[
                :argument_count
            ]
        )

        for name in names:

            if name not in local_values:

                continue

            value = finite_float(
                local_values[
                    name
                ]
            )

            if value is not None:

                return value

        return None


    def _profile(
        self,
        frame,
        event,
        arg,
    ):

        if event != "call":

            return

        filename = os.path.normcase(
            os.path.abspath(
                frame.f_code.co_filename
            )
        )

        if filename != self.target:

            return

        function_name = (
            frame.f_code.co_name
        )

        if function_name not in self.MONITORED:

            return

        self.calls += 1

        if function_name == "viscosity":

            self.viscosity_calls += 1

        elif (
            function_name
            == "thermal_conductivity"
        ):

            self.conductivity_calls += 1

        temperature = (
            self._extract_temperature(
                frame
            )
        )

        if temperature is None:

            return

        if (
            self.minimum_temperature
            is None
            or
            temperature
            < self.minimum_temperature
        ):

            self.minimum_temperature = (
                temperature
            )

        if (
            self.maximum_temperature
            is None
            or
            temperature
            > self.maximum_temperature
        ):

            self.maximum_temperature = (
                temperature
            )


    def start(
        self,
    ):

        self.previous_profile = (
            sys.getprofile()
        )

        sys.setprofile(
            self._profile
        )


    def stop(
        self,
    ):

        sys.setprofile(
            self.previous_profile
        )


    def result(
        self,
    ) -> dict[str, object]:

        if (
            self.minimum_temperature
            is None
            or
            self.maximum_temperature
            is None
        ):

            return {

                "transport_calls":
                    self.calls,

                "viscosity_calls":
                    self.viscosity_calls,

                "conductivity_calls":
                    self.conductivity_calls,

                "transport_T_min_K":
                    np.nan,

                "transport_T_max_K":
                    np.nan,

                "transport_lower_margin_K":
                    np.nan,

                "transport_upper_margin_K":
                    np.nan,

                "transport_support_pass":
                    False,
            }

        Tmin = float(
            self.minimum_temperature
        )

        Tmax = float(
            self.maximum_temperature
        )

        return {

            "transport_calls":
                self.calls,

            "viscosity_calls":
                self.viscosity_calls,

            "conductivity_calls":
                self.conductivity_calls,

            "transport_T_min_K":
                Tmin,

            "transport_T_max_K":
                Tmax,

            "transport_lower_margin_K":
                Tmin
                - TRANSPORT_MIN_K,

            "transport_upper_margin_K":
                TRANSPORT_MAX_K
                - Tmax,

            "transport_support_pass":
                bool(
                    Tmin
                    >= TRANSPORT_MIN_K
                    and
                    Tmax
                    <= TRANSPORT_MAX_K
                ),
        }


# ============================================================================
# REACTIVITY FUNCTIONS
# ============================================================================


def waveform_function(
    row: dict[str, str],
) -> Callable[
    [float],
    float,
]:

    waveform = (
        row[
            "waveform"
        ]
        .strip()
        .upper()
    )

    amplitude = float_value(
        row,
        "amplitude_delta_k_over_k",
        0.0,
    )

    onset = float_value(
        row,
        "event_onset_s",
        0.0,
    )

    if waveform == "BASELINE":

        def baseline(
            _t: float,
        ) -> float:

            return 0.0

        return baseline

    if waveform == "STEP_HOLD":

        def step(
            t: float,
        ) -> float:

            if t < onset:

                return 0.0

            return amplitude

        return step

    if waveform == "LINEAR_RAMP_HOLD":

        duration = float_value(
            row,
            "ramp_duration_s",
        )

        completion = (
            onset
            + duration
        )

        def ramp(
            t: float,
        ) -> float:

            if t < onset:

                return 0.0

            if t < completion:

                fraction = (
                    (
                        t
                        - onset
                    )
                    / duration
                )

                return (
                    amplitude
                    * fraction
                )

            return amplitude

        return ramp

    raise ValueError(
        f"Unknown waveform: {waveform}"
    )


def waveform_array(
    row: dict[str, str],
    times: np.ndarray,
) -> np.ndarray:

    function = waveform_function(
        row
    )

    return np.asarray(
        [
            function(
                float(
                    time
                )
            )
            for time
            in times
        ],
        dtype=np.float64,
    )


# ============================================================================
# ODE SEGMENT
# ============================================================================


def solve_segment(
    model,
    y0: np.ndarray,
    start_s: float,
    end_s: float,
    reactivity_function: Callable[
        [float],
        float,
    ],
    max_step_s: float,
):

    if end_s <= start_s:

        return (
            y0.copy(),
            None,
        )

    model.set_external_reactivity(
        reactivity_function
    )

    solution = solve_ivp(
        fun=model.derivatives,

        t_span=(
            start_s,
            end_s,
        ),

        y0=(
            y0.copy()
        ),

        method="BDF",

        rtol=RTOL,

        atol=ATOL,

        max_step=max_step_s,

        dense_output=True,
    )

    if not solution.success:

        raise RuntimeError(
            "ODE segment failed: "
            + str(
                solution.message
            )
        )

    y_end = np.asarray(
        solution.sol(
            end_s
        ),
        dtype=np.float64,
    ).reshape(
        -1
    )

    if not np.all(
        np.isfinite(
            y_end
        )
    ):

        raise RuntimeError(
            "ODE segment ended with non-finite state."
        )

    return (
        y_end,
        solution,
    )


# ============================================================================
# AUXILIARY CYCLE OUTPUTS
# ============================================================================


def evaluate_auxiliary(
    model,
    global_state: np.ndarray,
    auxiliary_names: list[str],
) -> np.ndarray:

    output = np.empty(
        (
            global_state.shape[
                0
            ],
            len(
                auxiliary_names
            ),
        ),
        dtype=np.float64,
    )

    for time_index in range(
        global_state.shape[
            0
        ]
    ):

        bulk_temperature = float(
            global_state[
                time_index,
                9
            ]
        )

        cycle = (
            model.core_cycle_from_bulk(
                bulk_temperature
            )
        )

        flattened = flatten_numeric(
            cycle,
            prefix="cycle",
        )

        for field_index, field in enumerate(
            auxiliary_names
        ):

            if field not in flattened:

                raise RuntimeError(
                    "Required auxiliary cycle field missing: "
                    f"{field}"
                )

            value = float(
                flattened[
                    field
                ]
            )

            if not np.isfinite(
                value
            ):

                raise RuntimeError(
                    "Non-finite auxiliary value: "
                    f"{field}"
                )

            output[
                time_index,
                field_index
            ] = value

    return output


# ============================================================================
# BASELINE
# ============================================================================


def generate_baseline_case(
    master_module,
    reference_state: np.ndarray,
    global_time: np.ndarray,
) -> tuple[
    np.ndarray,
    None,
    None,
    float,
]:

    # ------------------------------------------------------------------
    # Production representation:
    #
    # exact rated equilibrium, repeated on the global grid.
    # ------------------------------------------------------------------

    global_state = np.repeat(
        reference_state[
            None,
            :
        ],
        len(
            global_time
        ),
        axis=0,
    ).astype(
        np.float64
    )

    # ------------------------------------------------------------------
    # Runtime-path probe:
    #
    # Exercise one exact zero-reactivity derivative evaluation so the
    # File-72 runtime transport path is actually tested.
    #
    # This does NOT replace the exact baseline storage with a numerical
    # integration.
    # ------------------------------------------------------------------

    model = (
        master_module
        .MasterCoupledReferenceModel()
    )

    model.set_external_reactivity(
        lambda _t:
            0.0
    )

    derivative = np.asarray(
        model.derivatives(
            0.0,
            reference_state.copy(),
        ),
        dtype=np.float64,
    )

    if not np.all(
        np.isfinite(
            derivative
        )
    ):

        raise RuntimeError(
            "Baseline zero-reactivity derivative "
            "contains non-finite values."
        )

    max_abs_derivative = float(
        np.max(
            np.abs(
                derivative
            )
        )
    )

    return (
        global_state,
        None,
        None,
        max_abs_derivative,
    )


# ============================================================================
# STEP
# ============================================================================


def generate_step_case(
    master_module,
    row: dict[str, str],
    reference_state: np.ndarray,
    global_time: np.ndarray,
    event_relative_time: np.ndarray,
    fast_end_relative_s: float,
    transition_end_relative_s: float,
    fast_dt_s: float,
    transition_dt_s: float,
) -> tuple[
    np.ndarray,
    np.ndarray,
    None,
]:

    onset = float_value(
        row,
        "event_onset_s",
    )

    amplitude = float_value(
        row,
        "amplitude_delta_k_over_k",
    )

    horizon = float(
        global_time[
            -1
        ]
    )

    fast_end = (
        onset
        + fast_end_relative_s
    )

    transition_end = (
        onset
        + transition_end_relative_s
    )

    def hold(
        _t: float,
    ) -> float:

        return amplitude

    model = (
        master_module
        .MasterCoupledReferenceModel()
    )

    # ------------------------------------------------------------------
    # Prompt segment
    # ------------------------------------------------------------------

    (
        y_fast_end,
        fast_solution,
    ) = solve_segment(
        model=model,

        y0=reference_state,

        start_s=onset,

        end_s=fast_end,

        reactivity_function=hold,

        max_step_s=fast_dt_s,
    )

    # ------------------------------------------------------------------
    # Early transition segment
    # ------------------------------------------------------------------

    (
        y_transition_end,
        transition_solution,
    ) = solve_segment(
        model=model,

        y0=y_fast_end,

        start_s=fast_end,

        end_s=transition_end,

        reactivity_function=hold,

        max_step_s=transition_dt_s,
    )

    # ------------------------------------------------------------------
    # Long segment
    # ------------------------------------------------------------------

    (
        _y_final,
        long_solution,
    ) = solve_segment(
        model=model,

        y0=y_transition_end,

        start_s=transition_end,

        end_s=horizon,

        reactivity_function=hold,

        max_step_s=GLOBAL_MAX_STEP_S,
    )

    # ------------------------------------------------------------------
    # Global state
    # ------------------------------------------------------------------

    global_state = np.empty(
        (
            len(
                global_time
            ),
            len(
                reference_state
            ),
        ),
        dtype=np.float64,
    )

    pre_mask = (
        global_time
        <= onset
        + 1.0e-12
    )

    global_state[
        pre_mask,
        :
    ] = (
        reference_state[
            None,
            :
        ]
    )

    fast_mask = (
        (
            global_time
            > onset
            + 1.0e-12
        )
        &
        (
            global_time
            <= fast_end
            + 1.0e-12
        )
    )

    if np.any(
        fast_mask
    ):

        global_state[
            fast_mask,
            :
        ] = np.asarray(
            fast_solution.sol(
                global_time[
                    fast_mask
                ]
            ),
            dtype=np.float64,
        ).T

    transition_mask = (
        (
            global_time
            > fast_end
            + 1.0e-12
        )
        &
        (
            global_time
            <= transition_end
            + 1.0e-12
        )
    )

    if np.any(
        transition_mask
    ):

        global_state[
            transition_mask,
            :
        ] = np.asarray(
            transition_solution.sol(
                global_time[
                    transition_mask
                ]
            ),
            dtype=np.float64,
        ).T

    long_mask = (
        global_time
        > transition_end
        + 1.0e-12
    )

    if np.any(
        long_mask
    ):

        global_state[
            long_mask,
            :
        ] = np.asarray(
            long_solution.sol(
                global_time[
                    long_mask
                ]
            ),
            dtype=np.float64,
        ).T

    # ------------------------------------------------------------------
    # Event-local state
    # ------------------------------------------------------------------

    event_state = np.empty(
        (
            len(
                event_relative_time
            ),
            len(
                reference_state
            ),
        ),
        dtype=np.float64,
    )

    event_zero_mask = np.isclose(
        event_relative_time,
        0.0,
        atol=1.0e-15,
    )

    event_state[
        event_zero_mask,
        :
    ] = (
        reference_state[
            None,
            :
        ]
    )

    event_fast_mask = (
        (
            event_relative_time
            > 0.0
        )
        &
        (
            event_relative_time
            <= fast_end_relative_s
            + 1.0e-12
        )
    )

    if np.any(
        event_fast_mask
    ):

        absolute_time = (
            onset
            + event_relative_time[
                event_fast_mask
            ]
        )

        event_state[
            event_fast_mask,
            :
        ] = np.asarray(
            fast_solution.sol(
                absolute_time
            ),
            dtype=np.float64,
        ).T

    event_transition_mask = (
        event_relative_time
        > fast_end_relative_s
        + 1.0e-12
    )

    if np.any(
        event_transition_mask
    ):

        absolute_time = (
            onset
            + event_relative_time[
                event_transition_mask
            ]
        )

        event_state[
            event_transition_mask,
            :
        ] = np.asarray(
            transition_solution.sol(
                absolute_time
            ),
            dtype=np.float64,
        ).T

    if not np.all(
        np.isfinite(
            global_state
        )
    ):

        raise RuntimeError(
            "STEP global trajectory contains non-finite state."
        )

    if not np.all(
        np.isfinite(
            event_state
        )
    ):

        raise RuntimeError(
            "STEP event-local trajectory contains non-finite state."
        )

    return (
        global_state,
        event_state,
        None,
    )


# ============================================================================
# RAMP
# ============================================================================


def generate_ramp_case(
    master_module,
    row: dict[str, str],
    reference_state: np.ndarray,
    global_time: np.ndarray,
) -> tuple[
    np.ndarray,
    None,
    tuple[
        np.ndarray,
        np.ndarray,
    ],
]:

    onset = float_value(
        row,
        "event_onset_s",
    )

    duration = float_value(
        row,
        "ramp_duration_s",
    )

    amplitude = float_value(
        row,
        "amplitude_delta_k_over_k",
    )

    completion = (
        onset
        + duration
    )

    horizon = float(
        global_time[
            -1
        ]
    )

    def ramp(
        t: float,
    ) -> float:

        fraction = (
            (
                t
                - onset
            )
            / duration
        )

        fraction = min(
            1.0,
            max(
                0.0,
                fraction,
            ),
        )

        return (
            amplitude
            * fraction
        )

    def hold(
        _t: float,
    ) -> float:

        return amplitude

    model = (
        master_module
        .MasterCoupledReferenceModel()
    )

    (
        y_completion,
        ramp_solution,
    ) = solve_segment(
        model=model,

        y0=reference_state,

        start_s=onset,

        end_s=completion,

        reactivity_function=ramp,

        max_step_s=GLOBAL_MAX_STEP_S,
    )

    (
        _y_final,
        hold_solution,
    ) = solve_segment(
        model=model,

        y0=y_completion,

        start_s=completion,

        end_s=horizon,

        reactivity_function=hold,

        max_step_s=GLOBAL_MAX_STEP_S,
    )

    global_state = np.empty(
        (
            len(
                global_time
            ),
            len(
                reference_state
            ),
        ),
        dtype=np.float64,
    )

    pre_mask = (
        global_time
        <= onset
        + 1.0e-12
    )

    global_state[
        pre_mask,
        :
    ] = (
        reference_state[
            None,
            :
        ]
    )

    ramp_mask = (
        (
            global_time
            > onset
            + 1.0e-12
        )
        &
        (
            global_time
            <= completion
            + 1.0e-12
        )
    )

    if np.any(
        ramp_mask
    ):

        global_state[
            ramp_mask,
            :
        ] = np.asarray(
            ramp_solution.sol(
                global_time[
                    ramp_mask
                ]
            ),
            dtype=np.float64,
        ).T

    hold_mask = (
        global_time
        > completion
        + 1.0e-12
    )

    if np.any(
        hold_mask
    ):

        global_state[
            hold_mask,
            :
        ] = np.asarray(
            hold_solution.sol(
                global_time[
                    hold_mask
                ]
            ),
            dtype=np.float64,
        ).T

    anchor_times = np.asarray(
        [
            onset,
            completion,
        ],
        dtype=np.float64,
    )

    anchor_states = np.vstack(
        (
            reference_state,
            y_completion,
        )
    ).astype(
        np.float64
    )

    if not np.all(
        np.isfinite(
            global_state
        )
    ):

        raise RuntimeError(
            "RAMP global trajectory contains non-finite state."
        )

    if not np.all(
        np.isfinite(
            anchor_states
        )
    ):

        raise RuntimeError(
            "RAMP anchor state contains non-finite value."
        )

    return (
        global_state,
        None,
        (
            anchor_times,
            anchor_states,
        ),
    )


# ============================================================================
# SMOKE CASE SELECTION
# ============================================================================


def select_first(
    manifest: list[dict[str, str]],
    *,
    partition: str,
    waveform: str,
    regime: str | None = None,
    amplitude: float | None = None,
) -> dict[str, str]:

    for row in manifest:

        if (
            row[
                "partition"
            ]
            != partition
        ):

            continue

        if (
            row[
                "waveform"
            ]
            != waveform
        ):

            continue

        if (
            regime is not None
            and
            row[
                "regime"
            ]
            != regime
        ):

            continue

        if amplitude is not None:

            if not np.isclose(
                float(
                    row[
                        "amplitude_cents"
                    ]
                ),
                amplitude,
            ):

                continue

        return row

    raise RuntimeError(
        "Could not find smoke-test case: "
        f"partition={partition}, "
        f"regime={regime}, "
        f"waveform={waveform}, "
        f"amplitude={amplitude}"
    )


def select_smoke_cases(
    manifest: list[dict[str, str]],
) -> list[dict[str, str]]:

    baseline = None

    for row in manifest:

        if (
            row[
                "regime"
            ]
            == "BASELINE"
        ):

            baseline = row

            break

    if baseline is None:

        raise RuntimeError(
            "Production baseline case not found."
        )

    selected = [

        baseline,

        select_first(
            manifest,
            partition="TRAIN",
            regime="ID",
            waveform="STEP_HOLD",
        ),

        select_first(
            manifest,
            partition="TRAIN",
            regime="ID",
            waveform="LINEAR_RAMP_HOLD",
        ),

        select_first(
            manifest,
            partition="VALIDATION",
            regime="ID",
            waveform="STEP_HOLD",
        ),

        select_first(
            manifest,
            partition="ID_TEST",
            regime="ID",
            waveform="LINEAR_RAMP_HOLD",
        ),

        select_first(
            manifest,
            partition="OOD_NEG_TEST",
            regime="OOD_NEGATIVE",
            waveform="STEP_HOLD",
        ),

        select_first(
            manifest,
            partition="OOD_NEG_TEST",
            regime="OOD_NEGATIVE",
            waveform="LINEAR_RAMP_HOLD",
        ),

        select_first(
            manifest,
            partition="OOD_POS_TEST",
            regime="OOD_POSITIVE",
            waveform="STEP_HOLD",
        ),

        select_first(
            manifest,
            partition="OOD_POS_TEST",
            regime="OOD_POSITIVE",
            waveform="LINEAR_RAMP_HOLD",
        ),

        select_first(
            manifest,
            partition="STRESS_TEST",
            regime="STRESS",
            waveform="STEP_HOLD",
            amplitude=-30.0,
        ),

        select_first(
            manifest,
            partition="STRESS_TEST",
            regime="STRESS",
            waveform="LINEAR_RAMP_HOLD",
            amplitude=+17.5,
        ),
    ]

    case_ids = [
        row[
            "case_id"
        ]
        for row
        in selected
    ]

    if (
        len(
            case_ids
        )
        != len(
            set(
                case_ids
            )
        )
    ):

        raise RuntimeError(
            "Smoke-test selector produced duplicate cases."
        )

    return selected


# ============================================================================
# CASE EXECUTION
# ============================================================================


def execute_case(
    master_module,
    file72_path: Path,
    row: dict[str, str],
    reference_state: np.ndarray,
    global_time: np.ndarray,
    event_relative_time: np.ndarray,
    auxiliary_names: list[str],
    fast_end_relative_s: float,
    transition_end_relative_s: float,
    fast_dt_s: float,
    transition_dt_s: float,
) -> dict[str, Any]:

    result: dict[
        str,
        Any,
    ] = {

        "case_id":
            row[
                "case_id"
            ],

        "partition":
            row[
                "partition"
            ],

        "regime":
            row[
                "regime"
            ],

        "waveform":
            row[
                "waveform"
            ],

        "amplitude_cents":
            float_value(
                row,
                "amplitude_cents",
                0.0,
            ),

        "success":
            False,

        "exception":
            "",
    }

    profiler = (
        TransportProfiler(
            file72_path
        )
    )

    try:

        profiler.start()

        waveform = (
            row[
                "waveform"
            ]
            .strip()
            .upper()
        )

        baseline_max_abs_derivative = np.nan

        if waveform == "BASELINE":

            (
                global_state,
                event_state,
                ramp_anchor,
                baseline_max_abs_derivative,
            ) = generate_baseline_case(
                master_module=master_module,

                reference_state=reference_state,

                global_time=global_time,
            )

        elif waveform == "STEP_HOLD":

            (
                global_state,
                event_state,
                ramp_anchor,
            ) = generate_step_case(
                master_module=master_module,

                row=row,

                reference_state=reference_state,

                global_time=global_time,

                event_relative_time=event_relative_time,

                fast_end_relative_s=fast_end_relative_s,

                transition_end_relative_s=transition_end_relative_s,

                fast_dt_s=fast_dt_s,

                transition_dt_s=transition_dt_s,
            )

        elif (
            waveform
            == "LINEAR_RAMP_HOLD"
        ):

            (
                global_state,
                event_state,
                ramp_anchor,
            ) = generate_ramp_case(
                master_module=master_module,

                row=row,

                reference_state=reference_state,

                global_time=global_time,
            )

        else:

            raise RuntimeError(
                f"Unsupported waveform: {waveform}"
            )

        # --------------------------------------------------------------
        # Auxiliary outputs
        # --------------------------------------------------------------

        auxiliary_model = (
            master_module
            .MasterCoupledReferenceModel()
        )

        global_auxiliary = (
            evaluate_auxiliary(
                model=auxiliary_model,

                global_state=global_state,

                auxiliary_names=auxiliary_names,
            )
        )

        profiler.stop()

        transport = (
            profiler.result()
        )

        result.update(
            transport
        )

        if not transport[
            "transport_support_pass"
        ]:

            raise RuntimeError(
                "Actual File-72 transport call left "
                "the frozen 400-1200 K domain."
            )

        # --------------------------------------------------------------
        # Inputs
        # --------------------------------------------------------------

        global_reactivity = (
            waveform_array(
                row,
                global_time,
            )
        )

        if waveform == "STEP_HOLD":

            amplitude = float_value(
                row,
                "amplitude_delta_k_over_k",
            )

            event_reactivity = np.full(
                len(
                    event_relative_time
                ),
                amplitude,
                dtype=np.float64,
            )

        else:

            event_reactivity = None

        if waveform == "LINEAR_RAMP_HOLD":

            (
                anchor_times,
                anchor_states,
            ) = ramp_anchor

            anchor_reactivity = (
                waveform_array(
                    row,
                    anchor_times,
                )
            )

        else:

            anchor_times = None
            anchor_states = None
            anchor_reactivity = None

        # --------------------------------------------------------------
        # Finite checks
        # --------------------------------------------------------------

        if not np.all(
            np.isfinite(
                global_state
            )
        ):

            raise RuntimeError(
                "Non-finite global state."
            )

        if not np.all(
            np.isfinite(
                global_reactivity
            )
        ):

            raise RuntimeError(
                "Non-finite global reactivity."
            )

        if not np.all(
            np.isfinite(
                global_auxiliary
            )
        ):

            raise RuntimeError(
                "Non-finite auxiliary output."
            )

        if (
            event_state is not None
            and
            not np.all(
                np.isfinite(
                    event_state
                )
            )
        ):

            raise RuntimeError(
                "Non-finite STEP event-local state."
            )

        # --------------------------------------------------------------
        # Initial-state consistency
        # --------------------------------------------------------------

        initial_error = float(
            np.max(
                np.abs(
                    global_state[
                        0,
                        :
                    ]
                    -
                    reference_state
                )
            )
        )

        if initial_error > 1.0e-10:

            raise RuntimeError(
                "Global trajectory does not begin "
                "from frozen rated reference state."
            )

        if event_state is not None:

            event_initial_error = float(
                np.max(
                    np.abs(
                        event_state[
                            0,
                            :
                        ]
                        -
                        reference_state
                    )
                )
            )

            if (
                event_initial_error
                > 1.0e-10
            ):

                raise RuntimeError(
                    "STEP event-local trajectory does not "
                    "begin at rated pre-event state."
                )

        else:

            event_initial_error = np.nan

        # --------------------------------------------------------------
        # Metrics
        # --------------------------------------------------------------

        result[
            "baseline_max_abs_derivative"
        ] = (
            baseline_max_abs_derivative
        )

        result[
            "power_min"
        ] = float(
            np.min(
                global_state[
                    :,
                    0
                ]
            )
        )

        result[
            "power_max"
        ] = float(
            np.max(
                global_state[
                    :,
                    0
                ]
            )
        )

        result[
            "fuel_T_min_K"
        ] = float(
            np.min(
                global_state[
                    :,
                    7
                ]
            )
        )

        result[
            "fuel_T_max_K"
        ] = float(
            np.max(
                global_state[
                    :,
                    7
                ]
            )
        )

        result[
            "bulk_T_min_K"
        ] = float(
            np.min(
                global_state[
                    :,
                    9
                ]
            )
        )

        result[
            "bulk_T_max_K"
        ] = float(
            np.max(
                global_state[
                    :,
                    9
                ]
            )
        )

        result[
            "initial_state_error"
        ] = (
            initial_error
        )

        result[
            "event_initial_state_error"
        ] = (
            event_initial_error
        )

        result[
            "global_state"
        ] = (
            global_state
        )

        result[
            "global_reactivity"
        ] = (
            global_reactivity
        )

        result[
            "global_auxiliary"
        ] = (
            global_auxiliary
        )

        result[
            "event_state"
        ] = (
            event_state
        )

        result[
            "event_reactivity"
        ] = (
            event_reactivity
        )

        result[
            "ramp_anchor_times"
        ] = (
            anchor_times
        )

        result[
            "ramp_anchor_states"
        ] = (
            anchor_states
        )

        result[
            "ramp_anchor_reactivity"
        ] = (
            anchor_reactivity
        )

        result[
            "success"
        ] = True

        return result

    except Exception as exc:

        try:

            profiler.stop()

        except Exception:

            pass

        result.update(
            profiler.result()
        )

        result[
            "exception"
        ] = (
            f"{type(exc).__name__}: "
            f"{exc}"
        )

        result[
            "traceback"
        ] = (
            traceback.format_exc()
        )

        return result


# ============================================================================
# SUMMARY FILTER
# ============================================================================


def scalar_summary(
    result: dict[str, Any],
) -> dict[str, object]:

    excluded = {
        "global_state",
        "global_reactivity",
        "global_auxiliary",
        "event_state",
        "event_reactivity",
        "ramp_anchor_times",
        "ramp_anchor_states",
        "ramp_anchor_reactivity",
        "traceback",
    }

    return {
        key:
            value
        for key, value
        in result.items()
        if key not in excluded
    }


# ============================================================================
# MAIN
# ============================================================================


def main() -> None:

    root = Path(
        __file__
    ).resolve().parent

    if str(
        root
    ) not in sys.path:

        sys.path.insert(
            0,
            str(
                root
            ),
        )

    dataset_root = (
        root
        / DATASET_DIRECTORY
    )

    smoke_root = (
        dataset_root
        / SMOKE_DIRECTORY
    )

    smoke_root.mkdir(
        parents=True,
        exist_ok=True,
    )

    # ----------------------------------------------------------------------
    # Sources
    # ----------------------------------------------------------------------

    file72_path = require_file(
        root
        / FILE72
    )

    file74_path = require_file(
        root
        / FILE74
    )

    contract166_path = require_file(
        dataset_root
        / FILE166_CONTRACT
    )

    manifest172_path = require_file(
        dataset_root
        / FILE172_MANIFEST
    )

    contract172_path = require_file(
        dataset_root
        / FILE172_CONTRACT
    )

    # ----------------------------------------------------------------------
    # Contracts
    # ----------------------------------------------------------------------

    with contract166_path.open(
        "r",
        encoding="utf-8",
    ) as f:

        contract166 = json.load(
            f
        )

    with contract172_path.open(
        "r",
        encoding="utf-8",
    ) as f:

        contract172 = json.load(
            f
        )

    # ----------------------------------------------------------------------
    # Hash gates
    # ----------------------------------------------------------------------

    expected_manifest_hash = (
        contract172[
            "manifest_sha256"
        ]
    )

    actual_manifest_hash = (
        sha256_file(
            manifest172_path
        )
    )

    if (
        expected_manifest_hash
        != actual_manifest_hash
    ):

        raise RuntimeError(
            "File-172 production manifest hash changed."
        )

    expected_solver_hash = (
        contract166[
            "reference_solver_sha256"
        ]
    )

    actual_solver_hash = (
        sha256_file(
            file74_path
        )
    )

    if (
        expected_solver_hash
        != actual_solver_hash
    ):

        raise RuntimeError(
            "File 74 changed after frozen "
            "reference-model contract."
        )

    # ----------------------------------------------------------------------
    # Schemas
    # ----------------------------------------------------------------------

    state_names = list(
        contract172[
            "primary_pino_targets"
        ][
            "fields"
        ]
    )

    auxiliary_names = list(
        contract172[
            "auxiliary_cycle_outputs"
        ][
            "fields"
        ]
    )

    if len(
        state_names
    ) != 10:

        raise RuntimeError(
            "Expected 10 primary state targets."
        )

    if len(
        auxiliary_names
    ) != 9:

        raise RuntimeError(
            "Expected 9 varying auxiliary fields."
        )

    # ----------------------------------------------------------------------
    # Temporal representation
    # ----------------------------------------------------------------------

    temporal = (
        contract172[
            "temporal_representation"
        ]
    )

    global_info = (
        temporal[
            "global_view"
        ]
    )

    event_info = (
        temporal[
            "step_event_local_view"
        ]
    )

    global_time = np.linspace(
        float(
            global_info[
                "time_start_s"
            ]
        ),
        float(
            global_info[
                "time_end_s"
            ]
        ),
        int(
            global_info[
                "points"
            ]
        ),
        dtype=np.float64,
    )

    event_relative_time = np.asarray(
        event_info[
            "time_vector_s"
        ],
        dtype=np.float64,
    )

    global_points = len(
        global_time
    )

    event_points = len(
        event_relative_time
    )

    if global_points != 601:

        raise RuntimeError(
            "Expected 601 global points."
        )

    if event_points != 1021:

        raise RuntimeError(
            "Expected 1021 event-local points."
        )

    fast_dt_s = float(
        event_info[
            "fast_region"
        ][
            "dt_s"
        ]
    )

    fast_end_relative_s = float(
        event_info[
            "fast_region"
        ][
            "end_s"
        ]
    )

    transition_dt_s = float(
        event_info[
            "transition_region"
        ][
            "dt_s"
        ]
    )

    transition_end_relative_s = float(
        event_info[
            "transition_region"
        ][
            "end_s"
        ]
    )

    # ----------------------------------------------------------------------
    # Manifest
    # ----------------------------------------------------------------------

    production_manifest = (
        read_csv(
            manifest172_path
        )
    )

    if len(
        production_manifest
    ) != int(
        contract172[
            "production_case_count"
        ]
    ):

        raise RuntimeError(
            "Production manifest count changed."
        )

    selected = select_smoke_cases(
        production_manifest
    )

    selected_manifest_path = (
        smoke_root
        / SELECTED_MANIFEST_NAME
    )

    write_csv(
        selected_manifest_path,
        selected,
    )

    # ----------------------------------------------------------------------
    # Mappings
    # ----------------------------------------------------------------------

    step_case_indices = np.asarray(
        [
            index
            for index, row
            in enumerate(
                selected
            )
            if row[
                "waveform"
            ]
            == "STEP_HOLD"
        ],
        dtype=np.int64,
    )

    ramp_case_indices = np.asarray(
        [
            index
            for index, row
            in enumerate(
                selected
            )
            if row[
                "waveform"
            ]
            == "LINEAR_RAMP_HOLD"
        ],
        dtype=np.int64,
    )

    number_cases = len(
        selected
    )

    number_steps = len(
        step_case_indices
    )

    number_ramps = len(
        ramp_case_indices
    )

    # ----------------------------------------------------------------------
    # Reference model
    # ----------------------------------------------------------------------

    master = load_module_from_file(
        "_file173_master",
        file74_path,
    )

    baseline_model = (
        master
        .MasterCoupledReferenceModel()
    )

    reference_state = np.asarray(
        baseline_model
        .reference_state(),
        dtype=np.float64,
    )

    if reference_state.size != 10:

        raise RuntimeError(
            "File-74 reference-state size changed."
        )

    if not np.all(
        np.isfinite(
            reference_state
        )
    ):

        raise RuntimeError(
            "Reference state contains non-finite values."
        )

    # ======================================================================
    # PRODUCTION-STYLE ARRAYS
    # ======================================================================

    global_state_path = (
        smoke_root
        / "global_state.npy"
    )

    global_reactivity_path = (
        smoke_root
        / "global_reactivity_delta_k_over_k.npy"
    )

    global_auxiliary_path = (
        smoke_root
        / "global_auxiliary_cycle.npy"
    )

    step_event_state_path = (
        smoke_root
        / "step_event_state.npy"
    )

    step_event_reactivity_path = (
        smoke_root
        / "step_event_reactivity_delta_k_over_k.npy"
    )

    ramp_anchor_time_path = (
        smoke_root
        / "ramp_anchor_time_s.npy"
    )

    ramp_anchor_state_path = (
        smoke_root
        / "ramp_anchor_state.npy"
    )

    ramp_anchor_reactivity_path = (
        smoke_root
        / "ramp_anchor_reactivity_delta_k_over_k.npy"
    )

    global_state_mm = np.lib.format.open_memmap(
        global_state_path,
        mode="w+",
        dtype=np.float64,
        shape=(
            number_cases,
            global_points,
            len(
                state_names
            ),
        ),
    )

    global_reactivity_mm = np.lib.format.open_memmap(
        global_reactivity_path,
        mode="w+",
        dtype=np.float64,
        shape=(
            number_cases,
            global_points,
        ),
    )

    global_auxiliary_mm = np.lib.format.open_memmap(
        global_auxiliary_path,
        mode="w+",
        dtype=np.float64,
        shape=(
            number_cases,
            global_points,
            len(
                auxiliary_names
            ),
        ),
    )

    step_event_state_mm = np.lib.format.open_memmap(
        step_event_state_path,
        mode="w+",
        dtype=np.float64,
        shape=(
            number_steps,
            event_points,
            len(
                state_names
            ),
        ),
    )

    step_event_reactivity_mm = np.lib.format.open_memmap(
        step_event_reactivity_path,
        mode="w+",
        dtype=np.float64,
        shape=(
            number_steps,
            event_points,
        ),
    )

    ramp_anchor_time_mm = np.lib.format.open_memmap(
        ramp_anchor_time_path,
        mode="w+",
        dtype=np.float64,
        shape=(
            number_ramps,
            2,
        ),
    )

    ramp_anchor_state_mm = np.lib.format.open_memmap(
        ramp_anchor_state_path,
        mode="w+",
        dtype=np.float64,
        shape=(
            number_ramps,
            2,
            len(
                state_names
            ),
        ),
    )

    ramp_anchor_reactivity_mm = np.lib.format.open_memmap(
        ramp_anchor_reactivity_path,
        mode="w+",
        dtype=np.float64,
        shape=(
            number_ramps,
            2,
        ),
    )

    global_state_mm[:] = np.nan
    global_reactivity_mm[:] = np.nan
    global_auxiliary_mm[:] = np.nan

    step_event_state_mm[:] = np.nan
    step_event_reactivity_mm[:] = np.nan

    ramp_anchor_time_mm[:] = np.nan
    ramp_anchor_state_mm[:] = np.nan
    ramp_anchor_reactivity_mm[:] = np.nan

    # ----------------------------------------------------------------------
    # Metadata arrays
    # ----------------------------------------------------------------------

    np.save(
        smoke_root
        / "global_time_s.npy",
        global_time,
    )

    np.save(
        smoke_root
        / "step_event_relative_time_s.npy",
        event_relative_time,
    )

    np.save(
        smoke_root
        / "reference_state.npy",
        reference_state,
    )

    np.save(
        smoke_root
        / "step_case_indices.npy",
        step_case_indices,
    )

    np.save(
        smoke_root
        / "ramp_case_indices.npy",
        ramp_case_indices,
    )

    np.save(
        smoke_root
        / "case_ids.npy",
        np.asarray(
            [
                row[
                    "case_id"
                ]
                for row
                in selected
            ],
            dtype="U32",
        ),
    )

    np.save(
        smoke_root
        / "state_names.npy",
        np.asarray(
            state_names,
            dtype="U128",
        ),
    )

    np.save(
        smoke_root
        / "auxiliary_names.npy",
        np.asarray(
            auxiliary_names,
            dtype="U256",
        ),
    )

    # ----------------------------------------------------------------------
    # Header
    # ----------------------------------------------------------------------

    print(
        "=" * 78
    )

    print(
        "STEP 6 - PRODUCTION-FORMAT "
        "GENERATOR SMOKE TEST"
    )

    print(
        "=" * 78
    )

    print()

    print(
        f"Production manifest cases : "
        f"{len(production_manifest)}"
    )

    print(
        f"Smoke cases               : "
        f"{number_cases}"
    )

    print(
        f"STEP smoke cases          : "
        f"{number_steps}"
    )

    print(
        f"RAMP smoke cases          : "
        f"{number_ramps}"
    )

    print()

    print(
        f"Global points/case        : "
        f"{global_points}"
    )

    print(
        f"STEP event points/case    : "
        f"{event_points}"
    )

    print(
        f"Primary state variables   : "
        f"{len(state_names)}"
    )

    print(
        f"Auxiliary cycle fields    : "
        f"{len(auxiliary_names)}"
    )

    print()

    # ======================================================================
    # EXECUTION
    # ======================================================================

    summaries = []

    results = []

    step_storage_index = 0

    ramp_storage_index = 0

    for case_index, row in enumerate(
        selected
    ):

        print(
            f"[{case_index + 1:02d}/"
            f"{number_cases:02d}] "
            f"{row['case_id']} | "
            f"{row['partition']:<12s} | "
            f"{row['regime']:<12s} | "
            f"{row['waveform']:<18s} | "
            f"{float(row['amplitude_cents']):+8.4f} cents",
            end="",
            flush=True,
        )

        result = execute_case(
            master_module=master,

            file72_path=file72_path,

            row=row,

            reference_state=reference_state,

            global_time=global_time,

            event_relative_time=event_relative_time,

            auxiliary_names=auxiliary_names,

            fast_end_relative_s=fast_end_relative_s,

            transition_end_relative_s=transition_end_relative_s,

            fast_dt_s=fast_dt_s,

            transition_dt_s=transition_dt_s,
        )

        results.append(
            result
        )

        summaries.append(
            scalar_summary(
                result
            )
        )

        if not result[
            "success"
        ]:

            print(
                "  FAIL"
            )

            print(
                "       "
                + str(
                    result[
                        "exception"
                    ]
                )
            )

            continue

        # --------------------------------------------------------------
        # Global
        # --------------------------------------------------------------

        global_state_mm[
            case_index,
            :,
            :
        ] = result[
            "global_state"
        ]

        global_reactivity_mm[
            case_index,
            :
        ] = result[
            "global_reactivity"
        ]

        global_auxiliary_mm[
            case_index,
            :,
            :
        ] = result[
            "global_auxiliary"
        ]

        # --------------------------------------------------------------
        # STEP
        # --------------------------------------------------------------

        if (
            row[
                "waveform"
            ]
            == "STEP_HOLD"
        ):

            step_event_state_mm[
                step_storage_index,
                :,
                :
            ] = result[
                "event_state"
            ]

            step_event_reactivity_mm[
                step_storage_index,
                :
            ] = result[
                "event_reactivity"
            ]

            step_storage_index += 1

        # --------------------------------------------------------------
        # RAMP
        # --------------------------------------------------------------

        elif (
            row[
                "waveform"
            ]
            == "LINEAR_RAMP_HOLD"
        ):

            ramp_anchor_time_mm[
                ramp_storage_index,
                :
            ] = result[
                "ramp_anchor_times"
            ]

            ramp_anchor_state_mm[
                ramp_storage_index,
                :,
                :
            ] = result[
                "ramp_anchor_states"
            ]

            ramp_anchor_reactivity_mm[
                ramp_storage_index,
                :
            ] = result[
                "ramp_anchor_reactivity"
            ]

            ramp_storage_index += 1

        # --------------------------------------------------------------
        # Flush
        # --------------------------------------------------------------

        global_state_mm.flush()
        global_reactivity_mm.flush()
        global_auxiliary_mm.flush()

        step_event_state_mm.flush()
        step_event_reactivity_mm.flush()

        ramp_anchor_time_mm.flush()
        ramp_anchor_state_mm.flush()
        ramp_anchor_reactivity_mm.flush()

        print(
            "  PASS"
        )

    # ======================================================================
    # SUMMARY CSV
    # ======================================================================

    summary_path = (
        smoke_root
        / SUMMARY_CSV_NAME
    )

    write_csv(
        summary_path,
        summaries,
    )

    # ======================================================================
    # REOPEN DISK ARRAYS
    # ======================================================================

    del global_state_mm
    del global_reactivity_mm
    del global_auxiliary_mm
    del step_event_state_mm
    del step_event_reactivity_mm
    del ramp_anchor_time_mm
    del ramp_anchor_state_mm
    del ramp_anchor_reactivity_mm

    global_state_disk = np.load(
        global_state_path,
        mmap_mode="r",
        allow_pickle=False,
    )

    global_reactivity_disk = np.load(
        global_reactivity_path,
        mmap_mode="r",
        allow_pickle=False,
    )

    global_auxiliary_disk = np.load(
        global_auxiliary_path,
        mmap_mode="r",
        allow_pickle=False,
    )

    step_event_state_disk = np.load(
        step_event_state_path,
        mmap_mode="r",
        allow_pickle=False,
    )

    step_event_reactivity_disk = np.load(
        step_event_reactivity_path,
        mmap_mode="r",
        allow_pickle=False,
    )

    ramp_anchor_time_disk = np.load(
        ramp_anchor_time_path,
        mmap_mode="r",
        allow_pickle=False,
    )

    ramp_anchor_state_disk = np.load(
        ramp_anchor_state_path,
        mmap_mode="r",
        allow_pickle=False,
    )

    ramp_anchor_reactivity_disk = np.load(
        ramp_anchor_reactivity_path,
        mmap_mode="r",
        allow_pickle=False,
    )

    successful_count = sum(
        1
        for result in results
        if result[
            "success"
        ]
    )

    failed_count = (
        number_cases
        - successful_count
    )

    execution_pass = (
        successful_count
        == number_cases
    )

    # ----------------------------------------------------------------------
    # Shapes
    # ----------------------------------------------------------------------

    shape_checks = {

        "global_state":
            (
                global_state_disk.shape
                ==
                (
                    number_cases,
                    global_points,
                    10,
                )
            ),

        "global_reactivity":
            (
                global_reactivity_disk.shape
                ==
                (
                    number_cases,
                    global_points,
                )
            ),

        "global_auxiliary":
            (
                global_auxiliary_disk.shape
                ==
                (
                    number_cases,
                    global_points,
                    9,
                )
            ),

        "step_event_state":
            (
                step_event_state_disk.shape
                ==
                (
                    number_steps,
                    event_points,
                    10,
                )
            ),

        "step_event_reactivity":
            (
                step_event_reactivity_disk.shape
                ==
                (
                    number_steps,
                    event_points,
                )
            ),

        "ramp_anchor_time":
            (
                ramp_anchor_time_disk.shape
                ==
                (
                    number_ramps,
                    2,
                )
            ),

        "ramp_anchor_state":
            (
                ramp_anchor_state_disk.shape
                ==
                (
                    number_ramps,
                    2,
                    10,
                )
            ),

        "ramp_anchor_reactivity":
            (
                ramp_anchor_reactivity_disk.shape
                ==
                (
                    number_ramps,
                    2,
                )
            ),
    }

    shape_pass = all(
        shape_checks.values()
    )

    # ----------------------------------------------------------------------
    # Finite
    # ----------------------------------------------------------------------

    finite_checks = {

        "global_state":
            bool(
                np.all(
                    np.isfinite(
                        global_state_disk
                    )
                )
            ),

        "global_reactivity":
            bool(
                np.all(
                    np.isfinite(
                        global_reactivity_disk
                    )
                )
            ),

        "global_auxiliary":
            bool(
                np.all(
                    np.isfinite(
                        global_auxiliary_disk
                    )
                )
            ),

        "step_event_state":
            bool(
                np.all(
                    np.isfinite(
                        step_event_state_disk
                    )
                )
            ),

        "step_event_reactivity":
            bool(
                np.all(
                    np.isfinite(
                        step_event_reactivity_disk
                    )
                )
            ),

        "ramp_anchor_time":
            bool(
                np.all(
                    np.isfinite(
                        ramp_anchor_time_disk
                    )
                )
            ),

        "ramp_anchor_state":
            bool(
                np.all(
                    np.isfinite(
                        ramp_anchor_state_disk
                    )
                )
            ),

        "ramp_anchor_reactivity":
            bool(
                np.all(
                    np.isfinite(
                        ramp_anchor_reactivity_disk
                    )
                )
            ),
    }

    finite_pass = all(
        finite_checks.values()
    )

    # ----------------------------------------------------------------------
    # Baseline
    # ----------------------------------------------------------------------

    baseline_index = None

    baseline_result = None

    for index, row in enumerate(
        selected
    ):

        if (
            row[
                "regime"
            ]
            == "BASELINE"
        ):

            baseline_index = index
            baseline_result = results[
                index
            ]

            break

    if (
        baseline_index is None
        or
        baseline_result is None
    ):

        raise RuntimeError(
            "Smoke baseline disappeared."
        )

    baseline_drift = float(
        np.max(
            np.abs(
                global_state_disk[
                    baseline_index,
                    :,
                    :
                ]
                -
                reference_state[
                    None,
                    :
                ]
            )
        )
    )

    baseline_pass = bool(
        baseline_result[
            "success"
        ]
        and
        baseline_drift
        <= 1.0e-10
    )

    # ----------------------------------------------------------------------
    # Initial states
    # ----------------------------------------------------------------------

    all_initial_error = float(
        np.max(
            np.abs(
                global_state_disk[
                    :,
                    0,
                    :
                ]
                -
                reference_state[
                    None,
                    :
                ]
            )
        )
    )

    initial_pass = bool(
        all_initial_error
        <= 1.0e-10
    )

    step_event_initial_error = float(
        np.max(
            np.abs(
                step_event_state_disk[
                    :,
                    0,
                    :
                ]
                -
                reference_state[
                    None,
                    :
                ]
            )
        )
    )

    step_event_initial_pass = bool(
        step_event_initial_error
        <= 1.0e-10
    )

    ramp_onset_error = float(
        np.max(
            np.abs(
                ramp_anchor_state_disk[
                    :,
                    0,
                    :
                ]
                -
                reference_state[
                    None,
                    :
                ]
            )
        )
    )

    ramp_anchor_pass = bool(
        ramp_onset_error
        <= 1.0e-10
    )

    # ----------------------------------------------------------------------
    # Transport
    # ----------------------------------------------------------------------

    successful_results = [
        result
        for result in results
        if result[
            "success"
        ]
    ]

    all_transport_pass = bool(
        len(
            successful_results
        )
        == number_cases
        and
        all(
            result.get(
                "transport_support_pass",
                False,
            )
            for result
            in successful_results
        )
    )

    if successful_results:

        transport_min = min(
            float(
                result[
                    "transport_T_min_K"
                ]
            )
            for result
            in successful_results
        )

        transport_max = max(
            float(
                result[
                    "transport_T_max_K"
                ]
            )
            for result
            in successful_results
        )

        transport_upper_margin = min(
            float(
                result[
                    "transport_upper_margin_K"
                ]
            )
            for result
            in successful_results
        )

    else:

        transport_min = np.nan
        transport_max = np.nan
        transport_upper_margin = np.nan

    # ----------------------------------------------------------------------
    # Mappings
    # ----------------------------------------------------------------------

    mapping_pass = bool(
        step_storage_index
        == number_steps
        and
        ramp_storage_index
        == number_ramps
    )

    # ----------------------------------------------------------------------
    # Gate
    # ----------------------------------------------------------------------

    smoke_pass = all(
        (
            execution_pass,
            shape_pass,
            finite_pass,
            baseline_pass,
            initial_pass,
            step_event_initial_pass,
            ramp_anchor_pass,
            all_transport_pass,
            mapping_pass,
        )
    )

    # ======================================================================
    # HASHES
    # ======================================================================

    generated_files = (

        global_state_path,
        global_reactivity_path,
        global_auxiliary_path,

        step_event_state_path,
        step_event_reactivity_path,

        ramp_anchor_time_path,
        ramp_anchor_state_path,
        ramp_anchor_reactivity_path,

        smoke_root
        / "global_time_s.npy",

        smoke_root
        / "step_event_relative_time_s.npy",

        smoke_root
        / "reference_state.npy",

        smoke_root
        / "step_case_indices.npy",

        smoke_root
        / "ramp_case_indices.npy",

        smoke_root
        / "case_ids.npy",

        smoke_root
        / "state_names.npy",

        smoke_root
        / "auxiliary_names.npy",
    )

    hashes = {
        path.name:
            sha256_file(
                path
            )
        for path
        in generated_files
    }

    # ======================================================================
    # METADATA
    # ======================================================================

    metadata = {

        "status":
            (
                "PASS"
                if smoke_pass
                else "FAIL"
            ),

        "production_manifest_sha256":
            actual_manifest_hash,

        "reference_solver_sha256":
            actual_solver_hash,

        "file72_sha256":
            sha256_file(
                file72_path
            ),

        "smoke_case_count":
            number_cases,

        "step_case_count":
            number_steps,

        "ramp_case_count":
            number_ramps,

        "global_shape":
            list(
                global_state_disk.shape
            ),

        "step_event_shape":
            list(
                step_event_state_disk.shape
            ),

        "ramp_anchor_shape":
            list(
                ramp_anchor_state_disk.shape
            ),

        "global_points":
            global_points,

        "step_event_points":
            event_points,

        "state_names":
            state_names,

        "auxiliary_names":
            auxiliary_names,

        "transport_T_min_K":
            transport_min,

        "transport_T_max_K":
            transport_max,

        "transport_upper_margin_K":
            transport_upper_margin,

        "baseline_max_drift":
            baseline_drift,

        "baseline_max_abs_derivative":
            baseline_result.get(
                "baseline_max_abs_derivative"
            ),

        "global_initial_state_max_error":
            all_initial_error,

        "step_event_initial_state_max_error":
            step_event_initial_error,

        "ramp_onset_anchor_max_error":
            ramp_onset_error,

        "generated_file_sha256":
            hashes,
    }

    metadata_path = (
        smoke_root
        / METADATA_JSON_NAME
    )

    with metadata_path.open(
        "w",
        encoding="utf-8",
    ) as f:

        json.dump(
            metadata,
            f,
            indent=2,
        )

    # ======================================================================
    # REPORT
    # ======================================================================

    report_path = (
        smoke_root
        / REPORT_NAME
    )

    with report_path.open(
        "w",
        encoding="utf-8",
    ) as f:

        f.write(
            "=" * 100
            + "\n"
        )

        f.write(
            "STEP 6 - PRODUCTION-FORMAT "
            "GENERATOR SMOKE TEST\n"
        )

        f.write(
            "=" * 100
            + "\n\n"
        )

        f.write(
            f"Project root: {root}\n\n"
        )

        f.write(
            "CORRECTION\n"
        )

        f.write(
            "-" * 100
            + "\n"
        )

        f.write(
            "The first File-173 run incorrectly failed the "
            "exact baseline because the baseline storage shortcut "
            "made no File-72 transport calls.\n\n"
        )

        f.write(
            "This corrected run keeps the exact equilibrium storage "
            "and separately executes one zero-reactivity File-74 "
            "derivative evaluation while the File-72 transport "
            "profiler is active.\n\n"
        )

        f.write(
            "No physical model or production dataset design "
            "parameter was changed.\n\n"
        )

        f.write(
            "FROZEN PRODUCTION CONTRACT\n"
        )

        f.write(
            "=" * 100
            + "\n"
        )

        f.write(
            f"Production manifest cases : "
            f"{len(production_manifest)}\n"
        )

        f.write(
            f"Smoke cases               : "
            f"{number_cases}\n"
        )

        f.write(
            f"STEP smoke cases          : "
            f"{number_steps}\n"
        )

        f.write(
            f"RAMP smoke cases          : "
            f"{number_ramps}\n"
        )

        f.write(
            f"Global state shape        : "
            f"{global_state_disk.shape}\n"
        )

        f.write(
            f"STEP event state shape    : "
            f"{step_event_state_disk.shape}\n"
        )

        f.write(
            f"RAMP anchor state shape   : "
            f"{ramp_anchor_state_disk.shape}\n"
        )

        # ------------------------------------------------------------------
        # Case results
        # ------------------------------------------------------------------

        f.write(
            "\n\nCASE EXECUTION\n"
        )

        f.write(
            "=" * 100
            + "\n"
        )

        for result in results:

            f.write(
                "\n"
                f"{result['case_id']} | "
                f"{result['partition']} | "
                f"{result['waveform']}\n"
            )

            f.write(
                "-" * 100
                + "\n"
            )

            f.write(
                f"success               : "
                f"{result['success']}\n"
            )

            if result[
                "success"
            ]:

                f.write(
                    f"transport Tmin [K]    : "
                    f"{result['transport_T_min_K']:.6f}\n"
                )

                f.write(
                    f"transport Tmax [K]    : "
                    f"{result['transport_T_max_K']:.6f}\n"
                )

                f.write(
                    f"power min/max         : "
                    f"{result['power_min']:.9g} / "
                    f"{result['power_max']:.9g}\n"
                )

                if (
                    result[
                        "waveform"
                    ]
                    == "BASELINE"
                ):

                    f.write(
                        f"baseline max |dy/dt|  : "
                        f"{result['baseline_max_abs_derivative']:.12e}\n"
                    )

            else:

                f.write(
                    f"exception             : "
                    f"{result['exception']}\n"
                )

        # ------------------------------------------------------------------
        # Gate
        # ------------------------------------------------------------------

        f.write(
            "\n\nPRODUCTION-FORMAT SMOKE GATE\n"
        )

        f.write(
            "=" * 100
            + "\n"
        )

        gates = (

            (
                "All representative trajectories completed",
                execution_pass,
            ),

            (
                "Production array shapes correct",
                shape_pass,
            ),

            (
                "All written arrays finite",
                finite_pass,
            ),

            (
                "STEP/RAMP index mappings correct",
                mapping_pass,
            ),

            (
                "Baseline equilibrium preserved",
                baseline_pass,
            ),

            (
                "All global trajectories begin at rated state",
                initial_pass,
            ),

            (
                "STEP event-local views begin at rated state",
                step_event_initial_pass,
            ),

            (
                "RAMP onset anchors equal rated state",
                ramp_anchor_pass,
            ),

            (
                "All runtime transport calls remain supported",
                all_transport_pass,
            ),
        )

        for label, passed in gates:

            f.write(
                f"{'PASS' if passed else 'FAIL':<5s} "
                f"{label}\n"
            )

        f.write(
            "\n"
        )

        f.write(
            f"Successful trajectories : "
            f"{successful_count} / "
            f"{number_cases}\n"
        )

        f.write(
            f"Failed trajectories     : "
            f"{failed_count}\n"
        )

        f.write(
            f"Baseline max drift      : "
            f"{baseline_drift:.12e}\n"
        )

        f.write(
            f"Transport Tmin [K]      : "
            f"{transport_min:.6f}\n"
        )

        f.write(
            f"Transport Tmax [K]      : "
            f"{transport_max:.6f}\n"
        )

        f.write(
            f"Worst upper margin [K]  : "
            f"{transport_upper_margin:.6f}\n"
        )

        f.write(
            "\n"
        )

        f.write(
            f"PRODUCTION FORMAT SMOKE TEST PASS: "
            f"{smoke_pass}\n"
        )

        f.write(
            "\n"
        )

        if smoke_pass:

            f.write(
                "RESULT:\n"
            )

            f.write(
                "THE FROZEN PRODUCTION-V1 MANIFEST, MULTI-RATE "
                "REPRESENTATION, ARRAY SCHEMA, AUXILIARY OUTPUT "
                "SCHEMA, BASELINE RUNTIME PATH, TRANSPORT GATE AND "
                "INCREMENTAL NPY STORAGE FORMAT ALL PASSED.\n\n"
            )

            f.write(
                "The project is ready to execute the complete "
                "2,177-case Production-V1 dataset.\n"
            )

        else:

            f.write(
                "RESULT:\n"
            )

            f.write(
                "THE COMPLETE PRODUCTION RUN MUST NOT START. "
                "At least one production-format smoke gate failed.\n"
            )

        f.write(
            "\n"
            + "=" * 100
            + "\n"
        )

        f.write(
            "STATUS: STEP-6 PRODUCTION-FORMAT "
            "SMOKE TEST COMPLETE\n"
        )

    # ======================================================================
    # TERMINAL
    # ======================================================================

    print()

    print(
        "=" * 78
    )

    print(
        "PRODUCTION-FORMAT SMOKE RESULT"
    )

    print(
        "=" * 78
    )

    print(
        f"Successful cases          : "
        f"{successful_count} / "
        f"{number_cases}"
    )

    print(
        f"Failed cases              : "
        f"{failed_count}"
    )

    print()

    print(
        f"Global array shape        : "
        f"{global_state_disk.shape}"
    )

    print(
        f"STEP event array shape    : "
        f"{step_event_state_disk.shape}"
    )

    print(
        f"RAMP anchor array shape   : "
        f"{ramp_anchor_state_disk.shape}"
    )

    print()

    print(
        f"Global transport Tmin [K] : "
        f"{transport_min:.6f}"
    )

    print(
        f"Global transport Tmax [K] : "
        f"{transport_max:.6f}"
    )

    print(
        f"Worst upper margin [K]    : "
        f"{transport_upper_margin:.6f}"
    )

    print()

    print(
        f"Baseline max drift        : "
        f"{baseline_drift:.3e}"
    )

    print(
        f"Baseline max |dy/dt|      : "
        f"{float(baseline_result.get('baseline_max_abs_derivative', np.nan)):.3e}"
    )

    print(
        f"STEP local initial error  : "
        f"{step_event_initial_error:.3e}"
    )

    print(
        f"RAMP onset anchor error   : "
        f"{ramp_onset_error:.3e}"
    )

    print()

    print(
        f"PRODUCTION FORMAT PASS: "
        f"{smoke_pass}"
    )

    print()

    print(
        "Saved smoke directory:"
    )

    print(
        f"  {DATASET_DIRECTORY}/"
        f"{SMOKE_DIRECTORY}"
    )

    print()

    if smoke_pass:

        print(
            "STATUS: STEP-6 PRODUCTION-FORMAT "
            "SMOKE TEST PASSED"
        )

        print(
            "NEXT: GENERATE COMPLETE "
            "2,177-CASE PRODUCTION V1 DATASET"
        )

    else:

        print(
            "STATUS: PRODUCTION FORMAT "
            "REQUIRES INVESTIGATION"
        )


if __name__ == "__main__":
    main()