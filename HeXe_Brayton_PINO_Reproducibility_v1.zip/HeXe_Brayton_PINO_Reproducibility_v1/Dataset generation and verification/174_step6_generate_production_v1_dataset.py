from __future__ import annotations

import csv
import hashlib
import importlib.util
import json
import shutil
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np


# ============================================================================
# 174_step6_generate_production_v1_dataset.py
#
# STEP 6
# COMPLETE PAPER-1 PRODUCTION-V1 DATASET GENERATOR
#
# PURPOSE
# -------
# Generate all 2,177 trajectories frozen by File 172 using the exact
# production-format case-generation path already tested by File 173.
#
#
# IMPORTANT DESIGN DECISION
# -------------------------
# This file DOES NOT duplicate the physical trajectory-generation routines.
#
# Instead, it loads:
#
#   173_step6_production_format_smoke_test.py
#
# and reuses its PASSED:
#
#   execute_case()
#
# path.
#
# This prevents the full production generator from silently diverging from
# the production-format code that was actually smoke-tested.
#
#
# FEATURES
# --------
# - 2,177 frozen Production-V1 cases
# - 601-point global trajectories
# - 1,021-point STEP event-local trajectories
# - exact RAMP onset/completion anchors
# - 10 dynamic PINO targets
# - 9 auxiliary varying Brayton quantities
# - File-72 400-1200 K runtime transport gate
# - incremental float64 .npy memmap storage
# - automatic restart/resume
# - per-case completion status
# - failure logging
# - per-case execution metrics
# - manifest / solver / generator fingerprints
#
#
# RESTART POLICY
# --------------
# A case is marked COMPLETE only AFTER:
#
#   - global state is written;
#   - global reactivity is written;
#   - auxiliary outputs are written;
#   - STEP or RAMP local data are written;
#   - case metrics are written;
#   - all arrays are flushed.
#
# If execution stops before completion, rerunning this same file safely
# retries the unfinished case.
#
#
# FAILURE POLICY
# --------------
# Failed/unsupported trajectories are logged and the production run stops.
#
# We do NOT silently:
#
#   - replace a failed trajectory;
#   - clip it;
#   - modify its input;
#   - substitute a neighbouring trajectory.
#
#
# THIS FILE DOES NOT
# ------------------
# - change any model parameter;
# - change File 74;
# - change File-172 sample count;
# - change train/validation/test partitions;
# - change the validated temporal grid;
# - introduce new uncertainty;
# - train the PINO.
# ============================================================================


# ============================================================================
# PROJECT FILES
# ============================================================================

FILE72 = "72_hexe_transport_properties.py"

FILE74 = "74_master_coupled_reference_model.py"

FILE173 = (
    "173_step6_production_format_smoke_test.py"
)

DATASET_DIRECTORY = "step6_dataset"

FILE166_CONTRACT = (
    "166_step6_pilot_dataset_contract.json"
)

FILE172_MANIFEST = (
    "172_step6_production_manifest.csv"
)

FILE172_CONTRACT = (
    "172_step6_production_dataset_contract.json"
)

FILE173_REPORT = (
    "production_smoke_test/"
    "173_step6_production_format_smoke_test_report.txt"
)

FILE173_METADATA = (
    "production_smoke_test/"
    "173_smoke_dataset_metadata.json"
)


# ============================================================================
# PRODUCTION DIRECTORY
# ============================================================================

PRODUCTION_DIRECTORY = "production_v1"


# ============================================================================
# PRODUCTION OUTPUTS
# ============================================================================

RUNTIME_METADATA_NAME = (
    "174_step6_production_runtime_metadata.json"
)

PROGRESS_NAME = (
    "174_step6_production_progress.json"
)

FAILURE_LOG_NAME = (
    "174_step6_production_failure_log.csv"
)

SUMMARY_NAME = (
    "174_step6_production_execution_summary.csv"
)

REPORT_NAME = (
    "174_step6_production_generation_report.txt"
)


# ============================================================================
# CASE STATUS
#
#  0 = PENDING / INTERRUPTED
#  1 = COMPLETE
# -1 = FAILED ON LAST ATTEMPT
# ============================================================================

STATUS_PENDING = 0
STATUS_COMPLETE = 1
STATUS_FAILED = -1


# ============================================================================
# SCIENTIFIC FAILURE POLICY
# ============================================================================

STOP_ON_FAILURE = True


# ============================================================================
# HELPERS
# ============================================================================


def require_file(
    path: Path,
) -> Path:

    if not path.exists():

        raise FileNotFoundError(
            f"Required file missing: {path}"
        )

    return path


def safe_read(
    path: Path,
) -> str:

    encodings = (
        "utf-8",
        "utf-8-sig",
        "cp1252",
        "latin-1",
    )

    for encoding in encodings:

        try:

            return path.read_text(
                encoding=encoding
            )

        except UnicodeDecodeError:

            continue

        except OSError:

            return ""

    return ""


def sha256_file(
    path: Path,
) -> str:

    digest = hashlib.sha256()

    with path.open(
        "rb"
    ) as f:

        while True:

            block = f.read(
                1024 * 1024
            )

            if not block:

                break

            digest.update(
                block
            )

    return digest.hexdigest()


def load_module(
    module_name: str,
    path: Path,
):

    spec = importlib.util.spec_from_file_location(
        module_name,
        path,
    )

    if (
        spec is None
        or
        spec.loader is None
    ):

        raise ImportError(
            f"Could not load module: {path}"
        )

    module = importlib.util.module_from_spec(
        spec
    )

    sys.modules[
        module_name
    ] = module

    spec.loader.exec_module(
        module
    )

    return module


def read_csv(
    path: Path,
) -> list[dict[str, str]]:

    with path.open(
        "r",
        encoding="utf-8-sig",
        newline="",
    ) as f:

        return list(
            csv.DictReader(
                f
            )
        )


def utc_now() -> str:

    return (
        datetime.now(
            timezone.utc
        )
        .isoformat()
    )


def open_or_create_memmap(
    path: Path,
    *,
    dtype,
    shape: tuple,
    fill_value,
):

    requested_dtype = np.dtype(
        dtype
    )

    if path.exists():

        array = np.load(
            path,
            mmap_mode="r+",
            allow_pickle=False,
        )

        if (
            tuple(
                array.shape
            )
            != tuple(
                shape
            )
        ):

            raise RuntimeError(
                f"Existing array shape mismatch: "
                f"{path.name}\n"
                f"Expected: {shape}\n"
                f"Found   : {array.shape}"
            )

        if (
            np.dtype(
                array.dtype
            )
            != requested_dtype
        ):

            raise RuntimeError(
                f"Existing array dtype mismatch: "
                f"{path.name}\n"
                f"Expected: {requested_dtype}\n"
                f"Found   : {array.dtype}"
            )

        return array

    array = np.lib.format.open_memmap(
        path,
        mode="w+",
        dtype=requested_dtype,
        shape=shape,
    )

    array[...] = fill_value

    array.flush()

    return array


def save_or_validate_array(
    path: Path,
    expected: np.ndarray,
) -> None:

    if path.exists():

        actual = np.load(
            path,
            allow_pickle=False,
        )

        if (
            actual.shape
            != expected.shape
        ):

            raise RuntimeError(
                f"Static array shape changed: {path.name}"
            )

        if (
            actual.dtype
            != expected.dtype
        ):

            raise RuntimeError(
                f"Static array dtype changed: {path.name}"
            )

        if not np.array_equal(
            actual,
            expected,
        ):

            raise RuntimeError(
                f"Static array content changed: {path.name}"
            )

        return

    np.save(
        path,
        expected,
    )


def flush_all(
    arrays: list,
) -> None:

    for array in arrays:

        try:

            array.flush()

        except Exception:

            pass


def append_failure_log(
    path: Path,
    row: dict[str, str],
    result: dict,
) -> None:

    exists = path.exists()

    with path.open(
        "a",
        encoding="utf-8-sig",
        newline="",
    ) as f:

        fieldnames = (
            "utc_time",
            "case_id",
            "partition",
            "regime",
            "waveform",
            "amplitude_cents",
            "exception",
        )

        writer = csv.DictWriter(
            f,
            fieldnames=fieldnames,
        )

        if not exists:

            writer.writeheader()

        writer.writerow(
            {
                "utc_time":
                    utc_now(),

                "case_id":
                    row[
                        "case_id"
                    ],

                "partition":
                    row[
                        "partition"
                    ],

                "regime":
                    row[
                        "regime"
                    ],

                "waveform":
                    row[
                        "waveform"
                    ],

                "amplitude_cents":
                    row[
                        "amplitude_cents"
                    ],

                "exception":
                    result.get(
                        "exception",
                        "",
                    ),
            }
        )


def write_progress(
    path: Path,
    *,
    case_status,
    total_cases: int,
    last_case_id: str | None,
    session_start: float,
) -> None:

    status_array = np.asarray(
        case_status
    )

    complete = int(
        np.sum(
            status_array
            == STATUS_COMPLETE
        )
    )

    failed = int(
        np.sum(
            status_array
            == STATUS_FAILED
        )
    )

    pending = (
        total_cases
        - complete
        - failed
    )

    progress = {

        "dataset":
            "PAPER1_PRODUCTION_V1",

        "total_cases":
            total_cases,

        "complete_cases":
            complete,

        "failed_cases":
            failed,

        "pending_cases":
            pending,

        "percent_complete":
            (
                100.0
                * complete
                / total_cases
            ),

        "last_case_id":
            last_case_id,

        "current_session_elapsed_s":
            (
                time.perf_counter()
                - session_start
            ),

        "updated_utc":
            utc_now(),
    }

    with path.open(
        "w",
        encoding="utf-8",
    ) as f:

        json.dump(
            progress,
            f,
            indent=2,
        )


# ============================================================================
# RUNTIME METADATA
# ============================================================================


def build_runtime_contract(
    *,
    manifest_hash: str,
    contract172_hash: str,
    solver_hash: str,
    file72_hash: str,
    helper173_hash: str,
    generator174_hash: str,
    total_cases: int,
    step_cases: int,
    ramp_cases: int,
    global_points: int,
    event_points: int,
    state_count: int,
    auxiliary_count: int,
) -> dict:

    return {

        "dataset":
            "PAPER1_PRODUCTION_V1",

        "production_manifest_sha256":
            manifest_hash,

        "production_contract_sha256":
            contract172_hash,

        "reference_solver_sha256":
            solver_hash,

        "file72_sha256":
            file72_hash,

        "file173_case_generator_sha256":
            helper173_hash,

        "file174_generator_sha256":
            generator174_hash,

        "total_cases":
            total_cases,

        "step_cases":
            step_cases,

        "ramp_cases":
            ramp_cases,

        "global_points":
            global_points,

        "step_event_points":
            event_points,

        "state_count":
            state_count,

        "auxiliary_count":
            auxiliary_count,

        "raw_dtype":
            "float64",

        "status_encoding": {

            "pending":
                STATUS_PENDING,

            "complete":
                STATUS_COMPLETE,

            "failed":
                STATUS_FAILED,
        },
    }


def validate_or_write_runtime_contract(
    path: Path,
    contract: dict,
) -> None:

    if path.exists():

        with path.open(
            "r",
            encoding="utf-8",
        ) as f:

            existing = json.load(
                f
            )

        for key, expected in (
            contract.items()
        ):

            if (
                key
                not in existing
            ):

                raise RuntimeError(
                    "Production runtime metadata is missing "
                    f"required key: {key}"
                )

            if (
                existing[
                    key
                ]
                != expected
            ):

                raise RuntimeError(
                    "Production-V1 resume fingerprint mismatch.\n"
                    f"Field    : {key}\n"
                    f"Expected : {expected}\n"
                    f"Existing : {existing[key]}\n\n"
                    "Do not resume this dataset with modified "
                    "source files."
                )

        return

    contract_to_write = dict(
        contract
    )

    contract_to_write[
        "created_utc"
    ] = utc_now()

    with path.open(
        "w",
        encoding="utf-8",
    ) as f:

        json.dump(
            contract_to_write,
            f,
            indent=2,
        )


# ============================================================================
# EXECUTION SUMMARY
# ============================================================================


def write_execution_summary(
    path: Path,
    *,
    manifest: list[dict[str, str]],
    case_status,
    elapsed_s,
    transport_min,
    transport_max,
    transport_upper_margin,
    power_min,
    power_max,
    fuel_min,
    fuel_max,
    bulk_min,
    bulk_max,
) -> None:

    fieldnames = (

        "case_index",
        "case_id",
        "partition",
        "regime",
        "waveform",
        "amplitude_cents",
        "event_onset_s",
        "ramp_duration_s",
        "status",
        "elapsed_s",
        "transport_T_min_K",
        "transport_T_max_K",
        "transport_upper_margin_K",
        "power_min",
        "power_max",
        "fuel_T_min_K",
        "fuel_T_max_K",
        "bulk_T_min_K",
        "bulk_T_max_K",
    )

    with path.open(
        "w",
        encoding="utf-8-sig",
        newline="",
    ) as f:

        writer = csv.DictWriter(
            f,
            fieldnames=fieldnames,
        )

        writer.writeheader()

        for index, row in enumerate(
            manifest
        ):

            status_value = int(
                case_status[
                    index
                ]
            )

            if (
                status_value
                == STATUS_COMPLETE
            ):

                status_text = (
                    "COMPLETE"
                )

            elif (
                status_value
                == STATUS_FAILED
            ):

                status_text = (
                    "FAILED"
                )

            else:

                status_text = (
                    "PENDING"
                )

            writer.writerow(
                {
                    "case_index":
                        index,

                    "case_id":
                        row[
                            "case_id"
                        ],

                    "partition":
                        row[
                            "partition"
                        ],

                    "regime":
                        row[
                            "regime"
                        ],

                    "waveform":
                        row[
                            "waveform"
                        ],

                    "amplitude_cents":
                        row[
                            "amplitude_cents"
                        ],

                    "event_onset_s":
                        row[
                            "event_onset_s"
                        ],

                    "ramp_duration_s":
                        row[
                            "ramp_duration_s"
                        ],

                    "status":
                        status_text,

                    "elapsed_s":
                        float(
                            elapsed_s[
                                index
                            ]
                        ),

                    "transport_T_min_K":
                        float(
                            transport_min[
                                index
                            ]
                        ),

                    "transport_T_max_K":
                        float(
                            transport_max[
                                index
                            ]
                        ),

                    "transport_upper_margin_K":
                        float(
                            transport_upper_margin[
                                index
                            ]
                        ),

                    "power_min":
                        float(
                            power_min[
                                index
                            ]
                        ),

                    "power_max":
                        float(
                            power_max[
                                index
                            ]
                        ),

                    "fuel_T_min_K":
                        float(
                            fuel_min[
                                index
                            ]
                        ),

                    "fuel_T_max_K":
                        float(
                            fuel_max[
                                index
                            ]
                        ),

                    "bulk_T_min_K":
                        float(
                            bulk_min[
                                index
                            ]
                        ),

                    "bulk_T_max_K":
                        float(
                            bulk_max[
                                index
                            ]
                        ),
                }
            )


# ============================================================================
# MAIN
# ============================================================================


def main() -> None:

    root = Path(
        __file__
    ).resolve().parent

    if str(
        root
    ) not in sys.path:

        sys.path.insert(
            0,
            str(
                root
            ),
        )

    dataset_root = (
        root
        / DATASET_DIRECTORY
    )

    production_root = (
        dataset_root
        / PRODUCTION_DIRECTORY
    )

    production_root.mkdir(
        parents=True,
        exist_ok=True,
    )

    # ======================================================================
    # REQUIRED INPUTS
    # ======================================================================

    file72_path = require_file(
        root
        / FILE72
    )

    file74_path = require_file(
        root
        / FILE74
    )

    file173_path = require_file(
        root
        / FILE173
    )

    contract166_path = require_file(
        dataset_root
        / FILE166_CONTRACT
    )

    manifest172_path = require_file(
        dataset_root
        / FILE172_MANIFEST
    )

    contract172_path = require_file(
        dataset_root
        / FILE172_CONTRACT
    )

    smoke_report_path = require_file(
        dataset_root
        / FILE173_REPORT
    )

    smoke_metadata_path = require_file(
        dataset_root
        / FILE173_METADATA
    )

    # ======================================================================
    # REQUIRE PASSED FILE-173 SMOKE TEST
    # ======================================================================

    smoke_report = safe_read(
        smoke_report_path
    )

    if (
        "PRODUCTION FORMAT SMOKE TEST PASS: True"
        not in smoke_report
    ):

        raise RuntimeError(
            "File 173 does not confirm a passing "
            "production-format smoke test."
        )

    with smoke_metadata_path.open(
        "r",
        encoding="utf-8",
    ) as f:

        smoke_metadata = json.load(
            f
        )

    if (
        smoke_metadata.get(
            "status"
        )
        != "PASS"
    ):

        raise RuntimeError(
            "File-173 smoke metadata does not have PASS status."
        )

    # ======================================================================
    # LOAD CONTRACTS
    # ======================================================================

    with contract166_path.open(
        "r",
        encoding="utf-8",
    ) as f:

        contract166 = json.load(
            f
        )

    with contract172_path.open(
        "r",
        encoding="utf-8",
    ) as f:

        contract172 = json.load(
            f
        )

    manifest = read_csv(
        manifest172_path
    )

    total_cases = int(
        contract172[
            "production_case_count"
        ]
    )

    if (
        len(
            manifest
        )
        != total_cases
    ):

        raise RuntimeError(
            "Production manifest case count changed."
        )

    if total_cases != 2177:

        raise RuntimeError(
            "Frozen Production-V1 case count is no longer 2177."
        )

    # ======================================================================
    # FINGERPRINTS
    # ======================================================================

    manifest_hash = sha256_file(
        manifest172_path
    )

    contract172_hash = sha256_file(
        contract172_path
    )

    solver_hash = sha256_file(
        file74_path
    )

    file72_hash = sha256_file(
        file72_path
    )

    helper173_hash = sha256_file(
        file173_path
    )

    generator174_hash = sha256_file(
        Path(
            __file__
        ).resolve()
    )

    if (
        manifest_hash
        != contract172[
            "manifest_sha256"
        ]
    ):

        raise RuntimeError(
            "File-172 manifest no longer matches "
            "its frozen contract."
        )

    if (
        solver_hash
        != contract166[
            "reference_solver_sha256"
        ]
    ):

        raise RuntimeError(
            "File 74 changed after the frozen "
            "reference-model contract."
        )

    if (
        smoke_metadata.get(
            "production_manifest_sha256"
        )
        != manifest_hash
    ):

        raise RuntimeError(
            "Smoke test used a different production manifest."
        )

    if (
        smoke_metadata.get(
            "reference_solver_sha256"
        )
        != solver_hash
    ):

        raise RuntimeError(
            "Smoke test used a different File-74 solver."
        )

    if (
        smoke_metadata.get(
            "file72_sha256"
        )
        != file72_hash
    ):

        raise RuntimeError(
            "File 72 changed after the passed smoke test."
        )

    # ======================================================================
    # FROZEN SCHEMA
    # ======================================================================

    state_names = list(
        contract172[
            "primary_pino_targets"
        ][
            "fields"
        ]
    )

    auxiliary_names = list(
        contract172[
            "auxiliary_cycle_outputs"
        ][
            "fields"
        ]
    )

    state_count = len(
        state_names
    )

    auxiliary_count = len(
        auxiliary_names
    )

    if state_count != 10:

        raise RuntimeError(
            "Expected 10 primary state targets."
        )

    if auxiliary_count != 9:

        raise RuntimeError(
            "Expected 9 varying auxiliary cycle fields."
        )

    # ======================================================================
    # TEMPORAL REPRESENTATION
    # ======================================================================

    temporal = (
        contract172[
            "temporal_representation"
        ]
    )

    global_info = (
        temporal[
            "global_view"
        ]
    )

    event_info = (
        temporal[
            "step_event_local_view"
        ]
    )

    global_time = np.linspace(
        float(
            global_info[
                "time_start_s"
            ]
        ),
        float(
            global_info[
                "time_end_s"
            ]
        ),
        int(
            global_info[
                "points"
            ]
        ),
        dtype=np.float64,
    )

    event_relative_time = np.asarray(
        event_info[
            "time_vector_s"
        ],
        dtype=np.float64,
    )

    global_points = len(
        global_time
    )

    event_points = len(
        event_relative_time
    )

    if global_points != 601:

        raise RuntimeError(
            "Frozen global grid is no longer 601 points."
        )

    if event_points != 1021:

        raise RuntimeError(
            "Frozen STEP event-local grid is no longer 1021 points."
        )

    fast_dt_s = float(
        event_info[
            "fast_region"
        ][
            "dt_s"
        ]
    )

    fast_end_relative_s = float(
        event_info[
            "fast_region"
        ][
            "end_s"
        ]
    )

    transition_dt_s = float(
        event_info[
            "transition_region"
        ][
            "dt_s"
        ]
    )

    transition_end_relative_s = float(
        event_info[
            "transition_region"
        ][
            "end_s"
        ]
    )

    # ======================================================================
    # CASE MAPPINGS
    # ======================================================================

    step_case_indices = np.asarray(
        [
            index
            for index, row
            in enumerate(
                manifest
            )
            if row[
                "waveform"
            ]
            == "STEP_HOLD"
        ],
        dtype=np.int64,
    )

    ramp_case_indices = np.asarray(
        [
            index
            for index, row
            in enumerate(
                manifest
            )
            if row[
                "waveform"
            ]
            == "LINEAR_RAMP_HOLD"
        ],
        dtype=np.int64,
    )

    step_cases = len(
        step_case_indices
    )

    ramp_cases = len(
        ramp_case_indices
    )

    if step_cases != 1088:

        raise RuntimeError(
            f"Expected 1088 STEP cases, found {step_cases}."
        )

    if ramp_cases != 1088:

        raise RuntimeError(
            f"Expected 1088 RAMP cases, found {ramp_cases}."
        )

    global_to_step = np.full(
        total_cases,
        -1,
        dtype=np.int64,
    )

    for local_index, global_index in enumerate(
        step_case_indices
    ):

        global_to_step[
            global_index
        ] = local_index

    global_to_ramp = np.full(
        total_cases,
        -1,
        dtype=np.int64,
    )

    for local_index, global_index in enumerate(
        ramp_case_indices
    ):

        global_to_ramp[
            global_index
        ] = local_index

    case_ids = np.asarray(
        [
            row[
                "case_id"
            ]
            for row
            in manifest
        ],
        dtype="U32",
    )

    # ======================================================================
    # LOAD PASSED FILE-173 GENERATOR
    # ======================================================================

    helper173 = load_module(
        "_file174_helper173",
        file173_path,
    )

    master = helper173.load_module_from_file(
        "_file174_master74",
        file74_path,
    )

    baseline_model = (
        master
        .MasterCoupledReferenceModel()
    )

    reference_state = np.asarray(
        baseline_model
        .reference_state(),
        dtype=np.float64,
    )

    if reference_state.shape != (
        state_count,
    ):

        raise RuntimeError(
            "File-74 reference state no longer "
            "matches frozen target schema."
        )

    if not np.all(
        np.isfinite(
            reference_state
        )
    ):

        raise RuntimeError(
            "Reference state contains non-finite values."
        )

    # ======================================================================
    # RUNTIME CONTRACT
    # ======================================================================

    runtime_contract = build_runtime_contract(

        manifest_hash=manifest_hash,

        contract172_hash=contract172_hash,

        solver_hash=solver_hash,

        file72_hash=file72_hash,

        helper173_hash=helper173_hash,

        generator174_hash=generator174_hash,

        total_cases=total_cases,

        step_cases=step_cases,

        ramp_cases=ramp_cases,

        global_points=global_points,

        event_points=event_points,

        state_count=state_count,

        auxiliary_count=auxiliary_count,
    )

    runtime_metadata_path = (
        production_root
        / RUNTIME_METADATA_NAME
    )

    validate_or_write_runtime_contract(
        runtime_metadata_path,
        runtime_contract,
    )

    # ======================================================================
    # STATIC ARRAYS
    # ======================================================================

    save_or_validate_array(
        production_root
        / "global_time_s.npy",
        global_time,
    )

    save_or_validate_array(
        production_root
        / "step_event_relative_time_s.npy",
        event_relative_time,
    )

    save_or_validate_array(
        production_root
        / "reference_state.npy",
        reference_state,
    )

    save_or_validate_array(
        production_root
        / "case_ids.npy",
        case_ids,
    )

    save_or_validate_array(
        production_root
        / "state_names.npy",
        np.asarray(
            state_names,
            dtype="U128",
        ),
    )

    save_or_validate_array(
        production_root
        / "auxiliary_names.npy",
        np.asarray(
            auxiliary_names,
            dtype="U256",
        ),
    )

    save_or_validate_array(
        production_root
        / "step_case_indices.npy",
        step_case_indices,
    )

    save_or_validate_array(
        production_root
        / "ramp_case_indices.npy",
        ramp_case_indices,
    )

    save_or_validate_array(
        production_root
        / "global_to_step_index.npy",
        global_to_step,
    )

    save_or_validate_array(
        production_root
        / "global_to_ramp_index.npy",
        global_to_ramp,
    )

    # ======================================================================
    # MAIN DATA ARRAYS
    # ======================================================================

    global_state = open_or_create_memmap(

        production_root
        / "global_state.npy",

        dtype=np.float64,

        shape=(
            total_cases,
            global_points,
            state_count,
        ),

        fill_value=np.nan,
    )

    global_reactivity = open_or_create_memmap(

        production_root
        / "global_reactivity_delta_k_over_k.npy",

        dtype=np.float64,

        shape=(
            total_cases,
            global_points,
        ),

        fill_value=np.nan,
    )

    global_auxiliary = open_or_create_memmap(

        production_root
        / "global_auxiliary_cycle.npy",

        dtype=np.float64,

        shape=(
            total_cases,
            global_points,
            auxiliary_count,
        ),

        fill_value=np.nan,
    )

    step_event_state = open_or_create_memmap(

        production_root
        / "step_event_state.npy",

        dtype=np.float64,

        shape=(
            step_cases,
            event_points,
            state_count,
        ),

        fill_value=np.nan,
    )

    step_event_reactivity = open_or_create_memmap(

        production_root
        / "step_event_reactivity_delta_k_over_k.npy",

        dtype=np.float64,

        shape=(
            step_cases,
            event_points,
        ),

        fill_value=np.nan,
    )

    ramp_anchor_time = open_or_create_memmap(

        production_root
        / "ramp_anchor_time_s.npy",

        dtype=np.float64,

        shape=(
            ramp_cases,
            2,
        ),

        fill_value=np.nan,
    )

    ramp_anchor_state = open_or_create_memmap(

        production_root
        / "ramp_anchor_state.npy",

        dtype=np.float64,

        shape=(
            ramp_cases,
            2,
            state_count,
        ),

        fill_value=np.nan,
    )

    ramp_anchor_reactivity = open_or_create_memmap(

        production_root
        / "ramp_anchor_reactivity_delta_k_over_k.npy",

        dtype=np.float64,

        shape=(
            ramp_cases,
            2,
        ),

        fill_value=np.nan,
    )

    # ======================================================================
    # CASE STATUS / METRICS
    # ======================================================================

    case_status = open_or_create_memmap(

        production_root
        / "174_case_status.npy",

        dtype=np.int8,

        shape=(
            total_cases,
        ),

        fill_value=STATUS_PENDING,
    )

    elapsed_s = open_or_create_memmap(

        production_root
        / "174_case_elapsed_seconds.npy",

        dtype=np.float64,

        shape=(
            total_cases,
        ),

        fill_value=np.nan,
    )

    transport_min = open_or_create_memmap(

        production_root
        / "174_transport_T_min_K.npy",

        dtype=np.float64,

        shape=(
            total_cases,
        ),

        fill_value=np.nan,
    )

    transport_max = open_or_create_memmap(

        production_root
        / "174_transport_T_max_K.npy",

        dtype=np.float64,

        shape=(
            total_cases,
        ),

        fill_value=np.nan,
    )

    transport_upper_margin = open_or_create_memmap(

        production_root
        / "174_transport_upper_margin_K.npy",

        dtype=np.float64,

        shape=(
            total_cases,
        ),

        fill_value=np.nan,
    )

    power_min = open_or_create_memmap(

        production_root
        / "174_power_min.npy",

        dtype=np.float64,

        shape=(
            total_cases,
        ),

        fill_value=np.nan,
    )

    power_max = open_or_create_memmap(

        production_root
        / "174_power_max.npy",

        dtype=np.float64,

        shape=(
            total_cases,
        ),

        fill_value=np.nan,
    )

    fuel_min = open_or_create_memmap(

        production_root
        / "174_fuel_T_min_K.npy",

        dtype=np.float64,

        shape=(
            total_cases,
        ),

        fill_value=np.nan,
    )

    fuel_max = open_or_create_memmap(

        production_root
        / "174_fuel_T_max_K.npy",

        dtype=np.float64,

        shape=(
            total_cases,
        ),

        fill_value=np.nan,
    )

    bulk_min = open_or_create_memmap(

        production_root
        / "174_bulk_T_min_K.npy",

        dtype=np.float64,

        shape=(
            total_cases,
        ),

        fill_value=np.nan,
    )

    bulk_max = open_or_create_memmap(

        production_root
        / "174_bulk_T_max_K.npy",

        dtype=np.float64,

        shape=(
            total_cases,
        ),

        fill_value=np.nan,
    )

    flushable_arrays = [

        global_state,
        global_reactivity,
        global_auxiliary,

        step_event_state,
        step_event_reactivity,

        ramp_anchor_time,
        ramp_anchor_state,
        ramp_anchor_reactivity,

        case_status,
        elapsed_s,

        transport_min,
        transport_max,
        transport_upper_margin,

        power_min,
        power_max,

        fuel_min,
        fuel_max,

        bulk_min,
        bulk_max,
    ]

    # ======================================================================
    # PROGRESS / FAILURE PATHS
    # ======================================================================

    progress_path = (
        production_root
        / PROGRESS_NAME
    )

    failure_log_path = (
        production_root
        / FAILURE_LOG_NAME
    )

    summary_path = (
        production_root
        / SUMMARY_NAME
    )

    report_path = (
        production_root
        / REPORT_NAME
    )

    # ======================================================================
    # CURRENT RESUME STATE
    # ======================================================================

    already_complete = int(
        np.sum(
            np.asarray(
                case_status
            )
            == STATUS_COMPLETE
        )
    )

    previous_failed = int(
        np.sum(
            np.asarray(
                case_status
            )
            == STATUS_FAILED
        )
    )

    remaining = (
        total_cases
        - already_complete
    )

    disk = shutil.disk_usage(
        production_root
    )

    free_gib = (
        disk.free
        / (
            1024 ** 3
        )
    )

    # ======================================================================
    # TERMINAL HEADER
    # ======================================================================

    print(
        "=" * 82
    )

    print(
        "STEP 6 - GENERATE COMPLETE "
        "PRODUCTION-V1 DATASET"
    )

    print(
        "=" * 82
    )

    print()

    print(
        f"Frozen production cases    : "
        f"{total_cases}"
    )

    print(
        f"STEP_HOLD cases            : "
        f"{step_cases}"
    )

    print(
        f"LINEAR_RAMP_HOLD cases     : "
        f"{ramp_cases}"
    )

    print()

    print(
        f"Global points/case         : "
        f"{global_points}"
    )

    print(
        f"STEP event points/case     : "
        f"{event_points}"
    )

    print(
        f"Primary dynamic targets    : "
        f"{state_count}"
    )

    print(
        f"Auxiliary cycle outputs    : "
        f"{auxiliary_count}"
    )

    print()

    print(
        f"Already complete           : "
        f"{already_complete}"
    )

    print(
        f"Previous failed status     : "
        f"{previous_failed}"
    )

    print(
        f"Cases remaining            : "
        f"{remaining}"
    )

    print()

    print(
        f"Free disk space [GiB]      : "
        f"{free_gib:.2f}"
    )

    print()

    print(
        "Restart policy:"
    )

    print(
        "  Ctrl+C is safe. Run the same command "
        "again to continue."
    )

    print()

    # ======================================================================
    # GENERATION
    # ======================================================================

    session_start = time.perf_counter()

    new_case_times = []

    last_case_id = None

    try:

        for case_index, row in enumerate(
            manifest
        ):

            # ----------------------------------------------------------
            # Skip safely completed cases.
            # ----------------------------------------------------------

            if (
                int(
                    case_status[
                        case_index
                    ]
                )
                == STATUS_COMPLETE
            ):

                continue

            case_id = (
                row[
                    "case_id"
                ]
            )

            last_case_id = (
                case_id
            )

            # A previously failed case is deliberately retried.
            case_status[
                case_index
            ] = STATUS_PENDING

            case_status.flush()

            current_complete = int(
                np.sum(
                    np.asarray(
                        case_status
                    )
                    == STATUS_COMPLETE
                )
            )

            print(
                f"[{case_index + 1:04d}/"
                f"{total_cases:04d}] "
                f"{case_id} | "
                f"{row['partition']:<12s} | "
                f"{row['regime']:<12s} | "
                f"{row['waveform']:<18s} | "
                f"{float(row['amplitude_cents']):+8.4f} cents",
                end="",
                flush=True,
            )

            case_start = (
                time.perf_counter()
            )

            result = (
                helper173.execute_case(

                    master_module=master,

                    file72_path=file72_path,

                    row=row,

                    reference_state=reference_state,

                    global_time=global_time,

                    event_relative_time=event_relative_time,

                    auxiliary_names=auxiliary_names,

                    fast_end_relative_s=(
                        fast_end_relative_s
                    ),

                    transition_end_relative_s=(
                        transition_end_relative_s
                    ),

                    fast_dt_s=(
                        fast_dt_s
                    ),

                    transition_dt_s=(
                        transition_dt_s
                    ),
                )
            )

            case_elapsed = (
                time.perf_counter()
                - case_start
            )

            elapsed_s[
                case_index
            ] = case_elapsed

            # ==========================================================
            # FAILURE
            # ==========================================================

            if not result[
                "success"
            ]:

                case_status[
                    case_index
                ] = STATUS_FAILED

                flush_all(
                    flushable_arrays
                )

                append_failure_log(
                    failure_log_path,
                    row,
                    result,
                )

                write_progress(

                    progress_path,

                    case_status=case_status,

                    total_cases=total_cases,

                    last_case_id=case_id,

                    session_start=session_start,
                )

                print(
                    "  FAIL"
                )

                print(
                    "       "
                    + str(
                        result.get(
                            "exception",
                            "Unknown failure",
                        )
                    )
                )

                print()

                print(
                    "Production run stopped."
                )

                print(
                    "The failed case has been logged and "
                    "was NOT replaced."
                )

                print(
                    "After investigating the cause, rerun "
                    "the same command to retry it."
                )

                if STOP_ON_FAILURE:

                    raise SystemExit(
                        1
                    )

                continue

            # ==========================================================
            # WRITE GLOBAL ARRAYS
            # ==========================================================

            global_state[
                case_index,
                :,
                :
            ] = result[
                "global_state"
            ]

            global_reactivity[
                case_index,
                :
            ] = result[
                "global_reactivity"
            ]

            global_auxiliary[
                case_index,
                :,
                :
            ] = result[
                "global_auxiliary"
            ]

            # ==========================================================
            # WRITE STEP LOCAL VIEW
            # ==========================================================

            if (
                row[
                    "waveform"
                ]
                == "STEP_HOLD"
            ):

                local_index = int(
                    global_to_step[
                        case_index
                    ]
                )

                if local_index < 0:

                    raise RuntimeError(
                        f"{case_id}: missing STEP local mapping."
                    )

                step_event_state[
                    local_index,
                    :,
                    :
                ] = result[
                    "event_state"
                ]

                step_event_reactivity[
                    local_index,
                    :
                ] = result[
                    "event_reactivity"
                ]

            # ==========================================================
            # WRITE RAMP ANCHORS
            # ==========================================================

            elif (
                row[
                    "waveform"
                ]
                == "LINEAR_RAMP_HOLD"
            ):

                local_index = int(
                    global_to_ramp[
                        case_index
                    ]
                )

                if local_index < 0:

                    raise RuntimeError(
                        f"{case_id}: missing RAMP local mapping."
                    )

                ramp_anchor_time[
                    local_index,
                    :
                ] = result[
                    "ramp_anchor_times"
                ]

                ramp_anchor_state[
                    local_index,
                    :,
                    :
                ] = result[
                    "ramp_anchor_states"
                ]

                ramp_anchor_reactivity[
                    local_index,
                    :
                ] = result[
                    "ramp_anchor_reactivity"
                ]

            # ==========================================================
            # METRICS
            # ==========================================================

            transport_min[
                case_index
            ] = float(
                result[
                    "transport_T_min_K"
                ]
            )

            transport_max[
                case_index
            ] = float(
                result[
                    "transport_T_max_K"
                ]
            )

            transport_upper_margin[
                case_index
            ] = float(
                result[
                    "transport_upper_margin_K"
                ]
            )

            power_min[
                case_index
            ] = float(
                result[
                    "power_min"
                ]
            )

            power_max[
                case_index
            ] = float(
                result[
                    "power_max"
                ]
            )

            fuel_min[
                case_index
            ] = float(
                result[
                    "fuel_T_min_K"
                ]
            )

            fuel_max[
                case_index
            ] = float(
                result[
                    "fuel_T_max_K"
                ]
            )

            bulk_min[
                case_index
            ] = float(
                result[
                    "bulk_T_min_K"
                ]
            )

            bulk_max[
                case_index
            ] = float(
                result[
                    "bulk_T_max_K"
                ]
            )

            # ==========================================================
            # FLUSH DATA BEFORE MARKING COMPLETE
            # ==========================================================

            flush_all(
                flushable_arrays
            )

            # ----------------------------------------------------------
            # Completion flag is LAST.
            # ----------------------------------------------------------

            case_status[
                case_index
            ] = STATUS_COMPLETE

            case_status.flush()

            new_case_times.append(
                case_elapsed
            )

            complete_now = int(
                np.sum(
                    np.asarray(
                        case_status
                    )
                    == STATUS_COMPLETE
                )
            )

            remaining_now = (
                total_cases
                - complete_now
            )

            average_new_time = float(
                np.mean(
                    new_case_times
                )
            )

            eta_seconds = (
                average_new_time
                * remaining_now
            )

            eta_hours = (
                eta_seconds
                / 3600.0
            )

            print(
                f"  PASS | "
                f"{case_elapsed:7.2f} s | "
                f"complete={complete_now:4d}/"
                f"{total_cases} | "
                f"ETA~{eta_hours:6.2f} h"
            )

            write_progress(

                progress_path,

                case_status=case_status,

                total_cases=total_cases,

                last_case_id=case_id,

                session_start=session_start,
            )

    except KeyboardInterrupt:

        flush_all(
            flushable_arrays
        )

        write_progress(

            progress_path,

            case_status=case_status,

            total_cases=total_cases,

            last_case_id=last_case_id,

            session_start=session_start,
        )

        complete_now = int(
            np.sum(
                np.asarray(
                    case_status
                )
                == STATUS_COMPLETE
            )
        )

        print()

        print(
            "=" * 82
        )

        print(
            "PRODUCTION GENERATION INTERRUPTED SAFELY"
        )

        print(
            "=" * 82
        )

        print()

        print(
            f"Completed cases : "
            f"{complete_now} / "
            f"{total_cases}"
        )

        print()

        print(
            "Run the same command again to resume."
        )

        raise SystemExit(
            130
        )

    # ======================================================================
    # FINAL GENERATION STATUS
    # ======================================================================

    flush_all(
        flushable_arrays
    )

    status_array = np.asarray(
        case_status
    )

    completed_count = int(
        np.sum(
            status_array
            == STATUS_COMPLETE
        )
    )

    failed_count = int(
        np.sum(
            status_array
            == STATUS_FAILED
        )
    )

    pending_count = int(
        np.sum(
            status_array
            == STATUS_PENDING
        )
    )

    generation_complete = bool(
        completed_count
        == total_cases
        and
        failed_count
        == 0
        and
        pending_count
        == 0
    )

    # ======================================================================
    # EXECUTION SUMMARY
    # ======================================================================

    write_execution_summary(

        summary_path,

        manifest=manifest,

        case_status=case_status,

        elapsed_s=elapsed_s,

        transport_min=transport_min,

        transport_max=transport_max,

        transport_upper_margin=(
            transport_upper_margin
        ),

        power_min=power_min,

        power_max=power_max,

        fuel_min=fuel_min,

        fuel_max=fuel_max,

        bulk_min=bulk_min,

        bulk_max=bulk_max,
    )

    write_progress(

        progress_path,

        case_status=case_status,

        total_cases=total_cases,

        last_case_id=last_case_id,

        session_start=session_start,
    )

    # ======================================================================
    # GLOBAL METRICS
    # ======================================================================

    if generation_complete:

        global_transport_min = float(
            np.min(
                np.asarray(
                    transport_min
                )
            )
        )

        global_transport_max = float(
            np.max(
                np.asarray(
                    transport_max
                )
            )
        )

        worst_upper_margin = float(
            np.min(
                np.asarray(
                    transport_upper_margin
                )
            )
        )

        overall_power_min = float(
            np.min(
                np.asarray(
                    power_min
                )
            )
        )

        overall_power_max = float(
            np.max(
                np.asarray(
                    power_max
                )
            )
        )

        overall_fuel_min = float(
            np.min(
                np.asarray(
                    fuel_min
                )
            )
        )

        overall_fuel_max = float(
            np.max(
                np.asarray(
                    fuel_max
                )
            )
        )

        overall_bulk_min = float(
            np.min(
                np.asarray(
                    bulk_min
                )
            )
        )

        overall_bulk_max = float(
            np.max(
                np.asarray(
                    bulk_max
                )
            )
        )

        total_case_compute_s = float(
            np.sum(
                np.asarray(
                    elapsed_s
                )
            )
        )

    else:

        global_transport_min = np.nan
        global_transport_max = np.nan
        worst_upper_margin = np.nan

        overall_power_min = np.nan
        overall_power_max = np.nan

        overall_fuel_min = np.nan
        overall_fuel_max = np.nan

        overall_bulk_min = np.nan
        overall_bulk_max = np.nan

        total_case_compute_s = np.nan

    # ======================================================================
    # GENERATION REPORT
    # ======================================================================

    with report_path.open(
        "w",
        encoding="utf-8",
    ) as f:

        f.write(
            "=" * 104
            + "\n"
        )

        f.write(
            "STEP 6 - PAPER-1 PRODUCTION-V1 "
            "DATASET GENERATION\n"
        )

        f.write(
            "=" * 104
            + "\n\n"
        )

        f.write(
            f"Project root: {root}\n"
        )

        f.write(
            f"Production directory: "
            f"{production_root}\n\n"
        )

        # --------------------------------------------------------------
        # Frozen provenance
        # --------------------------------------------------------------

        f.write(
            "FROZEN PROVENANCE\n"
        )

        f.write(
            "=" * 104
            + "\n"
        )

        f.write(
            f"Manifest SHA256       : "
            f"{manifest_hash}\n"
        )

        f.write(
            f"Contract SHA256       : "
            f"{contract172_hash}\n"
        )

        f.write(
            f"File-74 SHA256        : "
            f"{solver_hash}\n"
        )

        f.write(
            f"File-72 SHA256        : "
            f"{file72_hash}\n"
        )

        f.write(
            f"File-173 SHA256       : "
            f"{helper173_hash}\n"
        )

        f.write(
            f"File-174 SHA256       : "
            f"{generator174_hash}\n"
        )

        # --------------------------------------------------------------
        # Structure
        # --------------------------------------------------------------

        f.write(
            "\n\nDATASET STRUCTURE\n"
        )

        f.write(
            "=" * 104
            + "\n"
        )

        f.write(
            f"Production cases      : "
            f"{total_cases}\n"
        )

        f.write(
            f"STEP cases            : "
            f"{step_cases}\n"
        )

        f.write(
            f"RAMP cases            : "
            f"{ramp_cases}\n"
        )

        f.write(
            f"Global points/case    : "
            f"{global_points}\n"
        )

        f.write(
            f"STEP event points     : "
            f"{event_points}\n"
        )

        f.write(
            f"Dynamic state targets : "
            f"{state_count}\n"
        )

        f.write(
            f"Auxiliary fields      : "
            f"{auxiliary_count}\n"
        )

        f.write(
            "Raw dtype             : float64\n"
        )

        # --------------------------------------------------------------
        # Completion
        # --------------------------------------------------------------

        f.write(
            "\n\nGENERATION STATUS\n"
        )

        f.write(
            "=" * 104
            + "\n"
        )

        f.write(
            f"Complete cases        : "
            f"{completed_count}\n"
        )

        f.write(
            f"Failed cases          : "
            f"{failed_count}\n"
        )

        f.write(
            f"Pending cases         : "
            f"{pending_count}\n"
        )

        f.write(
            f"Generation complete   : "
            f"{generation_complete}\n"
        )

        # --------------------------------------------------------------
        # Physical / numerical ranges
        # --------------------------------------------------------------

        if generation_complete:

            f.write(
                "\n\nPRODUCTION RESPONSE RANGES\n"
            )

            f.write(
                "=" * 104
                + "\n"
            )

            f.write(
                f"Transport Tmin [K]       : "
                f"{global_transport_min:.6f}\n"
            )

            f.write(
                f"Transport Tmax [K]       : "
                f"{global_transport_max:.6f}\n"
            )

            f.write(
                f"Worst upper margin [K]    : "
                f"{worst_upper_margin:.6f}\n"
            )

            f.write(
                f"Normalized power min/max  : "
                f"{overall_power_min:.9g} / "
                f"{overall_power_max:.9g}\n"
            )

            f.write(
                f"Fuel T min/max [K]        : "
                f"{overall_fuel_min:.6f} / "
                f"{overall_fuel_max:.6f}\n"
            )

            f.write(
                f"Bulk T min/max [K]        : "
                f"{overall_bulk_min:.6f} / "
                f"{overall_bulk_max:.6f}\n"
            )

            f.write(
                f"Accumulated case time [h] : "
                f"{total_case_compute_s / 3600.0:.3f}\n"
            )

        # --------------------------------------------------------------
        # Final
        # --------------------------------------------------------------

        f.write(
            "\n\nSTEP-6 PRODUCTION GENERATION GATE\n"
        )

        f.write(
            "=" * 104
            + "\n"
        )

        if generation_complete:

            f.write(
                "PASS  All 2,177 frozen Production-V1 "
                "manifest cases were generated.\n"
            )

            f.write(
                "PASS  No failed trajectory remains.\n"
            )

            f.write(
                "PASS  No pending trajectory remains.\n"
            )

            f.write(
                "PASS  Production arrays and per-case "
                "metrics have been written.\n\n"
            )

            f.write(
                "GENERATION STATUS: COMPLETE\n\n"
            )

            f.write(
                "IMPORTANT:\n"
            )

            f.write(
                "Dataset generation is complete, but Step 6 "
                "is not formally closed until File 175 performs "
                "the final production dataset QA/integrity gate.\n\n"
            )

            f.write(
                "NEXT: FILE 175 - FINAL PRODUCTION DATASET QA\n"
            )

        else:

            f.write(
                "GENERATION STATUS: INCOMPLETE\n"
            )

        f.write(
            "\n"
            + "=" * 104
            + "\n"
        )

        f.write(
            "STATUS: STEP-6 PRODUCTION-V1 "
            "GENERATOR COMPLETE\n"
        )

    # ======================================================================
    # TERMINAL RESULT
    # ======================================================================

    print()

    print(
        "=" * 82
    )

    print(
        "PRODUCTION-V1 GENERATION RESULT"
    )

    print(
        "=" * 82
    )

    print()

    print(
        f"Complete cases           : "
        f"{completed_count} / "
        f"{total_cases}"
    )

    print(
        f"Failed cases             : "
        f"{failed_count}"
    )

    print(
        f"Pending cases            : "
        f"{pending_count}"
    )

    print()

    print(
        f"GENERATION COMPLETE      : "
        f"{generation_complete}"
    )

    if generation_complete:

        print()

        print(
            f"Transport Tmin [K]       : "
            f"{global_transport_min:.6f}"
        )

        print(
            f"Transport Tmax [K]       : "
            f"{global_transport_max:.6f}"
        )

        print(
            f"Worst upper margin [K]   : "
            f"{worst_upper_margin:.6f}"
        )

        print()

        print(
            f"Power range              : "
            f"{overall_power_min:.6f} "
            f"to "
            f"{overall_power_max:.6f}"
        )

        print(
            f"Fuel T range [K]         : "
            f"{overall_fuel_min:.3f} "
            f"to "
            f"{overall_fuel_max:.3f}"
        )

        print(
            f"Bulk T range [K]         : "
            f"{overall_bulk_min:.3f} "
            f"to "
            f"{overall_bulk_max:.3f}"
        )

    print()

    print(
        "Production directory:"
    )

    print(
        f"  {DATASET_DIRECTORY}/"
        f"{PRODUCTION_DIRECTORY}"
    )

    print()

    print(
        "Saved report:"
    )

    print(
        f"  {DATASET_DIRECTORY}/"
        f"{PRODUCTION_DIRECTORY}/"
        f"{REPORT_NAME}"
    )

    print()

    if generation_complete:

        print(
            "STATUS: COMPLETE 2,177-CASE "
            "PRODUCTION-V1 DATASET GENERATED"
        )

        print(
            "NEXT: FILE 175 - FINAL "
            "PRODUCTION DATASET QA / STEP-6 CLOSURE"
        )

    else:

        print(
            "STATUS: PRODUCTION GENERATION "
            "INCOMPLETE"
        )


if __name__ == "__main__":
    main()