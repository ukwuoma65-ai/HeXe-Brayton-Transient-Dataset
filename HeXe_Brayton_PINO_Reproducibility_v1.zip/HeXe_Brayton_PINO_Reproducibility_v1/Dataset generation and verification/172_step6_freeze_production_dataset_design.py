from __future__ import annotations

import csv
import hashlib
import json
import math
import re
from pathlib import Path

import numpy as np
from scipy.stats import qmc


# ============================================================================
# 172_step6_freeze_production_dataset_design.py
#
# STEP 6
# PRODUCTION DATASET DESIGN FREEZE
#
# PURPOSE
# -------
# Freeze the Paper-1 production dataset design after successful completion of:
#
#   File 166 - pilot manifest
#   File 167 - pilot execution
#   File 168 - quality / coverage analysis
#   File 169 - uniform temporal-resolution diagnosis
#   File 170 - fast-kinetics / multi-rate diagnosis
#   File 171 - complete multi-rate grid validation
#
#
# THIS FILE DEFINES:
#
#   1. production sample counts;
#   2. train / validation / ID-test / OOD / stress partitions;
#   3. independent Sobol sampling blocks;
#   4. final raw-data temporal representation;
#   5. PINO primary target variables;
#   6. auxiliary Brayton evaluation outputs;
#   7. production manifest;
#   8. reproducibility metadata.
#
#
# THIS FILE DOES NOT:
#
#   - execute production trajectories;
#   - change File 74;
#   - change Step-4 disturbance ranges;
#   - introduce new physical parameters;
#   - train the PINO;
#   - sample cp, shaft fraction, mass flow, load or sink temperature.
#
#
# DATASET-SIZE NOTE
# -----------------
# The production sample count is a PROJECT NUMERICAL DESIGN choice.
#
# It is not a physical constant.
#
# The design deliberately uses power-of-two Sobol blocks for reproducible,
# space-filling sampling of the already frozen low-dimensional disturbance
# domain.
#
# Dataset expansion should occur only if the later training/learning-curve
# analysis demonstrates that this frozen production dataset is insufficient.
# ============================================================================


# ============================================================================
# DIRECTORY / INPUT FILES
# ============================================================================

DATASET_DIRECTORY = "step6_dataset"

FILE166_CONTRACT = (
    "166_step6_pilot_dataset_contract.json"
)

FILE168_DERIVED_STATS = (
    "168_step6_derived_field_statistics.csv"
)

FILE171_REPORT = (
    "171_step6_complete_multirate_grid_validation_report.txt"
)


# ============================================================================
# OUTPUT FILES
# ============================================================================

OUTPUT_MANIFEST = (
    "172_step6_production_manifest.csv"
)

OUTPUT_CONTRACT = (
    "172_step6_production_dataset_contract.json"
)

OUTPUT_REPORT = (
    "172_step6_production_dataset_design_report.txt"
)


# ============================================================================
# FROZEN PHYSICS / STEP-4 POLICY
# ============================================================================

BETA_EFF = 6.7327070195e-3

BETA_EFF_PCM = 673.27070195

TRAJECTORY_HORIZON_S = 600.0


# ---------------------------------------------------------------------------
# Reactivity amplitude policy
# ---------------------------------------------------------------------------

ID_MIN_CENTS = -10.0
ID_MAX_CENTS = +10.0

OOD_NEG_MIN_CENTS = -20.0
OOD_NEG_MAX_CENTS = -10.0

OOD_POS_MIN_CENTS = +10.0
OOD_POS_MAX_CENTS = +15.0

STRESS_NEG_CENTS = -30.0
STRESS_POS_CENTS = +17.5


# ---------------------------------------------------------------------------
# STEP timing
# ---------------------------------------------------------------------------

STEP_ONSET_MIN_S = 60.0
STEP_ONSET_MAX_S = 180.0


# ---------------------------------------------------------------------------
# RAMP timing
# ---------------------------------------------------------------------------

RAMP_ONSET_MIN_S = 60.0
RAMP_ONSET_MAX_S = 120.0

RAMP_DURATION_MIN_S = 30.0
RAMP_DURATION_MAX_S = 120.0

LATEST_RAMP_COMPLETION_S = 240.0


# ============================================================================
# FILE-171 VALIDATED TEMPORAL REPRESENTATION
# ============================================================================

GLOBAL_DT_S = 1.0

GLOBAL_POINTS = 601


# STEP prompt region
STEP_FAST_DT_S = 1.0e-5
STEP_FAST_END_S = 0.010


# STEP early transition region
STEP_TRANSITION_DT_S = 0.25
STEP_TRANSITION_END_S = 5.0


# Expected merged event-local point count from File 171.
STEP_EVENT_LOCAL_POINTS = 1021


# ============================================================================
# PRODUCTION SAMPLE COUNTS
#
# All Sobol counts are powers of two.
# ============================================================================


# ---------------------------------------------------------------------------
# ID TRAINING
# ---------------------------------------------------------------------------

TRAIN_ID_STEP = 512
TRAIN_ID_RAMP = 512


# ---------------------------------------------------------------------------
# ID VALIDATION
# ---------------------------------------------------------------------------

VALIDATION_ID_STEP = 128
VALIDATION_ID_RAMP = 128


# ---------------------------------------------------------------------------
# Independent ID TEST
# ---------------------------------------------------------------------------

TEST_ID_STEP = 128
TEST_ID_RAMP = 128


# ---------------------------------------------------------------------------
# Negative amplitude OOD test
# ---------------------------------------------------------------------------

OOD_NEG_STEP = 128
OOD_NEG_RAMP = 128


# ---------------------------------------------------------------------------
# Positive amplitude OOD test
# ---------------------------------------------------------------------------

OOD_POS_STEP = 128
OOD_POS_RAMP = 128


# ---------------------------------------------------------------------------
# Reserved stress cases
#
# Fixed amplitudes:
#
#   -30 cents
#   +17.5 cents
#
# Timing remains sampled.
# ---------------------------------------------------------------------------

STRESS_NEG_STEP = 32
STRESS_NEG_RAMP = 32

STRESS_POS_STEP = 32
STRESS_POS_RAMP = 32


# ---------------------------------------------------------------------------
# Baseline
# ---------------------------------------------------------------------------

BASELINE_CASES = 1


EXPECTED_TOTAL_CASES = (
    BASELINE_CASES
    + TRAIN_ID_STEP
    + TRAIN_ID_RAMP
    + VALIDATION_ID_STEP
    + VALIDATION_ID_RAMP
    + TEST_ID_STEP
    + TEST_ID_RAMP
    + OOD_NEG_STEP
    + OOD_NEG_RAMP
    + OOD_POS_STEP
    + OOD_POS_RAMP
    + STRESS_NEG_STEP
    + STRESS_NEG_RAMP
    + STRESS_POS_STEP
    + STRESS_POS_RAMP
)


EXPECTED_STEP_CASES = (
    TRAIN_ID_STEP
    + VALIDATION_ID_STEP
    + TEST_ID_STEP
    + OOD_NEG_STEP
    + OOD_POS_STEP
    + STRESS_NEG_STEP
    + STRESS_POS_STEP
)


EXPECTED_RAMP_CASES = (
    TRAIN_ID_RAMP
    + VALIDATION_ID_RAMP
    + TEST_ID_RAMP
    + OOD_NEG_RAMP
    + OOD_POS_RAMP
    + STRESS_NEG_RAMP
    + STRESS_POS_RAMP
)


# ============================================================================
# REPRODUCIBILITY
# ============================================================================

SOBOL_BASE_SEED = 20260929


# Unique deterministic seed offsets.
BLOCK_SEEDS = {

    "TRAIN_ID_STEP":
        SOBOL_BASE_SEED + 101,

    "TRAIN_ID_RAMP":
        SOBOL_BASE_SEED + 102,

    "VALIDATION_ID_STEP":
        SOBOL_BASE_SEED + 201,

    "VALIDATION_ID_RAMP":
        SOBOL_BASE_SEED + 202,

    "TEST_ID_STEP":
        SOBOL_BASE_SEED + 301,

    "TEST_ID_RAMP":
        SOBOL_BASE_SEED + 302,

    "OOD_NEG_STEP":
        SOBOL_BASE_SEED + 401,

    "OOD_NEG_RAMP":
        SOBOL_BASE_SEED + 402,

    "OOD_POS_STEP":
        SOBOL_BASE_SEED + 501,

    "OOD_POS_RAMP":
        SOBOL_BASE_SEED + 502,

    "STRESS_NEG_STEP":
        SOBOL_BASE_SEED + 601,

    "STRESS_NEG_RAMP":
        SOBOL_BASE_SEED + 602,

    "STRESS_POS_STEP":
        SOBOL_BASE_SEED + 701,

    "STRESS_POS_RAMP":
        SOBOL_BASE_SEED + 702,
}


# ============================================================================
# STORAGE POLICY
# ============================================================================

RAW_REFERENCE_DTYPE = "float64"

TRAINING_DTYPE = "float32"


# ============================================================================
# HELPERS
# ============================================================================


def require_file(
    path: Path,
) -> Path:

    if not path.exists():

        raise FileNotFoundError(
            f"Required file missing: {path}"
        )

    return path


def safe_read(
    path: Path,
) -> str:

    encodings = (
        "utf-8",
        "utf-8-sig",
        "cp1252",
        "latin-1",
    )

    for encoding in encodings:

        try:

            return path.read_text(
                encoding=encoding
            )

        except UnicodeDecodeError:

            continue

        except OSError:

            return ""

    return ""


def sha256_file(
    path: Path,
) -> str:

    digest = hashlib.sha256()

    with path.open(
        "rb"
    ) as f:

        while True:

            block = f.read(
                1024 * 1024
            )

            if not block:

                break

            digest.update(
                block
            )

    return digest.hexdigest()


def read_csv(
    path: Path,
) -> list[dict[str, str]]:

    with path.open(
        "r",
        encoding="utf-8-sig",
        newline="",
    ) as f:

        return list(
            csv.DictReader(
                f
            )
        )


def write_csv(
    path: Path,
    rows: list[dict[str, object]],
) -> None:

    if not rows:

        raise RuntimeError(
            "Cannot write empty manifest."
        )

    fieldnames = list(
        rows[
            0
        ].keys()
    )

    with path.open(
        "w",
        newline="",
        encoding="utf-8-sig",
    ) as f:

        writer = csv.DictWriter(
            f,
            fieldnames=fieldnames,
        )

        writer.writeheader()

        writer.writerows(
            rows
        )


def is_power_of_two(
    value: int,
) -> bool:

    return (
        value > 0
        and
        (
            value
            & (
                value - 1
            )
        )
        == 0
    )


def sobol_points(
    dimension: int,
    count: int,
    seed: int,
) -> np.ndarray:

    if not is_power_of_two(
        count
    ):

        raise ValueError(
            f"Sobol count must be power of two: {count}"
        )

    m = int(
        math.log2(
            count
        )
    )

    sampler = qmc.Sobol(
        d=dimension,
        scramble=True,
        seed=seed,
    )

    return sampler.random_base2(
        m=m
    )


def scale(
    value: float,
    minimum: float,
    maximum: float,
) -> float:

    return (
        minimum
        + value
        * (
            maximum
            - minimum
        )
    )


def cents_to_reactivity(
    cents: float,
) -> float:

    return (
        cents
        / 100.0
        * BETA_EFF
    )


def cents_to_pcm(
    cents: float,
) -> float:

    return (
        cents
        / 100.0
        * BETA_EFF_PCM
    )


# ============================================================================
# VALIDATED MULTI-RATE GRID
# ============================================================================


def uniform_grid(
    start: float,
    end: float,
    dt: float,
) -> np.ndarray:

    if end < start:

        raise ValueError(
            "Grid end before start."
        )

    count = int(
        math.floor(
            (
                end
                - start
            )
            / dt
            + 1.0e-12
        )
    )

    grid = (
        start
        + np.arange(
            count + 1,
            dtype=float,
        )
        * dt
    )

    if (
        grid[
            -1
        ]
        < end
        - 1.0e-12
    ):

        grid = np.append(
            grid,
            end,
        )

    return grid


def build_step_event_relative_grid() -> np.ndarray:

    fast = uniform_grid(
        0.0,
        STEP_FAST_END_S,
        STEP_FAST_DT_S,
    )

    transition = uniform_grid(
        STEP_FAST_END_S,
        STEP_TRANSITION_END_S,
        STEP_TRANSITION_DT_S,
    )

    merged = np.unique(
        np.round(
            np.concatenate(
                (
                    fast,
                    transition,
                )
            ),
            decimals=12,
        )
    )

    return merged


# ============================================================================
# MANIFEST ROW
# ============================================================================


def make_row(
    case_number: int,
    partition: str,
    regime: str,
    waveform: str,
    amplitude_cents: float,
    onset_s: float,
    ramp_duration_s: float | None,
    sampling_block: str,
    sobol_seed: int | None,
) -> dict[str, object]:

    if waveform == "BASELINE":

        completion_s = 0.0

        storage_view = (
            "GLOBAL"
        )

    elif waveform == "STEP_HOLD":

        completion_s = (
            onset_s
        )

        storage_view = (
            "GLOBAL+STEP_EVENT_LOCAL"
        )

    elif waveform == "LINEAR_RAMP_HOLD":

        if ramp_duration_s is None:

            raise ValueError(
                "Ramp duration required."
            )

        completion_s = (
            onset_s
            + ramp_duration_s
        )

        storage_view = (
            "GLOBAL+RAMP_EVENT_ANCHORS"
        )

    else:

        raise ValueError(
            f"Unknown waveform: {waveform}"
        )

    return {

        "case_id":
            f"PROD_{case_number:05d}",

        "dataset_version":
            "PAPER1_PRODUCTION_V1",

        "partition":
            partition,

        "regime":
            regime,

        "waveform":
            waveform,

        "amplitude_cents":
            float(
                amplitude_cents
            ),

        "amplitude_pcm":
            cents_to_pcm(
                amplitude_cents
            ),

        "amplitude_delta_k_over_k":
            cents_to_reactivity(
                amplitude_cents
            ),

        "event_onset_s":
            float(
                onset_s
            ),

        "ramp_duration_s":
            (
                ""
                if ramp_duration_s
                is None
                else float(
                    ramp_duration_s
                )
            ),

        "event_completion_s":
            float(
                completion_s
            ),

        "trajectory_horizon_s":
            TRAJECTORY_HORIZON_S,

        "initial_state_policy":
            "FILE74_RATED_REFERENCE_STATE",

        "independent_input":
            "external_reactivity",

        "sampling_method":
            (
                "EXACT_BASELINE"
                if waveform
                == "BASELINE"
                else "SCRAMBLED_SOBOL"
            ),

        "sampling_block":
            sampling_block,

        "sobol_seed":
            (
                ""
                if sobol_seed
                is None
                else int(
                    sobol_seed
                )
            ),

        "storage_view":
            storage_view,

        "global_dt_s":
            GLOBAL_DT_S,

        "step_fast_dt_s":
            (
                STEP_FAST_DT_S
                if waveform
                == "STEP_HOLD"
                else ""
            ),

        "step_fast_window_s":
            (
                STEP_FAST_END_S
                if waveform
                == "STEP_HOLD"
                else ""
            ),

        "step_transition_dt_s":
            (
                STEP_TRANSITION_DT_S
                if waveform
                == "STEP_HOLD"
                else ""
            ),

        "step_transition_window_s":
            (
                STEP_TRANSITION_END_S
                if waveform
                == "STEP_HOLD"
                else ""
            ),

        "training_eligible":
            bool(
                partition
                == "TRAIN"
            ),

        "validation_eligible":
            bool(
                partition
                == "VALIDATION"
            ),

        "final_test_only":
            bool(
                partition
                in (
                    "ID_TEST",
                    "OOD_NEG_TEST",
                    "OOD_POS_TEST",
                    "STRESS_TEST",
                )
            ),
    }


# ============================================================================
# VARIABLE-AMPLITUDE SOBOL BLOCKS
# ============================================================================


def add_step_block(
    rows,
    case_number: int,
    partition: str,
    regime: str,
    count: int,
    amplitude_min: float,
    amplitude_max: float,
    block_name: str,
) -> int:

    seed = BLOCK_SEEDS[
        block_name
    ]

    points = sobol_points(
        dimension=2,
        count=count,
        seed=seed,
    )

    for point in points:

        amplitude = scale(
            point[
                0
            ],
            amplitude_min,
            amplitude_max,
        )

        onset = scale(
            point[
                1
            ],
            STEP_ONSET_MIN_S,
            STEP_ONSET_MAX_S,
        )

        rows.append(
            make_row(
                case_number=case_number,

                partition=partition,

                regime=regime,

                waveform="STEP_HOLD",

                amplitude_cents=amplitude,

                onset_s=onset,

                ramp_duration_s=None,

                sampling_block=block_name,

                sobol_seed=seed,
            )
        )

        case_number += 1

    return case_number


def add_ramp_block(
    rows,
    case_number: int,
    partition: str,
    regime: str,
    count: int,
    amplitude_min: float,
    amplitude_max: float,
    block_name: str,
) -> int:

    seed = BLOCK_SEEDS[
        block_name
    ]

    points = sobol_points(
        dimension=3,
        count=count,
        seed=seed,
    )

    for point in points:

        amplitude = scale(
            point[
                0
            ],
            amplitude_min,
            amplitude_max,
        )

        onset = scale(
            point[
                1
            ],
            RAMP_ONSET_MIN_S,
            RAMP_ONSET_MAX_S,
        )

        duration = scale(
            point[
                2
            ],
            RAMP_DURATION_MIN_S,
            RAMP_DURATION_MAX_S,
        )

        completion = (
            onset
            + duration
        )

        if (
            completion
            > LATEST_RAMP_COMPLETION_S
            + 1.0e-10
        ):

            raise RuntimeError(
                f"{block_name}: ramp completion > 240 s."
            )

        rows.append(
            make_row(
                case_number=case_number,

                partition=partition,

                regime=regime,

                waveform="LINEAR_RAMP_HOLD",

                amplitude_cents=amplitude,

                onset_s=onset,

                ramp_duration_s=duration,

                sampling_block=block_name,

                sobol_seed=seed,
            )
        )

        case_number += 1

    return case_number


# ============================================================================
# FIXED-AMPLITUDE STRESS SOBOL BLOCKS
# ============================================================================


def add_stress_step_block(
    rows,
    case_number: int,
    amplitude_cents: float,
    count: int,
    block_name: str,
) -> int:

    seed = BLOCK_SEEDS[
        block_name
    ]

    points = sobol_points(
        dimension=1,
        count=count,
        seed=seed,
    )

    for point in points:

        onset = scale(
            point[
                0
            ],
            STEP_ONSET_MIN_S,
            STEP_ONSET_MAX_S,
        )

        rows.append(
            make_row(
                case_number=case_number,

                partition="STRESS_TEST",

                regime="STRESS",

                waveform="STEP_HOLD",

                amplitude_cents=amplitude_cents,

                onset_s=onset,

                ramp_duration_s=None,

                sampling_block=block_name,

                sobol_seed=seed,
            )
        )

        case_number += 1

    return case_number


def add_stress_ramp_block(
    rows,
    case_number: int,
    amplitude_cents: float,
    count: int,
    block_name: str,
) -> int:

    seed = BLOCK_SEEDS[
        block_name
    ]

    points = sobol_points(
        dimension=2,
        count=count,
        seed=seed,
    )

    for point in points:

        onset = scale(
            point[
                0
            ],
            RAMP_ONSET_MIN_S,
            RAMP_ONSET_MAX_S,
        )

        duration = scale(
            point[
                1
            ],
            RAMP_DURATION_MIN_S,
            RAMP_DURATION_MAX_S,
        )

        if (
            onset
            + duration
            > LATEST_RAMP_COMPLETION_S
            + 1.0e-10
        ):

            raise RuntimeError(
                f"{block_name}: ramp completion > 240 s."
            )

        rows.append(
            make_row(
                case_number=case_number,

                partition="STRESS_TEST",

                regime="STRESS",

                waveform="LINEAR_RAMP_HOLD",

                amplitude_cents=amplitude_cents,

                onset_s=onset,

                ramp_duration_s=duration,

                sampling_block=block_name,

                sobol_seed=seed,
            )
        )

        case_number += 1

    return case_number


# ============================================================================
# MANIFEST VALIDATION
# ============================================================================


def validate_manifest(
    rows: list[
        dict[str, object]
    ],
) -> list[str]:

    errors = []

    if (
        len(
            rows
        )
        != EXPECTED_TOTAL_CASES
    ):

        errors.append(
            f"Expected {EXPECTED_TOTAL_CASES} cases, "
            f"received {len(rows)}."
        )

    case_ids = [
        str(
            row[
                "case_id"
            ]
        )
        for row
        in rows
    ]

    if (
        len(
            case_ids
        )
        != len(
            set(
                case_ids
            )
        )
    ):

        errors.append(
            "Duplicate case IDs detected."
        )

    # ------------------------------------------------------------------
    # Exact parameter duplicates
    # ------------------------------------------------------------------

    seen = {}

    for row in rows:

        if (
            row[
                "waveform"
            ]
            == "BASELINE"
        ):

            continue

        duration = (
            None
            if row[
                "ramp_duration_s"
            ]
            == ""
            else round(
                float(
                    row[
                        "ramp_duration_s"
                    ]
                ),
                12,
            )
        )

        key = (
            str(
                row[
                    "waveform"
                ]
            ),
            round(
                float(
                    row[
                        "amplitude_cents"
                    ]
                ),
                12,
            ),
            round(
                float(
                    row[
                        "event_onset_s"
                    ]
                ),
                12,
            ),
            duration,
        )

        if key in seen:

            errors.append(
                "Duplicate physical input combination: "
                f"{seen[key]} and "
                f"{row['case_id']}"
            )

        else:

            seen[
                key
            ] = row[
                "case_id"
            ]

    # ------------------------------------------------------------------
    # Train / validation must be ID only.
    # ------------------------------------------------------------------

    for row in rows:

        partition = str(
            row[
                "partition"
            ]
        )

        regime = str(
            row[
                "regime"
            ]
        )

        if (
            partition
            in (
                "TRAIN",
                "VALIDATION",
                "ID_TEST",
            )
            and
            regime
            not in (
                "ID",
                "BASELINE",
            )
        ):

            errors.append(
                f"{row['case_id']}: "
                f"{partition} contains non-ID regime."
            )

        if (
            partition
            == "TRAIN"
            and
            regime
            in (
                "OOD_NEGATIVE",
                "OOD_POSITIVE",
                "STRESS",
            )
        ):

            errors.append(
                f"{row['case_id']}: "
                "OOD/stress leaked into training."
            )

    # ------------------------------------------------------------------
    # Amplitude domains
    # ------------------------------------------------------------------

    for row in rows:

        regime = str(
            row[
                "regime"
            ]
        )

        amplitude = float(
            row[
                "amplitude_cents"
            ]
        )

        if regime == "BASELINE":

            if not np.isclose(
                amplitude,
                0.0,
            ):

                errors.append(
                    f"{row['case_id']}: "
                    "baseline amplitude not zero."
                )

        elif regime == "ID":

            if not (
                ID_MIN_CENTS
                <= amplitude
                <= ID_MAX_CENTS
            ):

                errors.append(
                    f"{row['case_id']}: "
                    "ID amplitude outside range."
                )

        elif regime == "OOD_NEGATIVE":

            if not (
                OOD_NEG_MIN_CENTS
                <= amplitude
                <= OOD_NEG_MAX_CENTS
            ):

                errors.append(
                    f"{row['case_id']}: "
                    "negative OOD amplitude outside range."
                )

            if np.isclose(
                amplitude,
                ID_MIN_CENTS,
                atol=1.0e-12,
            ):

                errors.append(
                    f"{row['case_id']}: "
                    "OOD negative sample exactly on ID boundary."
                )

        elif regime == "OOD_POSITIVE":

            if not (
                OOD_POS_MIN_CENTS
                <= amplitude
                <= OOD_POS_MAX_CENTS
            ):

                errors.append(
                    f"{row['case_id']}: "
                    "positive OOD amplitude outside range."
                )

            if np.isclose(
                amplitude,
                ID_MAX_CENTS,
                atol=1.0e-12,
            ):

                errors.append(
                    f"{row['case_id']}: "
                    "OOD positive sample exactly on ID boundary."
                )

        elif regime == "STRESS":

            if not (
                np.isclose(
                    amplitude,
                    STRESS_NEG_CENTS,
                )
                or
                np.isclose(
                    amplitude,
                    STRESS_POS_CENTS,
                )
            ):

                errors.append(
                    f"{row['case_id']}: "
                    "invalid stress amplitude."
                )

    return errors


# ============================================================================
# MAIN
# ============================================================================


def main() -> None:

    root = Path(
        __file__
    ).resolve().parent

    dataset_root = (
        root
        / DATASET_DIRECTORY
    )

    dataset_root.mkdir(
        parents=True,
        exist_ok=True,
    )

    contract166_path = require_file(
        dataset_root
        / FILE166_CONTRACT
    )

    derived168_path = require_file(
        dataset_root
        / FILE168_DERIVED_STATS
    )

    report171_path = require_file(
        dataset_root
        / FILE171_REPORT
    )

    # ======================================================================
    # CONFIRM FILE-171 FINAL GRID
    # ======================================================================

    report171 = safe_read(
        report171_path
    )

    if (
        "COMPLETE MULTI-RATE GRID PASS: True"
        not in report171
    ):

        raise RuntimeError(
            "File 171 does not confirm a passing "
            "complete multi-rate grid."
        )

    transition_match = re.search(
        r"Selected transition dt \[s\]\s*:\s*"
        r"([0-9.]+)",
        report171,
    )

    if transition_match is None:

        raise RuntimeError(
            "Could not extract selected File-171 "
            "transition timestep."
        )

    file171_transition_dt = float(
        transition_match.group(
            1
        )
    )

    if not np.isclose(
        file171_transition_dt,
        STEP_TRANSITION_DT_S,
        atol=1.0e-12,
    ):

        raise RuntimeError(
            "File-171 selected transition dt does not "
            "match the intended frozen 0.25-s value."
        )

    # ======================================================================
    # READ PILOT CONTRACT
    # ======================================================================

    with contract166_path.open(
        "r",
        encoding="utf-8",
    ) as f:

        pilot_contract = json.load(
            f
        )

    state_names = list(
        pilot_contract[
            "initial_state"
        ][
            "state_names"
        ]
    )

    if len(
        state_names
    ) != 10:

        raise RuntimeError(
            "Expected 10 File-74 dynamic states."
        )

    # ======================================================================
    # READ FILE-168 DERIVED FIELD CLASSIFICATION
    # ======================================================================

    derived_rows = read_csv(
        derived168_path
    )

    varying_derived_fields = []

    constant_derived_fields = []

    for row in derived_rows:

        name = (
            row[
                "field_name"
            ]
        )

        classification = (
            row[
                "classification"
            ]
            .strip()
            .upper()
        )

        if classification == "VARYING":

            varying_derived_fields.append(
                name
            )

        elif classification == "EFFECTIVELY_CONSTANT":

            constant_derived_fields.append(
                name
            )

        else:

            raise RuntimeError(
                "Unknown File-168 derived-field "
                f"classification: {classification}"
            )

    if (
        len(
            varying_derived_fields
        )
        != 9
    ):

        raise RuntimeError(
            "Expected 9 varying derived fields from "
            f"File 168, found {len(varying_derived_fields)}."
        )

    if (
        len(
            constant_derived_fields
        )
        != 17
    ):

        raise RuntimeError(
            "Expected 17 effectively constant fields "
            f"from File 168, found "
            f"{len(constant_derived_fields)}."
        )

    # ======================================================================
    # BUILD VALIDATED EVENT-LOCAL GRID
    # ======================================================================

    event_relative_time = (
        build_step_event_relative_grid()
    )

    if (
        len(
            event_relative_time
        )
        != STEP_EVENT_LOCAL_POINTS
    ):

        raise RuntimeError(
            "Validated STEP event-local grid does "
            f"not contain {STEP_EVENT_LOCAL_POINTS} points. "
            f"Received {len(event_relative_time)}."
        )

    global_time = uniform_grid(
        0.0,
        TRAJECTORY_HORIZON_S,
        GLOBAL_DT_S,
    )

    if (
        len(
            global_time
        )
        != GLOBAL_POINTS
    ):

        raise RuntimeError(
            "Global grid does not contain 601 points."
        )

    # ======================================================================
    # BUILD PRODUCTION MANIFEST
    # ======================================================================

    rows: list[
        dict[str, object]
    ] = []

    case_number = 1

    # ------------------------------------------------------------------
    # Baseline belongs to TRAIN reference set.
    # ------------------------------------------------------------------

    rows.append(
        make_row(
            case_number=case_number,

            partition="TRAIN",

            regime="BASELINE",

            waveform="BASELINE",

            amplitude_cents=0.0,

            onset_s=0.0,

            ramp_duration_s=None,

            sampling_block="EXACT_BASELINE",

            sobol_seed=None,
        )
    )

    case_number += 1

    # ==================================================================
    # ID TRAIN
    # ==================================================================

    case_number = add_step_block(
        rows=rows,

        case_number=case_number,

        partition="TRAIN",

        regime="ID",

        count=TRAIN_ID_STEP,

        amplitude_min=ID_MIN_CENTS,

        amplitude_max=ID_MAX_CENTS,

        block_name="TRAIN_ID_STEP",
    )

    case_number = add_ramp_block(
        rows=rows,

        case_number=case_number,

        partition="TRAIN",

        regime="ID",

        count=TRAIN_ID_RAMP,

        amplitude_min=ID_MIN_CENTS,

        amplitude_max=ID_MAX_CENTS,

        block_name="TRAIN_ID_RAMP",
    )

    # ==================================================================
    # ID VALIDATION
    # ==================================================================

    case_number = add_step_block(
        rows=rows,

        case_number=case_number,

        partition="VALIDATION",

        regime="ID",

        count=VALIDATION_ID_STEP,

        amplitude_min=ID_MIN_CENTS,

        amplitude_max=ID_MAX_CENTS,

        block_name="VALIDATION_ID_STEP",
    )

    case_number = add_ramp_block(
        rows=rows,

        case_number=case_number,

        partition="VALIDATION",

        regime="ID",

        count=VALIDATION_ID_RAMP,

        amplitude_min=ID_MIN_CENTS,

        amplitude_max=ID_MAX_CENTS,

        block_name="VALIDATION_ID_RAMP",
    )

    # ==================================================================
    # ID TEST
    # ==================================================================

    case_number = add_step_block(
        rows=rows,

        case_number=case_number,

        partition="ID_TEST",

        regime="ID",

        count=TEST_ID_STEP,

        amplitude_min=ID_MIN_CENTS,

        amplitude_max=ID_MAX_CENTS,

        block_name="TEST_ID_STEP",
    )

    case_number = add_ramp_block(
        rows=rows,

        case_number=case_number,

        partition="ID_TEST",

        regime="ID",

        count=TEST_ID_RAMP,

        amplitude_min=ID_MIN_CENTS,

        amplitude_max=ID_MAX_CENTS,

        block_name="TEST_ID_RAMP",
    )

    # ==================================================================
    # NEGATIVE OOD TEST
    # ==================================================================

    case_number = add_step_block(
        rows=rows,

        case_number=case_number,

        partition="OOD_NEG_TEST",

        regime="OOD_NEGATIVE",

        count=OOD_NEG_STEP,

        amplitude_min=OOD_NEG_MIN_CENTS,

        amplitude_max=OOD_NEG_MAX_CENTS,

        block_name="OOD_NEG_STEP",
    )

    case_number = add_ramp_block(
        rows=rows,

        case_number=case_number,

        partition="OOD_NEG_TEST",

        regime="OOD_NEGATIVE",

        count=OOD_NEG_RAMP,

        amplitude_min=OOD_NEG_MIN_CENTS,

        amplitude_max=OOD_NEG_MAX_CENTS,

        block_name="OOD_NEG_RAMP",
    )

    # ==================================================================
    # POSITIVE OOD TEST
    # ==================================================================

    case_number = add_step_block(
        rows=rows,

        case_number=case_number,

        partition="OOD_POS_TEST",

        regime="OOD_POSITIVE",

        count=OOD_POS_STEP,

        amplitude_min=OOD_POS_MIN_CENTS,

        amplitude_max=OOD_POS_MAX_CENTS,

        block_name="OOD_POS_STEP",
    )

    case_number = add_ramp_block(
        rows=rows,

        case_number=case_number,

        partition="OOD_POS_TEST",

        regime="OOD_POSITIVE",

        count=OOD_POS_RAMP,

        amplitude_min=OOD_POS_MIN_CENTS,

        amplitude_max=OOD_POS_MAX_CENTS,

        block_name="OOD_POS_RAMP",
    )

    # ==================================================================
    # RESERVED STRESS TESTS
    # ==================================================================

    case_number = add_stress_step_block(
        rows=rows,

        case_number=case_number,

        amplitude_cents=STRESS_NEG_CENTS,

        count=STRESS_NEG_STEP,

        block_name="STRESS_NEG_STEP",
    )

    case_number = add_stress_ramp_block(
        rows=rows,

        case_number=case_number,

        amplitude_cents=STRESS_NEG_CENTS,

        count=STRESS_NEG_RAMP,

        block_name="STRESS_NEG_RAMP",
    )

    case_number = add_stress_step_block(
        rows=rows,

        case_number=case_number,

        amplitude_cents=STRESS_POS_CENTS,

        count=STRESS_POS_STEP,

        block_name="STRESS_POS_STEP",
    )

    case_number = add_stress_ramp_block(
        rows=rows,

        case_number=case_number,

        amplitude_cents=STRESS_POS_CENTS,

        count=STRESS_POS_RAMP,

        block_name="STRESS_POS_RAMP",
    )

    # ======================================================================
    # VALIDATE
    # ======================================================================

    errors = validate_manifest(
        rows
    )

    if errors:

        print(
            "PRODUCTION MANIFEST VALIDATION FAILED"
        )

        for error in errors:

            print(
                f"  - {error}"
            )

        raise RuntimeError(
            "Production dataset design failed validation."
        )

    # ======================================================================
    # COUNTS
    # ======================================================================

    partition_counts = {}

    regime_counts = {}

    waveform_counts = {}

    cross_counts = {}

    for row in rows:

        partition = str(
            row[
                "partition"
            ]
        )

        regime = str(
            row[
                "regime"
            ]
        )

        waveform = str(
            row[
                "waveform"
            ]
        )

        partition_counts[
            partition
        ] = (
            partition_counts.get(
                partition,
                0,
            )
            + 1
        )

        regime_counts[
            regime
        ] = (
            regime_counts.get(
                regime,
                0,
            )
            + 1
        )

        waveform_counts[
            waveform
        ] = (
            waveform_counts.get(
                waveform,
                0,
            )
            + 1
        )

        key = (
            partition,
            waveform,
        )

        cross_counts[
            key
        ] = (
            cross_counts.get(
                key,
                0,
            )
            + 1
        )

    actual_step_cases = (
        waveform_counts.get(
            "STEP_HOLD",
            0,
        )
    )

    actual_ramp_cases = (
        waveform_counts.get(
            "LINEAR_RAMP_HOLD",
            0,
        )
    )

    if (
        actual_step_cases
        != EXPECTED_STEP_CASES
    ):

        raise RuntimeError(
            "Unexpected production STEP case count."
        )

    if (
        actual_ramp_cases
        != EXPECTED_RAMP_CASES
    ):

        raise RuntimeError(
            "Unexpected production RAMP case count."
        )

    # ======================================================================
    # SAVE MANIFEST
    # ======================================================================

    manifest_path = (
        dataset_root
        / OUTPUT_MANIFEST
    )

    write_csv(
        manifest_path,
        rows,
    )

    manifest_hash = (
        sha256_file(
            manifest_path
        )
    )

    # ======================================================================
    # STORAGE ESTIMATE
    # ======================================================================

    float64_bytes = 8

    global_state_bytes = (
        EXPECTED_TOTAL_CASES
        * GLOBAL_POINTS
        * len(
            state_names
        )
        * float64_bytes
    )

    global_input_bytes = (
        EXPECTED_TOTAL_CASES
        * GLOBAL_POINTS
        * float64_bytes
    )

    global_aux_bytes = (
        EXPECTED_TOTAL_CASES
        * GLOBAL_POINTS
        * len(
            varying_derived_fields
        )
        * float64_bytes
    )

    event_state_bytes = (
        EXPECTED_STEP_CASES
        * STEP_EVENT_LOCAL_POINTS
        * len(
            state_names
        )
        * float64_bytes
    )

    event_input_bytes = (
        EXPECTED_STEP_CASES
        * STEP_EVENT_LOCAL_POINTS
        * float64_bytes
    )

    estimated_raw_bytes = (
        global_state_bytes
        + global_input_bytes
        + global_aux_bytes
        + event_state_bytes
        + event_input_bytes
    )

    estimated_raw_mib = (
        estimated_raw_bytes
        / (
            1024 ** 2
        )
    )

    # ======================================================================
    # PRODUCTION CONTRACT
    # ======================================================================

    contract = {

        "methodology_step":
            6,

        "dataset_version":
            "PAPER1_PRODUCTION_V1",

        "design_status":
            "FROZEN",

        "production_case_count":
            EXPECTED_TOTAL_CASES,

        "partition_counts":
            partition_counts,

        "regime_counts":
            regime_counts,

        "waveform_counts":
            waveform_counts,

        "sampling_policy": {

            "method":
                "INDEPENDENT_SCRAMBLED_SOBOL_BLOCKS",

            "base_seed":
                SOBOL_BASE_SEED,

            "block_seeds":
                BLOCK_SEEDS,

            "purpose":
                (
                    "SPACE_FILLING_DESIGN_OF_FROZEN_"
                    "DISTURBANCE_DOMAIN"
                ),

            "not_physical_uncertainty":
                True,
        },

        "input_space": {

            "independent_input":
                "external_reactivity",

            "ID_amplitude_cents":
                [
                    ID_MIN_CENTS,
                    ID_MAX_CENTS,
                ],

            "OOD_negative_cents":
                [
                    OOD_NEG_MIN_CENTS,
                    OOD_NEG_MAX_CENTS,
                ],

            "OOD_positive_cents":
                [
                    OOD_POS_MIN_CENTS,
                    OOD_POS_MAX_CENTS,
                ],

            "stress_cents":
                [
                    STRESS_NEG_CENTS,
                    STRESS_POS_CENTS,
                ],

            "step_onset_s":
                [
                    STEP_ONSET_MIN_S,
                    STEP_ONSET_MAX_S,
                ],

            "ramp_onset_s":
                [
                    RAMP_ONSET_MIN_S,
                    RAMP_ONSET_MAX_S,
                ],

            "ramp_duration_s":
                [
                    RAMP_DURATION_MIN_S,
                    RAMP_DURATION_MAX_S,
                ],
        },

        "initial_state_policy":
            "FILE74_RATED_REFERENCE_STATE_ONLY",

        "trajectory_horizon_s":
            TRAJECTORY_HORIZON_S,

        "temporal_representation": {

            "global_view": {

                "time_start_s":
                    0.0,

                "time_end_s":
                    TRAJECTORY_HORIZON_S,

                "dt_s":
                    GLOBAL_DT_S,

                "points":
                    GLOBAL_POINTS,

                "applies_to":
                    "ALL_CASES",
            },

            "step_event_local_view": {

                "relative_time_start_s":
                    0.0,

                "relative_time_end_s":
                    STEP_TRANSITION_END_S,

                "points":
                    STEP_EVENT_LOCAL_POINTS,

                "fast_region": {

                    "start_s":
                        0.0,

                    "end_s":
                        STEP_FAST_END_S,

                    "dt_s":
                        STEP_FAST_DT_S,
                },

                "transition_region": {

                    "start_s":
                        STEP_FAST_END_S,

                    "end_s":
                        STEP_TRANSITION_END_S,

                    "dt_s":
                        STEP_TRANSITION_DT_S,
                },

                "applies_to":
                    "STEP_HOLD_ONLY",

                "time_vector_s":
                    [
                        float(
                            x
                        )
                        for x
                        in event_relative_time
                    ],
            },

            "ramp_event_anchors": {

                "applies_to":
                    "LINEAR_RAMP_HOLD_ONLY",

                "anchors":
                    [
                        "event_onset",
                        "event_completion",
                    ],

                "purpose":
                    (
                        "PRESERVE_EXACT_NONINTEGER_"
                        "WAVEFORM_BREAKPOINT_STATES"
                    ),
            },
        },

        "primary_pino_targets": {

            "count":
                len(
                    state_names
                ),

            "fields":
                state_names,

            "policy":
                (
                    "ALL_FILE74_DYNAMIC_STATES_"
                    "ARE_PRIMARY_OPERATOR_TARGETS"
                ),
        },

        "auxiliary_cycle_outputs": {

            "count":
                len(
                    varying_derived_fields
                ),

            "fields":
                varying_derived_fields,

            "role":
                (
                    "REFERENCE_AND_FULL_SYSTEM_EVALUATION_ONLY"
                ),

            "network_target":
                False,

            "reason":
                (
                    "THESE OUTPUTS ARE ALGEBRAICALLY GENERATED "
                    "FROM THE FROZEN CYCLE MODEL AND SHOULD NOT "
                    "BE LEARNED AS INDEPENDENT UNCONSTRAINED "
                    "STATE VARIABLES"
                ),
        },

        "constant_cycle_fields": {

            "count":
                len(
                    constant_derived_fields
                ),

            "fields":
                constant_derived_fields,

            "per_timestep_storage":
                False,

            "role":
                "METADATA_ONLY",
        },

        "property_policy": {

            "CP_HEXE_J_kgK":
                519.654,

            "classification":
                "PROJECT_ASSUMPTION",

            "B12":
                "SOURCE_LOCKED_NOT_RUNTIME_REQUIRED",

            "transport_temperature_gate_K":
                [
                    400.0,
                    1200.0,
                ],
        },

        "raw_reference_dtype":
            RAW_REFERENCE_DTYPE,

        "training_dtype":
            TRAINING_DTYPE,

        "storage_policy": {

            "raw_reference":
                (
                    "FLOAT64_PRODUCTION_REFERENCE_DATA"
                ),

            "training_conversion":
                (
                    "CONVERT_TO_FLOAT32_IN_TRAINING_LOADER"
                ),

            "recommended_structure":
                (
                    "NUMPY_MEMORY_MAPPED_ARRAYS_PLUS_"
                    "CSV_MANIFEST_AND_JSON_CONTRACT"
                ),
        },

        "estimated_uncompressed_core_storage_MiB":
            estimated_raw_mib,

        "manifest_file":
            OUTPUT_MANIFEST,

        "manifest_sha256":
            manifest_hash,

        "source_evidence": {

            "pilot_contract":
                FILE166_CONTRACT,

            "derived_field_classification":
                FILE168_DERIVED_STATS,

            "multirate_validation":
                FILE171_REPORT,
        },

        "future_expansion_rule":
            (
                "DO_NOT_EXPAND_DATASET_ARBITRARILY. "
                "EXPANSION IS PERMITTED ONLY IF STEP-7 "
                "LEARNING-CURVE OR GENERALIZATION TESTS "
                "SHOW THAT PRODUCTION_V1 IS INSUFFICIENT."
            ),
    }

    contract_path = (
        dataset_root
        / OUTPUT_CONTRACT
    )

    with contract_path.open(
        "w",
        encoding="utf-8",
    ) as f:

        json.dump(
            contract,
            f,
            indent=2,
        )

    # ======================================================================
    # REPORT
    # ======================================================================

    report_path = (
        dataset_root
        / OUTPUT_REPORT
    )

    with report_path.open(
        "w",
        encoding="utf-8",
    ) as f:

        f.write(
            "=" * 100
            + "\n"
        )

        f.write(
            "STEP 6 - PAPER-1 PRODUCTION "
            "DATASET DESIGN FREEZE\n"
        )

        f.write(
            "=" * 100
            + "\n\n"
        )

        f.write(
            f"Project root: {root}\n\n"
        )

        f.write(
            "PREREQUISITE RESULT\n"
        )

        f.write(
            "-" * 100
            + "\n"
        )

        f.write(
            "File 171 complete multi-rate grid: PASS\n"
        )

        f.write(
            f"Global grid                   : "
            f"{GLOBAL_DT_S:.6f} s\n"
        )

        f.write(
            f"STEP prompt grid              : "
            f"{STEP_FAST_DT_S * 1e6:.3f} us\n"
        )

        f.write(
            f"STEP transition grid          : "
            f"{STEP_TRANSITION_DT_S:.6f} s\n"
        )

        f.write(
            f"STEP event-local points       : "
            f"{STEP_EVENT_LOCAL_POINTS}\n\n"
        )

        # --------------------------------------------------------------
        # Dataset count
        # --------------------------------------------------------------

        f.write(
            "PRODUCTION CASE COUNTS\n"
        )

        f.write(
            "=" * 100
            + "\n"
        )

        for partition in (
            "TRAIN",
            "VALIDATION",
            "ID_TEST",
            "OOD_NEG_TEST",
            "OOD_POS_TEST",
            "STRESS_TEST",
        ):

            f.write(
                f"{partition:<20s}: "
                f"{partition_counts.get(partition, 0)}\n"
            )

        f.write(
            "\n"
        )

        f.write(
            f"TOTAL PRODUCTION CASES : "
            f"{len(rows)}\n"
        )

        f.write(
            f"STEP_HOLD cases        : "
            f"{actual_step_cases}\n"
        )

        f.write(
            f"LINEAR_RAMP_HOLD cases : "
            f"{actual_ramp_cases}\n"
        )

        f.write(
            f"BASELINE cases         : "
            f"{waveform_counts.get('BASELINE', 0)}\n"
        )

        # --------------------------------------------------------------
        # Split philosophy
        # --------------------------------------------------------------

        f.write(
            "\n\nPARTITION POLICY\n"
        )

        f.write(
            "=" * 100
            + "\n"
        )

        f.write(
            "TRAIN:\n"
        )

        f.write(
            "  ID cases only. Includes one exact rated "
            "zero-reactivity baseline.\n\n"
        )

        f.write(
            "VALIDATION:\n"
        )

        f.write(
            "  Independent scrambled-Sobol ID cases. "
            "Used for model/hyperparameter selection.\n\n"
        )

        f.write(
            "ID_TEST:\n"
        )

        f.write(
            "  Independent ID cases never used for training "
            "or validation.\n\n"
        )

        f.write(
            "OOD_NEG_TEST / OOD_POS_TEST:\n"
        )

        f.write(
            "  Amplitude-extrapolation cases. Never exposed "
            "during training or validation.\n\n"
        )

        f.write(
            "STRESS_TEST:\n"
        )

        f.write(
            "  Reserved -30 and +17.5 cent boundary/stress cases. "
            "Never exposed during model development.\n"
        )

        # --------------------------------------------------------------
        # Target variables
        # --------------------------------------------------------------

        f.write(
            "\n\nPRIMARY PINO TARGETS\n"
        )

        f.write(
            "=" * 100
            + "\n"
        )

        f.write(
            f"Primary dynamic targets: "
            f"{len(state_names)}\n\n"
        )

        for index, name in enumerate(
            state_names
        ):

            f.write(
                f"{index:2d}: "
                f"{name}\n"
            )

        f.write(
            "\n"
        )

        f.write(
            "Reason:\n"
        )

        f.write(
            "The point-kinetics precursor groups and thermal states "
            "are true dynamic states of the File-74 reference model "
            "and are required for physics-informed consistency.\n"
        )

        # --------------------------------------------------------------
        # Auxiliary outputs
        # --------------------------------------------------------------

        f.write(
            "\n\nAUXILIARY COUPLED-CYCLE OUTPUTS\n"
        )

        f.write(
            "=" * 100
            + "\n"
        )

        f.write(
            f"Varying auxiliary fields : "
            f"{len(varying_derived_fields)}\n"
        )

        f.write(
            f"Constant metadata fields  : "
            f"{len(constant_derived_fields)}\n\n"
        )

        f.write(
            "Varying fields retained for reference/full-system "
            "evaluation:\n"
        )

        for name in (
            varying_derived_fields
        ):

            f.write(
                f"  - {name}\n"
            )

        f.write(
            "\n"
        )

        f.write(
            "These are NOT independent PINO targets because they "
            "are algebraic outputs of the frozen Brayton-cycle "
            "mapping driven by the dynamic state.\n"
        )

        f.write(
            "\nEffectively constant fields stored as metadata only:\n"
        )

        for name in (
            constant_derived_fields
        ):

            f.write(
                f"  - {name}\n"
            )

        # --------------------------------------------------------------
        # Multi-rate storage
        # --------------------------------------------------------------

        f.write(
            "\n\nFROZEN RAW TEMPORAL REPRESENTATION\n"
        )

        f.write(
            "=" * 100
            + "\n"
        )

        f.write(
            "ALL CASES:\n"
        )

        f.write(
            "  global 0-600 s trajectory\n"
        )

        f.write(
            "  dt = 1.0 s\n"
        )

        f.write(
            "  601 points\n\n"
        )

        f.write(
            "STEP_HOLD CASES:\n"
        )

        f.write(
            "  event-relative 0-10 ms: dt = 10 us\n"
        )

        f.write(
            "  event-relative 10 ms-5 s: dt = 0.25 s\n"
        )

        f.write(
            f"  merged event-local points: "
            f"{STEP_EVENT_LOCAL_POINTS}\n\n"
        )

        f.write(
            "LINEAR_RAMP_HOLD CASES:\n"
        )

        f.write(
            "  1-s global trajectory plus exact "
            "onset/completion state anchors.\n"
        )

        # --------------------------------------------------------------
        # Sobol design
        # --------------------------------------------------------------

        f.write(
            "\n\nSAMPLING DESIGN\n"
        )

        f.write(
            "=" * 100
            + "\n"
        )

        f.write(
            "Method: independent scrambled Sobol sequences.\n"
        )

        f.write(
            "Every train/validation/test/OOD/stress block uses "
            "a separate deterministic seed.\n\n"
        )

        f.write(
            "Sobol sampling is a numerical space-filling design.\n"
        )

        f.write(
            "It is NOT a statement of physical probability or "
            "parameter uncertainty.\n"
        )

        # --------------------------------------------------------------
        # Storage
        # --------------------------------------------------------------

        f.write(
            "\n\nESTIMATED CORE RAW STORAGE\n"
        )

        f.write(
            "=" * 100
            + "\n"
        )

        f.write(
            f"Uncompressed float64 estimate : "
            f"{estimated_raw_mib:.2f} MiB\n"
        )

        f.write(
            "This estimate covers dynamic global states, "
            "global reactivity, nine varying global auxiliary "
            "outputs, and STEP event-local states/reactivity.\n"
        )

        f.write(
            "Actual storage may differ due to metadata and "
            "filesystem representation.\n"
        )

        # --------------------------------------------------------------
        # Freeze rules
        # --------------------------------------------------------------

        f.write(
            "\n\nPRODUCTION DATASET FREEZE RULES\n"
        )

        f.write(
            "=" * 100
            + "\n"
        )

        rules = (

            "1. Generate exactly the manifest cases defined "
            "by File 172 for Production V1.",

            "2. Do not mix OOD or stress cases into training "
            "or validation.",

            "3. Use the rated File-74 reference state for "
            "every production trajectory.",

            "4. external_reactivity remains the only independently "
            "sampled full-system input.",

            "5. Preserve the validated multi-rate temporal "
            "representation.",

            "6. Store raw reference quantities in float64.",

            "7. Convert to float32 only in the later ML data loader.",

            "8. The 10 dynamic File-74 states are the primary "
            "PINO targets.",

            "9. The nine varying Brayton fields are auxiliary "
            "full-system evaluation quantities, not unconstrained "
            "independent network targets.",

            "10. The 17 effectively constant Brayton fields are "
            "metadata and must not inflate the training target vector.",

            "11. Apply the frozen File-72 400-1200 K runtime "
            "transport gate during generation.",

            "12. Reject and log any failed/unsupported trajectory "
            "rather than silently replacing it.",

            "13. Do not expand the Production V1 dataset merely "
            "to increase sample count.",

            "14. Additional samples are permitted only if later "
            "learning-curve/generalization evidence demonstrates "
            "that Production V1 is insufficient.",
        )

        for rule in rules:

            f.write(
                f"{rule}\n"
            )

        # --------------------------------------------------------------
        # Final gate
        # --------------------------------------------------------------

        f.write(
            "\n\nSTEP-6 PRODUCTION DESIGN GATE\n"
        )

        f.write(
            "=" * 100
            + "\n"
        )

        f.write(
            f"Manifest validation errors : "
            f"{len(errors)}\n"
        )

        f.write(
            f"Total cases                : "
            f"{len(rows)}\n"
        )

        f.write(
            f"Primary PINO targets       : "
            f"{len(state_names)}\n"
        )

        f.write(
            f"Auxiliary varying outputs  : "
            f"{len(varying_derived_fields)}\n"
        )

        f.write(
            f"Constant metadata outputs  : "
            f"{len(constant_derived_fields)}\n"
        )

        f.write(
            f"Validated STEP event points: "
            f"{len(event_relative_time)}\n"
        )

        f.write(
            "\n"
        )

        f.write(
            "PRODUCTION DATASET DESIGN STATUS: FROZEN\n"
        )

        f.write(
            "\n"
        )

        f.write(
            "NEXT:\n"
        )

        f.write(
            "EXECUTE A SMALL PRODUCTION-FORMAT SMOKE TEST, "
            "THEN GENERATE THE FROZEN PRODUCTION V1 DATASET.\n"
        )

        f.write(
            "\n"
            + "=" * 100
            + "\n"
        )

        f.write(
            "STATUS: STEP-6 PRODUCTION DATASET "
            "DESIGN FROZEN\n"
        )

    # ======================================================================
    # TERMINAL
    # ======================================================================

    print(
        "=" * 78
    )

    print(
        "STEP 6 - PRODUCTION DATASET "
        "DESIGN FREEZE"
    )

    print(
        "=" * 78
    )

    print()

    print(
        f"Total production cases   : "
        f"{len(rows)}"
    )

    print(
        f"TRAIN                    : "
        f"{partition_counts.get('TRAIN', 0)}"
    )

    print(
        f"VALIDATION               : "
        f"{partition_counts.get('VALIDATION', 0)}"
    )

    print(
        f"ID_TEST                  : "
        f"{partition_counts.get('ID_TEST', 0)}"
    )

    print(
        f"OOD_NEG_TEST             : "
        f"{partition_counts.get('OOD_NEG_TEST', 0)}"
    )

    print(
        f"OOD_POS_TEST             : "
        f"{partition_counts.get('OOD_POS_TEST', 0)}"
    )

    print(
        f"STRESS_TEST              : "
        f"{partition_counts.get('STRESS_TEST', 0)}"
    )

    print()

    print(
        f"STEP_HOLD cases          : "
        f"{actual_step_cases}"
    )

    print(
        f"RAMP cases               : "
        f"{actual_ramp_cases}"
    )

    print()

    print(
        f"Global trajectory points : "
        f"{GLOBAL_POINTS}"
    )

    print(
        f"STEP event-local points  : "
        f"{len(event_relative_time)}"
    )

    print(
        f"Fast STEP dt [us]        : "
        f"{STEP_FAST_DT_S * 1e6:.3f}"
    )

    print(
        f"Transition dt [s]        : "
        f"{STEP_TRANSITION_DT_S:.3f}"
    )

    print()

    print(
        f"Primary PINO targets     : "
        f"{len(state_names)}"
    )

    print(
        f"Auxiliary varying fields : "
        f"{len(varying_derived_fields)}"
    )

    print(
        f"Constant metadata fields : "
        f"{len(constant_derived_fields)}"
    )

    print()

    print(
        f"Estimated raw storage    : "
        f"{estimated_raw_mib:.2f} MiB"
    )

    print()

    print(
        f"Manifest SHA256:"
    )

    print(
        f"  {manifest_hash}"
    )

    print()

    print(
        f"Saved manifest:"
    )

    print(
        f"  {DATASET_DIRECTORY}/"
        f"{OUTPUT_MANIFEST}"
    )

    print(
        f"Saved contract:"
    )

    print(
        f"  {DATASET_DIRECTORY}/"
        f"{OUTPUT_CONTRACT}"
    )

    print(
        f"Saved report:"
    )

    print(
        f"  {DATASET_DIRECTORY}/"
        f"{OUTPUT_REPORT}"
    )

    print()

    print(
        "STATUS: STEP-6 PRODUCTION "
        "DATASET DESIGN FROZEN"
    )

    print(
        "NEXT: PRODUCTION-FORMAT "
        "GENERATOR SMOKE TEST"
    )


if __name__ == "__main__":
    main()